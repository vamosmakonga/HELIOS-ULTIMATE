package com.vamosmakonga.helios

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var status: TextView
    private lateinit var report: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF081323.toInt())
        }
        fun label(text: String, size: Float) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFEAF5FF.toInt())
        }
        layout.addView(label("HELIOS", 32f).apply { gravity = Gravity.CENTER; setTextColor(0xFF61D9FF.toInt()) })
        layout.addView(label("Assistant Android — première base native", 14f).apply { gravity = Gravity.CENTER })
        status = label("Prêt", 15f)
        report = label("Rapport : en attente de commande.", 16f)
        input = EditText(this).apply { hint = "Écris une commande"; setTextColor(-1) }
        fun button(text: String, action: () -> Unit) {
            layout.addView(Button(this).apply { this.text = text; isAllCaps = false; setOnClickListener { action() } })
        }
        layout.addView(status)
        button("🎙 Parler à HELIOS") { listen() }
        layout.addView(input)
        button("Exécuter") { execute(input.text.toString()) }
        button("Afficher les applications") { showApps() }
        layout.addView(ScrollView(this).apply { addView(report) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            report("Autorisation microphone manquante."); requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            report("Aucun moteur de reconnaissance vocale disponible sur Android."); return
        }
        try {
            recognizer?.destroy()
            recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this) else SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Écoute en cours…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Analyse…" }
                override fun onError(error: Int) {
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Android refuse la permission microphone."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Le moteur vocal demande Internet ou ne répond pas."
                        SpeechRecognizer.ERROR_NO_MATCH -> "Aucune parole comprise."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Aucune voix détectée."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Moteur vocal occupé. Réessaie."
                        SpeechRecognizer.ERROR_AUDIO -> "Erreur audio du microphone."
                        else -> "Échec de reconnaissance vocale, code Android : $error."
                    }
                    showReport(msg)
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) { input.setText(text); execute(text) } else showReport("Aucune parole reconnue.")
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) { showReport("Démarrage vocal impossible : ${e.message}") }
    }

    private fun execute(raw: String) {
        val c = raw.trim().lowercase(Locale.FRENCH)
        if (c.isEmpty()) { showReport("Commande vide."); return }
        when {
            c.contains("bonjour") || c == "salut" -> say("Bonjour. HELIOS est prêt.")
            c.contains("heure") -> say("Il est " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
            c.contains("date") -> say("Nous sommes le " + SimpleDateFormat("dd MMMM yyyy", Locale.FRENCH).format(Date()))
            c.contains("paramètre") || c.contains("parametre") -> open(Intent(android.provider.Settings.ACTION_SETTINGS), "Paramètres ouverts.")
            c.contains("wifi") -> open(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS), "Paramètres Wi-Fi ouverts.")
            c.contains("bluetooth") -> open(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS), "Paramètres Bluetooth ouverts.")
            c.startsWith("ouvre ") || c.startsWith("ouvrir ") -> openApp(c.substringAfter(" ").trim())
            else -> say("Commande reçue, mais cette fonction n'est pas encore programmée.")
        }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val found = apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
        if (found == null) { say("Application introuvable : $name"); return }
        val launch = pm.getLaunchIntentForPackage(found.activityInfo.packageName)
        if (launch != null) { startActivity(launch); showReport("Application ouverte : ${found.loadLabel(pm)}") }
        else say("Impossible de lancer cette application.")
    }

    private fun showApps() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        showReport("Applications détectées : " + apps.map { it.loadLabel(pm).toString() }.distinct().sorted().take(40).joinToString(", "))
    }

    private fun open(intent: Intent, message: String) {
        try { startActivity(intent); showReport(message) } catch (_: Exception) { showReport("Action non disponible sur ce téléphone.") }
    }
    private fun say(message: String) {
        showReport(message)
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "helios")
    }
    private fun showReport(message: String) { report.text = "Rapport HELIOS : $message"; status.text = "Prêt" }
    override fun onInit(code: Int) {
        ttsReady = code == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.FRENCH
    }
    override fun onDestroy() { recognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
}
