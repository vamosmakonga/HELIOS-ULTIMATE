plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.vamosmakonga.helios"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vamosmakonga.helios"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
