# HELIOS ULTIMATE — première base Android native

Cette archive est le socle de départ d'une application Android native. Ce n'est pas encore le JARVIS complet ni un APK compilé.

## Déjà prévu dans ce socle
- Interface Android native.
- Reconnaissance vocale Android en français, avec priorité au moteur hors ligne si disponible.
- Réponse vocale française via Text-to-Speech.
- Commandes locales simples : heure, date, paramètres, Wi-Fi, Bluetooth.
- Ouverture d'applications par leur nom, selon ce qu'Android autorise.
- Messages de diagnostic plus précis pour les erreurs vocales.

## Limites à connaître
- La reconnaissance vocale hors ligne exige un moteur et un modèle français installés sur le téléphone.
- La reconnaissance standard peut nécessiter Internet.
- Les commandes avancées, recherche Web, caméra IA, mémoire évoluée, activation permanente « Bonjour HELIOS », automatisations et autoréparation ne sont pas encore développées.
- Android protège certaines actions et demandera des autorisations.
- Le projet source doit être compilé pour produire l'APK.

## Compilation
Le workflow GitHub Actions permet une compilation à distance après envoi du projet dans un dépôt GitHub. Ouvrir l'onglet Actions, lancer « Construire HELIOS APK » puis télécharger l'artefact `HELIOS-APK-debug`.

## Technologies
Kotlin, Android natif, Java 17, Gradle 8.9, minSdk 26, compileSdk 35.
