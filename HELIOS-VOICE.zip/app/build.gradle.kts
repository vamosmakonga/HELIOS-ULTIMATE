plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vamos.helios"
    compileSdk = 34

    // Signature FIXE : chaque build GitHub produit un APK signé avec la même clé,
    // donc les mises à jour s'installent par-dessus sans « Application non installée ».
    signingConfigs {
        create("helios") {
            storeFile = file("helios.keystore")
            storePassword = "helios2026"
            keyAlias = "helios"
            keyPassword = "helios2026"
        }
    }

    defaultConfig {
        // Identifiant NOUVEAU : cohabite avec d'anciennes versions de HELIOS (aucun conflit de signature).
        applicationId = "com.vamos.helios.voice"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "2.0"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("helios")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("helios")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    androidResources {
        noCompress += listOf("onnx", "txt")
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
