package com.vamos.helios

import android.content.Context
import android.os.Build
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Liaison avec l'API Gemini : conversation avec mémoire courte + appel des outils du téléphone. */
object Gemini {

    private val history = ArrayList<JSONObject>()
    private const val MAX_STEPS = 8

    private fun systemPrompt(ctx: Context): String {
        val lang = if (Prefs.lang(ctx) == "sw") "en swahili (Kiswahili)" else "en français"
        val now = SimpleDateFormat("EEEE d MMMM yyyy HH:mm", Locale.FRANCE).format(Date())
        return """
Tu es HELIOS, l'assistant vocal personnel de l'utilisateur, installé sur son téléphone Android (${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}). Tu es inspiré de Jarvis : calme, efficace, courtois, légèrement formel.
Tu peux AGIR sur le téléphone grâce aux outils fournis : ouvrir des applications, appeler, envoyer des SMS, lire et toucher l'écran, défiler, écrire, régler volume/alarme/lampe, faire un diagnostic, etc.

Règles :
- Réponds $lang, en 1 à 3 phrases courtes. Tes réponses sont lues à voix haute : pas de markdown, pas de listes, pas d'émojis, pas de symboles.
- Ce que dit l'utilisateur est transcrit automatiquement et contient des erreurs : devine l'intention la plus probable (« ouvre watsap » = WhatsApp, « appel Jean » = appeler Jean).
- Pour une tâche dans une application : ouvre-la (open_app), lis l'écran (read_screen), puis appuie (click_text ou tap), écris (type_text), fais défiler (scroll). Vérifie avec read_screen avant d'affirmer que c'est fait.
- Si l'utilisateur dit « fais le diagnostic », « vérifie le téléphone » : appelle l'outil diagnostic et résume le résultat.
- Pour envoyer un SMS ou un message : demande d'abord confirmation orale (destinataire et texte), puis n'envoie qu'après un « oui ». Les appels demandés explicitement par l'utilisateur peuvent être lancés directement.
- N'affirme jamais avoir réussi si un outil a renvoyé une erreur : explique simplement le problème (ex. accessibilité à activer, autorisation manquante).
- Tu te souviens de la conversation en cours. Sois bref.
Date et heure actuelles : $now.
""".trimIndent()
    }

    private fun candidates(ctx: Context): List<String> {
        val m = Prefs.model(ctx)
        return listOf(m, "gemini-flash-latest", "gemini-2.5-flash", "gemini-2.0-flash").distinct()
    }

    private class Resp(val code: Int, val body: String)

    private fun post(model: String, key: String, body: JSONObject): Resp {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 45000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Resp(code, txt)
        } finally {
            c.disconnect()
        }
    }

    /** Envoie la requête ; essaie d'autres noms de modèle si celui choisi n'existe pas (404). */
    private fun call(ctx: Context, body: JSONObject): Resp {
        val key = Prefs.key(ctx)
        var last = Resp(0, "")
        for (m in candidates(ctx)) {
            val r = post(m, key, body)
            last = r
            if (r.code == 404) continue
            if (r.code in 200..299 && m != Prefs.model(ctx)) Prefs.setModel(ctx, m)
            return r
        }
        return last
    }

    private fun errorText(r: Resp): String = when {
        r.code == 429 -> "Le quota Gemini est dépassé. Réessayez dans une minute."
        r.code == 400 && r.body.contains("API key", true) -> "La clé Gemini est refusée. Vérifiez-la dans les réglages."
        r.code == 403 || r.code == 401 -> "La clé Gemini n'a pas l'autorisation. Vérifiez-la dans les réglages."
        r.code == 404 -> "Le modèle Gemini choisi n'existe pas. Changez-le dans les réglages."
        r.code >= 500 -> "Gemini est momentanément indisponible."
        else -> "Gemini a répondu avec une erreur ${r.code}."
    }

    private fun trimHistory() {
        while (history.size > 16) history.removeAt(0)
        // l'historique doit commencer par un message texte de l'utilisateur
        while (history.isNotEmpty()) {
            val f = history[0]
            val parts = f.optJSONArray("parts")
            val firstIsText = f.optString("role") == "user" && parts != null && parts.length() > 0 && parts.getJSONObject(0).has("text")
            if (firstIsText) break
            history.removeAt(0)
        }
    }

    fun run(ctx: Context, userText: String): String {
        history.add(
            JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText)))
        )
        trimHistory()
        val turnStart = history.size
        var finalText = ""
        try {
            var steps = 0
            while (steps++ < MAX_STEPS) {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(ctx)))))
                    .put("contents", JSONArray(history))
                    .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", Tools.declarations())))
                val gen = JSONObject().put("temperature", 0.5).put("maxOutputTokens", 1024)
                if (Prefs.model(ctx).contains("2.5") && Prefs.model(ctx).contains("flash")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                body.put("generationConfig", gen)

                val r = call(ctx, body)
                if (r.code !in 200..299) {
                    finalText = errorText(r)
                    break
                }
                val content = JSONObject(r.body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (content == null || parts == null || parts.length() == 0) {
                    finalText = "Je ne peux pas répondre à cette demande."
                    break
                }
                if (!content.has("role")) content.put("role", "model")
                history.add(content)

                val respParts = JSONArray()
                val texts = StringBuilder()
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val fc = part.optJSONObject("functionCall")
                    if (fc != null) {
                        val name = fc.optString("name")
                        val args = fc.optJSONObject("args") ?: JSONObject()
                        Bus.emit("tool", name)
                        val result = Tools.execute(ctx, name, args)
                        respParts.put(
                            JSONObject().put(
                                "functionResponse",
                                JSONObject().put("name", name).put("response", JSONObject().put("result", result))
                            )
                        )
                    } else if (part.has("text") && !part.optBoolean("thought", false)) {
                        texts.append(part.optString("text"))
                    }
                }
                if (respParts.length() == 0) {
                    finalText = texts.toString().trim()
                    break
                }
                history.add(JSONObject().put("role", "user").put("parts", respParts))
            }
            if (finalText.isBlank()) finalText = "C'est fait."
        } catch (e: IOException) {
            finalText = "Je n'arrive pas à joindre Gemini. Vérifiez la connexion Internet."
        } catch (t: Throwable) {
            finalText = "Erreur Gemini : ${t.message ?: t.javaClass.simpleName}"
        }

        // On ne garde en mémoire que le texte : on retire les appels d'outils de ce tour.
        try {
            val keep = ArrayList<JSONObject>(history.subList(0, turnStart))
            keep.add(
                JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", finalText)))
            )
            history.clear()
            history.addAll(keep)
        } catch (_: Throwable) {
        }
        return finalText.replace(Regex("[*#_`]+"), "").trim()
    }

    /** Analyse d'une image (capture d'écran) par Gemini. */
    fun askWithImage(ctx: Context, jpeg: ByteArray, question: String): String {
        return try {
            val parts = JSONArray()
                .put(JSONObject().put("text", "$question\nRéponds en français, en 2 ou 3 phrases courtes, sans markdown."))
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))))
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            val r = call(ctx, body)
            if (r.code !in 200..299) return errorText(r)
            val p = JSONObject(r.body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (p != null) for (i in 0 until p.length()) sb.append(p.getJSONObject(i).optString("text"))
            sb.toString().trim().ifEmpty { "Je ne distingue rien d'exploitable sur l'écran." }
        } catch (t: Throwable) {
            "Analyse de l'écran impossible : ${t.message ?: t.javaClass.simpleName}"
        }
    }
}
