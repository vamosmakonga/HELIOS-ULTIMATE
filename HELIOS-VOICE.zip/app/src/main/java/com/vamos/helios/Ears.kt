package com.vamos.helios

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OnlineModelConfig
import com.k2fsa.sherpa.onnx.OnlineRecognizer
import com.k2fsa.sherpa.onnx.OnlineRecognizerConfig
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig
import kotlin.math.min
import kotlin.math.sqrt

/** Oreilles de HELIOS : transforment la voix en texte, en continu. */
abstract class Ears(protected val ctx: Context, protected val cb: Callback) {
    interface Callback {
        fun onPartial(t: String)
        fun onFinal(t: String)
        fun onLevel(l: Float)
        fun onProblem(msg: String)
    }

    /** Vrai pendant que HELIOS parle : l'audio est ignoré pour qu'il ne s'entende pas lui-même. */
    @Volatile
    var muted: Boolean = false

    abstract val name: String
    abstract fun start()
    abstract fun stop()
}

/** Reconnaissance HORS LIGNE avec Sherpa-ONNX (modèle zipformer français embarqué dans l'APK). */
class SherpaEars(ctx: Context, cb: Callback) : Ears(ctx, cb) {
    override val name = "Sherpa-ONNX (hors ligne)"

    @Volatile
    private var running = false
    private var thread: Thread? = null
    private var recognizer: OnlineRecognizer? = null

    /** Charge le modèle. Renvoie faux s'il est absent ou illisible (on bascule alors sur le micro Android). */
    fun init(): Boolean {
        return try {
            val am = ctx.assets
            val files = am.list("sherpa-fr") ?: return false
            if (!files.contains("tokens.txt") || !files.contains("encoder.onnx") ||
                !files.contains("decoder.onnx") || !files.contains("joiner.onnx")
            ) return false
            val cfg = OnlineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OnlineModelConfig(
                    transducer = OnlineTransducerModelConfig(
                        encoder = "sherpa-fr/encoder.onnx",
                        decoder = "sherpa-fr/decoder.onnx",
                        joiner = "sherpa-fr/joiner.onnx"
                    ),
                    tokens = "sherpa-fr/tokens.txt",
                    numThreads = 2,
                    debug = false,
                    provider = "cpu"
                ),
                enableEndpoint = true,
                decodingMethod = "greedy_search"
            )
            recognizer = OnlineRecognizer(assetManager = am, config = cfg)
            true
        } catch (t: Throwable) {
            Log.e("HELIOS", "Sherpa init: $t")
            false
        }
    }

    override fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "helios-ears").also { it.start() }
    }

    override fun stop() {
        running = false
        try {
            thread?.join(1500)
        } catch (_: Throwable) {
        }
    }

    private fun loop() {
        val rec = recognizer ?: return
        val sr = 16000
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val audio = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, sr * 2)
            )
        } catch (t: Throwable) {
            cb.onProblem("Micro indisponible : ${t.message}")
            return
        }
        if (audio.state != AudioRecord.STATE_INITIALIZED) {
            cb.onProblem("Le micro ne démarre pas. Vérifiez l'autorisation Microphone.")
            return
        }
        audio.startRecording()
        val stream = rec.createStream()
        val buf = ShortArray(1600)
        var last = ""
        try {
            while (running) {
                val n = audio.read(buf, 0, buf.size)
                if (n <= 0) continue
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i].toDouble()
                cb.onLevel(min(1f, sqrt(sum / n).toFloat() / 6000f))
                if (muted) {
                    if (last.isNotEmpty()) {
                        rec.reset(stream)
                        last = ""
                    }
                    continue
                }
                val f = FloatArray(n) { buf[it] / 32768f }
                stream.acceptWaveform(f, sr)
                while (rec.isReady(stream)) rec.decode(stream)
                val text = rec.getResult(stream).text.trim()
                if (text != last) {
                    last = text
                    if (text.isNotEmpty()) cb.onPartial(text)
                }
                if (rec.isEndpoint(stream)) {
                    if (text.isNotEmpty()) cb.onFinal(text)
                    rec.reset(stream)
                    last = ""
                }
            }
        } catch (t: Throwable) {
            cb.onProblem("Erreur d'écoute : ${t.message}")
        } finally {
            try {
                audio.stop()
                audio.release()
            } catch (_: Throwable) {
            }
            try {
                stream.release()
            } catch (_: Throwable) {
            }
        }
    }
}

/** Écoute de secours / swahili : reconnaissance vocale Google du téléphone, relancée en boucle. */
class AndroidEars(ctx: Context, cb: Callback, private val lang: String) : Ears(ctx, cb) {
    override val name = if (lang == "sw") "Google Voice (swahili)" else "Google Voice"
    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null

    @Volatile
    private var running = false

    override fun start() {
        running = true
        h.post {
            if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                cb.onProblem("Aucun service de reconnaissance vocale sur ce téléphone (installez l'app Google).")
                return@post
            }
            create()
            listen()
        }
    }

    override fun stop() {
        running = false
        h.post {
            try {
                sr?.destroy()
            } catch (_: Throwable) {
            }
            sr = null
        }
    }

    private fun create() {
        try {
            sr?.destroy()
        } catch (_: Throwable) {
        }
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(listener) }
    }

    private fun listen() {
        if (!running) return
        if (muted) {
            h.postDelayed({ listen() }, 400)
            return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "sw") "sw-KE" else "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        try {
            sr?.startListening(i)
        } catch (_: Throwable) {
            h.postDelayed({ create(); listen() }, 800)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {
            cb.onLevel(min(1f, maxOf(0f, (rmsdB + 2f) / 12f)))
        }

        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {
            if (!running) return
            val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200L else 450L
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                cb.onProblem("Autorisation Microphone manquante.")
                return
            }
            h.postDelayed({
                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) create()
                listen()
            }, delay)
        }

        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            if (t.isNotEmpty() && !muted) cb.onFinal(t)
            h.postDelayed({ listen() }, 250)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (t.isNotEmpty() && !muted) cb.onPartial(t)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
