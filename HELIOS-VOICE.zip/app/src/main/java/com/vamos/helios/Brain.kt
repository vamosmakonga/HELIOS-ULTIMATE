package com.vamos.helios

import android.content.Context

/**
 * Cerveau de HELIOS.
 * 1) Commandes simples comprises LOCALEMENT (marche sans Internet, réponse immédiate).
 * 2) Tout le reste est confié à Gemini, qui enchaîne les outils du téléphone.
 */
object Brain {

    fun handle(ctx: Context, cmd: String): String {
        local(ctx, cmd)?.let { return it }
        if (Prefs.key(ctx).isBlank()) {
            return "Cette demande a besoin de Gemini. Ajoutez votre clé Gemini dans les réglages de HELIOS."
        }
        if (!Net.online(ctx)) {
            return "Je n'ai pas Internet pour cette demande. Hors ligne, je sais ouvrir les applications, la lampe, le volume, le diagnostic, les alarmes, les appels et les gestes d'écran."
        }
        return Gemini.run(ctx, cmd)
    }

    private val openRe = Regex("^(?:ouvre|ouvrir|ouvres|lance|lancer|demarre|demarrer|va sur|va dans|fungua|open)\\s+(?:l'application\\s+|l'app\\s+|application\\s+|app\\s+|la\\s+|le\\s+|l'|les\\s+)?(.+)$")
    private val callRe = Regex("^(?:appelle|appeler|telephone a|call|piga simu)\\s+(.+)$")
    private val timerRe = Regex("(?:minuteur|chrono|timer).*?(\\d+)\\s*(seconde|secondes|sec|minute|minutes|min|heure|heures)")
    private val alarmRe = Regex("(?:reveille|alarme|reveil).*?(\\d{1,2})\\s*(?:h|heures?|:)\\s*(\\d{1,2})?")

    private fun has(n: String, vararg w: String) = w.any { n.contains(it) }

    /** Renvoie la réponse parlée, ou null si la demande doit passer par Gemini. */
    fun local(ctx: Context, raw: String): String? {
        val n = Text.clean(Text.strip(raw))
        if (n.isEmpty()) return null

        // Arrêt
        if (Regex("^(stop|arrete|tais.?toi|silence|annule|ça suffit)\\b").containsMatchIn(n) || n == "ca suffit") {
            HeliosService.instance?.silence()
            return ""
        }

        // Langue
        if (has(n, "swahili", "kiswahili") && has(n, "parle", "passe", "mets", "change", "ongea")) {
            return Tools.execute(ctx, "set_language", org.json.JSONObject().put("lang", "sw"))
        }
        if (has(n, "francais") && has(n, "parle", "passe", "mets", "change", "reviens")) {
            return Tools.execute(ctx, "set_language", org.json.JSONObject().put("lang", "fr"))
        }

        // Diagnostic / état
        if (has(n, "diagnostic", "etat du telephone", "etat de l'appareil", "sante du telephone", "analyse le telephone", "verifie le telephone")) {
            return Tools.diagnostic(ctx)
        }
        if (has(n, "batterie") && !has(n, "parametre", "economie")) {
            return Tools.diagnostic(ctx).substringBefore("Stockage")
        }

        // Heure / date
        if (has(n, "quelle heure", "l'heure", "quel jour", "la date", "date d'aujourd", "on est quel jour")) return Tools.now()

        // Lampe
        if (has(n, "lampe", "torche", "flash", "lumiere")) {
            return when {
                has(n, "eteins", "eteint", "coupe", "desactive", "ferme", "arrete") -> Tools.flashlight(ctx, false)
                has(n, "allume", "active", "ouvre", "mets", "met ") -> Tools.flashlight(ctx, true)
                else -> null
            }
        }

        // Lecture des notifications
        if (has(n, "lis") && has(n, "notification")) return Tools.execute(ctx, "read_notifications", org.json.JSONObject())

        // Gestes système
        if (n == "retour" || has(n, "reviens en arriere", "touche retour", "va en arriere", "fais retour")) return Tools.execute(ctx, "press", org.json.JSONObject().put("key", "back"))
        if (has(n, "ecran d'accueil", "page d'accueil", "va a l'accueil", "retourne a l'accueil") || n == "accueil") return Tools.execute(ctx, "press", org.json.JSONObject().put("key", "home"))
        if (has(n, "applications recentes", "apps recentes", "multitache", "recents")) return Tools.execute(ctx, "press", org.json.JSONObject().put("key", "recents"))
        if (has(n, "capture d'ecran", "screenshot", "capture ecran")) return Tools.execute(ctx, "press", org.json.JSONObject().put("key", "screenshot"))
        if (has(n, "notification") && has(n, "ouvre", "affiche", "baisse", "montre", "descends")) return Tools.execute(ctx, "press", org.json.JSONObject().put("key", "notifications"))
        if (has(n, "verrouille")) return Tools.execute(ctx, "press", org.json.JSONObject().put("key", "lock"))
        if (has(n, "fais defiler", "defile", "descends la page", "scroll", "page suivante")) return Tools.execute(ctx, "scroll", org.json.JSONObject().put("direction", if (has(n, "haut", "monte", "up")) "up" else "down"))
        if (has(n, "remonte la page", "monte la page")) return Tools.execute(ctx, "scroll", org.json.JSONObject().put("direction", "up"))

        // Volume & médias
        if (has(n, "volume") || has(n, "coupe le son", "mets en muet")) {
            val act = when {
                has(n, "muet", "coupe le son") -> "mute"
                has(n, "moins", "baisse", "diminue", "plus bas", "reduis") -> "down"
                has(n, "plus", "augmente", "monte", "fort", "haut") -> "up"
                else -> return null
            }
            return Tools.volume(ctx, act, -1)
        }
        if (has(n, "mets en pause", "pause la musique", "mets pause") || n == "pause") return Tools.media(ctx, "play_pause")
        if (has(n, "reprends la musique", "relance la musique", "joue la musique") || n == "play" || n == "lecture") return Tools.media(ctx, "play_pause")
        if (has(n, "musique suivante", "piste suivante", "chanson suivante") || n == "suivant") return Tools.media(ctx, "next")
        if (has(n, "piste precedente", "musique precedente", "chanson precedente")) return Tools.media(ctx, "previous")

        // Minuteur / alarme
        timerRe.find(n)?.let { m ->
            val v = m.groupValues[1].toIntOrNull() ?: return@let
            val u = m.groupValues[2]
            val sec = when {
                u.startsWith("s") -> v
                u.startsWith("m") -> v * 60
                else -> v * 3600
            }
            return Tools.execute(ctx, "set_timer", org.json.JSONObject().put("seconds", sec))
        }
        alarmRe.find(n)?.let { m ->
            val h = m.groupValues[1].toIntOrNull() ?: return@let
            val mi = m.groupValues[2].toIntOrNull() ?: 0
            if (h in 0..23) return Tools.execute(ctx, "set_alarm", org.json.JSONObject().put("hour", h).put("minute", mi))
        }

        // Réglages
        if (has(n, "wifi", "wi fi", "wi-fi") && has(n, "ouvre", "active", "desactive", "parametre", "mets", "coupe", "allume", "eteins")) return Tools.openSettings(ctx, "wifi")
        if (has(n, "bluetooth") && has(n, "ouvre", "active", "desactive", "parametre", "mets", "coupe", "allume", "eteins")) return Tools.openSettings(ctx, "bluetooth")
        if (has(n, "donnees mobiles", "internet mobile")) return Tools.openSettings(ctx, "internet")
        if (n == "parametres" || has(n, "ouvre les parametres", "ouvre les reglages", "ouvre parametres")) return Tools.openSettings(ctx, "settings")

        // Écran
        if (has(n, "lis l'ecran", "lis ecran", "que vois tu", "qu'est ce qu'il y a a l'ecran", "decris l'ecran", "decris ecran")) {
            if (Prefs.key(ctx).isNotBlank() && Net.online(ctx) && HeliosAccessibilityService.instance != null) return null
            val d = Tools.execute(ctx, "read_screen", org.json.JSONObject())
            return d.lines().drop(1).take(12).joinToString(". ") { it.replace(Regex("^\\d+\\.\\s*"), "").substringBefore(" @").substringBefore(" [") }.ifBlank { d }
        }

        // Voice Access
        if (has(n, "voice access")) return Tools.execute(ctx, "voice_access", org.json.JSONObject())

        // Appeler
        callRe.find(n)?.let { return Tools.execute(ctx, "call", org.json.JSONObject().put("target", it.groupValues[1])) }

        // Ouvrir une application
        openRe.find(n)?.let { m ->
            val target = m.groupValues[1].trim()
            if (target.contains("http") || target.contains(".com") || target.contains(".org") || target.contains(" point ")) return null
            if (has(target, "parametre", "reglage")) return Tools.openSettings(ctx, "settings")
            return Tools.execute(ctx, "open_app", org.json.JSONObject().put("name", target))
        }
        return null
    }
}
