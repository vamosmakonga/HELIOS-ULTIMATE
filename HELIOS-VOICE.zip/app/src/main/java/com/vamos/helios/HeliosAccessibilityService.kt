package com.vamos.helios

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Le « Voice Access » intégré de HELIOS : lit l'écran, appuie, défile, écrit, fait les gestes système.
 * (L'application Voice Access de Google reste une application à part ; ce service fait le même travail
 * mais piloté par Gemini.)
 */
class HeliosAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: HeliosAccessibilityService? = null

        @Volatile
        var lastPackage: String = ""
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Bus.emit("a11y", "on")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val p = event?.packageName?.toString()
        if (!p.isNullOrEmpty()) lastPackage = p
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Bus.emit("a11y", "off")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- Lecture de l'écran ----------

    fun dump(max: Int = 70): String {
        val root = rootInActiveWindow ?: return "Écran illisible : aucune fenêtre active (écran verrouillé ?)."
        val sb = StringBuilder("Application au premier plan : $lastPackage\n")
        var n = 0
        fun walk(nd: AccessibilityNodeInfo?) {
            if (nd == null || n >= max) return
            val t = (nd.text ?: nd.contentDescription)?.toString()?.trim()
            val interesting = !t.isNullOrEmpty() || nd.isClickable || nd.isEditable
            if (nd.isVisibleToUser && interesting) {
                val r = Rect()
                nd.getBoundsInScreen(r)
                n++
                sb.append(n).append(". ")
                if (!t.isNullOrEmpty()) sb.append(t.take(80))
                else sb.append('(').append(nd.className?.toString()?.substringAfterLast('.') ?: "?").append(')')
                if (nd.isEditable) sb.append(" [champ de saisie]") else if (nd.isClickable) sb.append(" [cliquable]")
                sb.append(" @").append(r.centerX()).append(',').append(r.centerY()).append('\n')
            }
            for (i in 0 until nd.childCount) walk(nd.getChild(i))
        }
        walk(root)
        if (n == 0) sb.append("(aucun élément lisible)")
        return sb.toString()
    }

    private fun collect(label: String): List<AccessibilityNodeInfo> {
        val root = rootInActiveWindow ?: return emptyList()
        val direct = root.findAccessibilityNodeInfosByText(label)
        if (!direct.isNullOrEmpty()) return direct.filter { it.isVisibleToUser }
        val q = Text.strip(label)
        val found = ArrayList<AccessibilityNodeInfo>()
        fun walk(nd: AccessibilityNodeInfo?) {
            if (nd == null) return
            val t = (nd.text ?: nd.contentDescription)?.toString()
            if (t != null && nd.isVisibleToUser && Text.similarity(Text.strip(t), q) >= 80) found.add(nd)
            for (i in 0 until nd.childCount) walk(nd.getChild(i))
        }
        walk(root)
        return found
    }

    // ---------- Actions ----------

    fun clickText(label: String): Boolean {
        val target = collect(label).firstOrNull() ?: return false
        var n: AccessibilityNodeInfo? = target
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        target.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 70)).build()
        return dispatchGesture(g, null, null)
    }

    private fun swipePath(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val p = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }

    /** direction = sens de défilement du contenu : "down" pour voir la suite, "up" pour remonter. */
    fun scroll(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (direction.lowercase()) {
            "down", "bas" -> swipePath(w / 2, h * 0.72f, w / 2, h * 0.28f, 350)
            "up", "haut" -> swipePath(w / 2, h * 0.28f, w / 2, h * 0.72f, 350)
            "left", "gauche" -> swipePath(w * 0.25f, h / 2, w * 0.75f, h / 2, 300)
            "right", "droite" -> swipePath(w * 0.75f, h / 2, w * 0.25f, h / 2, 300)
            else -> false
        }
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null) {
            fun find(nd: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
                if (nd == null) return null
                if (nd.isEditable && nd.isVisibleToUser) return nd
                for (i in 0 until nd.childCount) find(nd.getChild(i))?.let { return it }
                return null
            }
            target = find(root)
        }
        if (target == null) return false
        val showingHint = if (Build.VERSION.SDK_INT >= 26) target.isShowingHintText else false
        val cur = if (showingHint) "" else target.text?.toString().orEmpty()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun press(key: String): Boolean {
        val a = when (key.lowercase()) {
            "back", "retour" -> GLOBAL_ACTION_BACK
            "home", "accueil" -> GLOBAL_ACTION_HOME
            "recents", "recent" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings", "reglages_rapides" -> GLOBAL_ACTION_QUICK_SETTINGS
            "power", "power_dialog" -> GLOBAL_ACTION_POWER_DIALOG
            "lock", "lock_screen", "verrouiller" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            "screenshot", "capture" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return false
            else -> return false
        }
        return performGlobalAction(a)
    }

    /** Capture d'écran en JPEG (Android 11+) pour que Gemini « voie » l'écran. */
    fun screenshotJpeg(): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: ByteArray? = null
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                ContextCompat.getMainExecutor(this),
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val hb = result.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                            val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            if (bmp != null) {
                                val scale = 900f / maxOf(bmp.width, bmp.height)
                                val sm = if (scale < 1f)
                                    Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
                                else bmp
                                val bos = ByteArrayOutputStream()
                                sm.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                                out = bos.toByteArray()
                            }
                        } catch (_: Throwable) {
                        }
                        latch.countDown()
                    }

                    override fun onFailure(errorCode: Int) {
                        latch.countDown()
                    }
                }
            )
        } catch (_: Throwable) {
            return null
        }
        latch.await(6, TimeUnit.SECONDS)
        return out
    }
}
