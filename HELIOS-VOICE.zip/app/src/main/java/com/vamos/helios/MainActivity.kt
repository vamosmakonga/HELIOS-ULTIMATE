package com.vamos.helios

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject

/** Écran principal : l'interface HUD « Jarvis » (assets/hud/index.html) dans une WebView, branchée sur le service. */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var startAfterPerms = false

    private val listener = Bus.Listener { type, payload ->
        runOnUiThread {
            if (::web.isInitialized) {
                web.evaluateJavascript(
                    "window.onHelios&&window.onHelios(${JSONObject.quote(type)},${JSONObject.quote(payload)})", null
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#02070D")
        window.navigationBarColor = Color.parseColor("#02070D")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#02070D"))
        setContentView(web)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            mediaPlaybackRequiresUserGesture = false
        }
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/hud/index.html")
    }

    override fun onResume() {
        super.onResume()
        Bus.add(listener)
        Bus.emit("resume", "")
    }

    override fun onPause() {
        Bus.remove(listener)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // HELIOS continue d'écouter en arrière-plan
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        try {
            web.removeJavascriptInterface("Android")
            web.destroy()
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (startAfterPerms && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startAfterPerms = false
            HeliosService.start(this)
        }
        Bus.emit("resume", "")
    }

    private fun needed(): Array<String> {
        val l = ArrayList<String>()
        l.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        l.add(Manifest.permission.CALL_PHONE)
        l.add(Manifest.permission.SEND_SMS)
        l.add(Manifest.permission.READ_CONTACTS)
        return l.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
    }

    private fun open(i: Intent) {
        try {
            startActivity(i)
        } catch (t: Throwable) {
            Toast.makeText(this, "Impossible d'ouvrir cet écran : ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Fonctions appelables depuis le HUD : window.Android.xxx() */
    inner class Bridge {

        @JavascriptInterface
        fun setup(): String {
            val pm = getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
            val sherpa = try {
                assets.list("sherpa-fr")?.contains("encoder.onnx") == true
            } catch (_: Throwable) {
                false
            }
            val o = JSONObject()
            o.put("mic", checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            o.put("perms", needed().isEmpty())
            o.put("a11y", HeliosAccessibilityService.instance != null)
            o.put("notif", NotificationManagerCompat.getEnabledListenerPackages(this@MainActivity).contains(packageName))
            o.put("overlay", Settings.canDrawOverlays(this@MainActivity))
            o.put("battery", pm.isIgnoringBatteryOptimizations(packageName))
            o.put("key", Prefs.key(this@MainActivity).isNotBlank())
            o.put("running", HeliosService.instance != null)
            o.put("sherpa", sherpa)
            o.put("lang", Prefs.lang(this@MainActivity))
            o.put("model", Prefs.model(this@MainActivity))
            o.put("cc", Prefs.cc(this@MainActivity))
            o.put("sdk", Build.VERSION.SDK_INT)
            o.put("state", Bus.state)
            return o.toString()
        }

        @JavascriptInterface
        fun start() {
            runOnUiThread {
                val n = needed()
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    startAfterPerms = true
                    requestPermissions(n, 7)
                } else {
                    HeliosService.start(this@MainActivity)
                    if (n.isNotEmpty()) requestPermissions(n, 8)
                }
            }
        }

        @JavascriptInterface
        fun stop() {
            runOnUiThread { HeliosService.stop(this@MainActivity) }
        }

        @JavascriptInterface
        fun perms() {
            runOnUiThread {
                val n = needed()
                if (n.isNotEmpty()) requestPermissions(n, 9)
                else Toast.makeText(this@MainActivity, "Toutes les autorisations sont déjà accordées.", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun send(text: String) {
            val s = HeliosService.instance
            if (s == null) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Démarrez HELIOS d'abord (bouton central).", Toast.LENGTH_SHORT).show() }
            } else s.typed(text)
        }

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun openNotifAccess() {
            runOnUiThread { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }

        /** Android 13+ : les applis installées hors Play Store sont « restreintes » ; le menu ⋮ de cet écran les débloque. */
        @JavascriptInterface
        fun openAppInfo() {
            runOnUiThread {
                open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }

        @JavascriptInterface
        fun openOverlay() {
            runOnUiThread { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        }

        @JavascriptInterface
        fun batteryExempt() {
            runOnUiThread {
                try {
                    open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (_: Throwable) {
                    open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }

        @JavascriptInterface
        fun saveKey(k: String) {
            Prefs.setKey(this@MainActivity, k)
        }

        @JavascriptInterface
        fun saveModel(m: String) {
            if (m.isNotBlank()) Prefs.setModel(this@MainActivity, m)
        }

        @JavascriptInterface
        fun saveCc(c: String) {
            Prefs.setCc(this@MainActivity, c)
        }

        @JavascriptInterface
        fun setLang(l: String) {
            Prefs.setLang(this@MainActivity, if (l == "sw") "sw" else "fr")
            HeliosService.instance?.restartEars()
        }

        @JavascriptInterface
        fun diag(): String = Tools.diagnostic(this@MainActivity)
    }
}
