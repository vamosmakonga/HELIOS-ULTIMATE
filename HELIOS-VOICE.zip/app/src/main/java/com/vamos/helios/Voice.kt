package com.vamos.helios

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Voix de HELIOS (moteur de synthèse du téléphone, voix grave si disponible). */
class Voice(
    ctx: Context,
    private val startCb: () -> Unit,
    private val doneCb: () -> Unit
) {
    private var tts: TextToSpeech? = null

    @Volatile
    private var ready = false

    @Volatile
    private var failed = false
    private var pending: Pair<String, String>? = null

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            startCb()
        }

        override fun onDone(utteranceId: String?) {
            doneCb()
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            doneCb()
        }
    }

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                tts?.setOnUtteranceProgressListener(progress)
                tts?.setPitch(0.8f)
                tts?.setSpeechRate(1.0f)
                pending?.let {
                    pending = null
                    speak(it.first, it.second)
                }
            } else {
                failed = true
                pending?.let {
                    pending = null
                    doneCb()
                }
            }
        }
    }

    fun speak(text: String, lang: String) {
        if (failed) {
            doneCb()
            return
        }
        val t = tts
        if (!ready || t == null) {
            pending = text to lang
            return
        }
        try {
            val loc = if (lang == "sw") Locale("sw", "KE") else Locale.FRANCE
            val r = t.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                t.setLanguage(Locale.FRANCE)
            }
            pickMale(t)
            val clean = text.replace(Regex("[*_#`>]"), "").take(3500)
            t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "h" + System.nanoTime())
        } catch (_: Throwable) {
            doneCb()
        }
    }

    private fun pickMale(t: TextToSpeech) {
        try {
            val cur = t.voice ?: return
            val lang = cur.locale.language
            val male = t.voices?.firstOrNull {
                it.locale.language == lang && it.name.contains("male", true) && !it.name.contains("female", true)
            }
            if (male != null) t.voice = male
        } catch (_: Throwable) {
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Throwable) {
        }
    }
}
