package com.vamos.helios

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Garde les dernières notifications pour que HELIOS puisse les lire à voix haute. */
class HeliosNotificationListener : NotificationListenerService() {

    companion object {
        private val recent = ArrayList<String>()

        @Synchronized
        fun add(s: String) {
            recent.add(0, s)
            while (recent.size > 30) recent.removeAt(recent.size - 1)
        }

        @Synchronized
        fun latest(n: Int): List<String> = recent.take(n)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        if (s.packageName == packageName) return
        try {
            val e = s.notification.extras
            val title = e.getCharSequence("android.title")?.toString().orEmpty()
            val text = e.getCharSequence("android.text")?.toString().orEmpty()
            if (title.isEmpty() && text.isEmpty()) return
            val label = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(s.packageName, 0)).toString()
            } catch (_: Throwable) {
                s.packageName
            }
            add("$label : $title ${if (text.isNotEmpty()) "- $text" else ""}".trim())
        } catch (_: Throwable) {
        }
    }
}
