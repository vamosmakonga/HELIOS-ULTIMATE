package com.vamos.helios

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.concurrent.CopyOnWriteArrayList

/** Bus d'événements Service -> interface HUD. */
object Bus {
    fun interface Listener {
        fun on(type: String, payload: String)
    }

    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile
    var state: String = "idle"

    fun add(l: Listener) {
        listeners.addIfAbsent(l)
    }

    fun remove(l: Listener) {
        listeners.remove(l)
    }

    fun emit(type: String, payload: String = "") {
        for (l in listeners) {
            try {
                l.on(type, payload)
            } catch (_: Throwable) {
            }
        }
    }

    fun changeState(s: String) {
        state = s
        emit("state", s)
    }
}

/** Réglages enregistrés sur le téléphone (jamais envoyés ailleurs que vers Gemini pour la clé). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("helios", Context.MODE_PRIVATE)

    fun key(c: Context): String = sp(c).getString("gkey", "") ?: ""
    fun setKey(c: Context, v: String) = sp(c).edit().putString("gkey", v.trim()).apply()

    fun model(c: Context): String = sp(c).getString("gmodel", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("gmodel", v.trim()).apply()

    fun lang(c: Context): String = sp(c).getString("lang", "fr") ?: "fr"
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()

    /** Indicatif pays par défaut pour les numéros locaux commençant par 0 (243 = RDC). */
    fun cc(c: Context): String = sp(c).getString("cc", "243") ?: "243"
    fun setCc(c: Context, v: String) = sp(c).edit().putString("cc", v.filter { it.isDigit() }).apply()

    fun notes(c: Context): JSONArray = try {
        JSONArray(sp(c).getString("notes", "[]"))
    } catch (_: Throwable) {
        JSONArray()
    }

    fun saveNotes(c: Context, a: JSONArray) = sp(c).edit().putString("notes", a.toString()).apply()
}

object Net {
    fun online(c: Context): Boolean {
        return try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(n) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Throwable) {
            false
        }
    }
}

/** Outils de texte : normalisation, distance d'édition, mot de réveil tolérant aux erreurs de reconnaissance. */
object Text {
    private val accents = Regex("\\p{Mn}+")

    fun strip(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(accents, "")

    fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }

    /** Similarité 0..100 entre deux libellés déjà normalisés. */
    fun similarity(a: String, b: String): Int {
        if (a.isEmpty() || b.isEmpty()) return 0
        if (a == b) return 100
        if (a.contains(b) || b.contains(a)) return 85
        val d = lev(a, b)
        val m = maxOf(a.length, b.length)
        return ((1.0 - d.toDouble() / m) * 75).toInt()
    }

    private val wakeSet = setOf("helios", "elios", "helio", "elyos", "helyos", "alios", "elio", "helias", "helyo")
    private val greet = setOf("bonjour", "salut", "hey", "ok", "dis", "eh", "hello", "coucou", "bonsoir", "ohe", "oh")

    private fun token(w: String): String = strip(w).trim { !it.isLetterOrDigit() }

    fun isWake(w: String): Boolean {
        val t = token(w)
        if (t.length < 4) return false
        return t in wakeSet || lev(t, "helios") <= 1
    }

    fun hasWake(s: String): Boolean = s.split(Regex("\\s+")).any { isWake(it) }

    fun stripWake(s: String): String {
        val words = s.trim().split(Regex("\\s+"))
        val out = ArrayList<String>()
        for (w in words) {
            if (isWake(w)) {
                if (out.isNotEmpty() && token(out.last()) in greet) out.removeAt(out.size - 1)
                continue
            }
            out.add(w)
        }
        return out.joinToString(" ").trim().trim(',', '.', '!', '?', ' ')
    }

    fun clean(s: String): String =
        s.replace("’", "'").replace(Regex("[^a-z0-9' :@.]"), " ").replace(Regex("\\s+"), " ").trim()
}

fun JSONObject.str(name: String): String = optString(name, "").trim()
