package com.vamos.helios

import android.Manifest
import android.app.ActivityManager
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tous les « bras » de HELIOS. Chaque outil est déclaré à Gemini (fonctions) et exécuté ici.
 * Les résultats sont des phrases courtes que Gemini relit et reformule.
 */
object Tools {

    // ---------- Déclarations pour Gemini ----------

    private fun p(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)

    private fun fn(name: String, desc: String, props: List<Triple<String, String, String>> = emptyList(), req: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val ps = JSONObject()
            for ((k, t, d) in props) ps.put(k, p(t, d))
            val schema = JSONObject().put("type", "OBJECT").put("properties", ps)
            if (req.isNotEmpty()) schema.put("required", JSONArray(req))
            o.put("parameters", schema)
        }
        return o
    }

    fun declarations(): JSONArray {
        val a = JSONArray()
        a.put(fn("open_app", "Ouvre une application installée par son nom (WhatsApp, Chrome, YouTube, Appareil photo, Paramètres...).", listOf(Triple("name", "STRING", "Nom de l'application")), listOf("name")))
        a.put(fn("list_apps", "Liste les applications installées (filtrables).", listOf(Triple("filter", "STRING", "Mot à chercher, optionnel"))))
        a.put(fn("call", "Appelle un contact (par son nom) ou un numéro.", listOf(Triple("target", "STRING", "Nom du contact ou numéro")), listOf("target")))
        a.put(fn("send_sms", "Envoie un SMS. DEMANDER D'ABORD CONFIRMATION à l'utilisateur, puis appeler avec confirmed=true.", listOf(Triple("to", "STRING", "Nom du contact ou numéro"), Triple("message", "STRING", "Texte du SMS"), Triple("confirmed", "BOOLEAN", "true uniquement si l'utilisateur a confirmé")), listOf("to", "message")))
        a.put(fn("whatsapp", "Ouvre une discussion WhatsApp avec un contact/numéro, avec un message pré-rempli (l'envoi final se fait avec click_text 'Envoyer' si l'utilisateur le demande).", listOf(Triple("to", "STRING", "Nom du contact ou numéro"), Triple("message", "STRING", "Message pré-rempli, optionnel")), listOf("to")))
        a.put(fn("open_url", "Ouvre une adresse web dans le navigateur.", listOf(Triple("url", "STRING", "Adresse")), listOf("url")))
        a.put(fn("web_search", "Lance une recherche Google dans le navigateur.", listOf(Triple("query", "STRING", "Recherche")), listOf("query")))
        a.put(fn("navigate", "Ouvre Google Maps avec un itinéraire vers une destination.", listOf(Triple("destination", "STRING", "Lieu")), listOf("destination")))
        a.put(fn("set_alarm", "Programme une alarme à une heure précise (format 24 h).", listOf(Triple("hour", "INTEGER", "Heure 0-23"), Triple("minute", "INTEGER", "Minute 0-59"), Triple("label", "STRING", "Nom de l'alarme")), listOf("hour", "minute")))
        a.put(fn("set_timer", "Lance un minuteur.", listOf(Triple("seconds", "INTEGER", "Durée en secondes"), Triple("label", "STRING", "Nom")), listOf("seconds")))
        a.put(fn("flashlight", "Allume ou éteint la lampe torche.", listOf(Triple("on", "BOOLEAN", "true = allumer")), listOf("on")))
        a.put(fn("volume", "Règle le volume multimédia : action = up, down, mute, set (avec level 0-100).", listOf(Triple("action", "STRING", "up | down | mute | set"), Triple("level", "INTEGER", "0-100 pour set")), listOf("action")))
        a.put(fn("media", "Commande la lecture : play_pause, next, previous.", listOf(Triple("action", "STRING", "play_pause | next | previous")), listOf("action")))
        a.put(fn("open_settings", "Ouvre un écran de réglages : wifi, internet, bluetooth, display, sound, volume, battery, storage, apps, accessibility, location, airplane, nfc, date, language, developer, hotspot, settings.", listOf(Triple("panel", "STRING", "Nom du réglage")), listOf("panel")))
        a.put(fn("diagnostic", "Diagnostic réel du téléphone : batterie, température, stockage, mémoire, réseau, modèle, état des autorisations de HELIOS."))
        a.put(fn("time", "Donne la date et l'heure actuelles."))
        a.put(fn("read_screen", "Lit les éléments visibles à l'écran (texte, boutons, champs) avec leur position. À utiliser avant de cliquer."))
        a.put(fn("look_at_screen", "Prend une capture d'écran et la fait analyser visuellement (images, vidéos, mises en page).", listOf(Triple("question", "STRING", "Ce qu'il faut regarder ou répondre")), listOf("question")))
        a.put(fn("click_text", "Appuie sur l'élément de l'écran portant ce texte (bouton, onglet, contact...).", listOf(Triple("text", "STRING", "Texte exact ou approché")), listOf("text")))
        a.put(fn("tap", "Appuie à des coordonnées de l'écran (utiliser les @x,y de read_screen).", listOf(Triple("x", "INTEGER", "x"), Triple("y", "INTEGER", "y")), listOf("x", "y")))
        a.put(fn("scroll", "Fait défiler l'écran : down (voir la suite), up, left, right.", listOf(Triple("direction", "STRING", "down | up | left | right")), listOf("direction")))
        a.put(fn("type_text", "Écrit du texte dans le champ de saisie actif.", listOf(Triple("text", "STRING", "Texte à écrire")), listOf("text")))
        a.put(fn("press", "Geste système : back, home, recents, notifications, quick_settings, lock, screenshot, power.", listOf(Triple("key", "STRING", "Nom du geste")), listOf("key")))
        a.put(fn("read_notifications", "Lit les dernières notifications reçues."))
        a.put(fn("clipboard", "Copie un texte dans le presse-papiers (action=set).", listOf(Triple("action", "STRING", "set"), Triple("text", "STRING", "Texte")), listOf("action")))
        a.put(fn("note", "Gère les notes de HELIOS : action = add, list, clear.", listOf(Triple("action", "STRING", "add | list | clear"), Triple("text", "STRING", "Texte de la note")), listOf("action")))
        a.put(fn("set_language", "Change la langue d'écoute et de réponse : fr ou sw (swahili).", listOf(Triple("lang", "STRING", "fr | sw")), listOf("lang")))
        a.put(fn("voice_access", "Ouvre l'application Google Voice Access si elle est installée (sinon sa page de téléchargement)."))
        return a
    }

    // ---------- Exécution ----------

    fun execute(ctx: Context, name: String, a: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> openApp(ctx, a.str("name"))
                "list_apps" -> listApps(ctx, a.str("filter"))
                "call" -> call(ctx, a.str("target"))
                "send_sms" -> sendSms(ctx, a.str("to"), a.str("message"), a.optBoolean("confirmed", false))
                "whatsapp" -> whatsapp(ctx, a.str("to"), a.str("message"))
                "open_url" -> openUrl(ctx, a.str("url"))
                "web_search" -> openUrl(ctx, "https://www.google.com/search?q=" + Uri.encode(a.str("query")))
                "navigate" -> navigate(ctx, a.str("destination"))
                "set_alarm" -> setAlarm(ctx, a.optInt("hour", 7), a.optInt("minute", 0), a.str("label"))
                "set_timer" -> setTimer(ctx, a.optInt("seconds", 60), a.str("label"))
                "flashlight" -> flashlight(ctx, a.optBoolean("on", true))
                "volume" -> volume(ctx, a.str("action"), a.optInt("level", -1))
                "media" -> media(ctx, a.str("action"))
                "open_settings" -> openSettings(ctx, a.str("panel"))
                "diagnostic" -> diagnostic(ctx)
                "time" -> now()
                "read_screen" -> a11y { it.dump() }
                "look_at_screen" -> lookAtScreen(ctx, a.str("question"))
                "click_text" -> a11yBool("Touché : ${a.str("text")}", "Élément introuvable à l'écran : ${a.str("text")}") { it.clickText(a.str("text")) }
                "tap" -> a11yBool("Appui effectué.", "Appui impossible.") { it.tap(a.optDouble("x").toFloat(), a.optDouble("y").toFloat()) }
                "scroll" -> a11yBool("Défilement effectué.", "Défilement impossible.") { it.scroll(a.str("direction")) }
                "type_text" -> a11yBool("Texte saisi.", "Aucun champ de saisie actif. Appuyez d'abord sur le champ.") { it.typeText(a.str("text")) }
                "press" -> a11yBool("Geste ${a.str("key")} effectué.", "Geste impossible.") { it.press(a.str("key")) }
                "read_notifications" -> readNotifications(ctx)
                "clipboard" -> clipboard(ctx, a.str("text"))
                "note" -> note(ctx, a.str("action"), a.str("text"))
                "set_language" -> setLanguage(ctx, a.str("lang"))
                "voice_access" -> voiceAccess(ctx)
                else -> "Outil inconnu : $name"
            }
        } catch (t: Throwable) {
            "Erreur ($name) : ${t.message ?: t.javaClass.simpleName}"
        }
    }

    // ---------- Aides ----------

    /** Lance une activité avec le contexte le plus « autorisé » (le service d'accessibilité peut ouvrir des applis en arrière-plan). */
    fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = HeliosAccessibilityService.instance ?: ctx
        c.startActivity(i)
    }

    private fun a11y(f: (HeliosAccessibilityService) -> String): String {
        val s = HeliosAccessibilityService.instance
            ?: return "Le service d'accessibilité de HELIOS n'est pas activé. Il faut l'activer dans Réglages, Accessibilité."
        return f(s)
    }

    private fun a11yBool(ok: String, ko: String, f: (HeliosAccessibilityService) -> Boolean): String {
        val s = HeliosAccessibilityService.instance
            ?: return "Le service d'accessibilité de HELIOS n'est pas activé. Il faut l'activer dans Réglages, Accessibilité."
        val r = f(s)
        if (r) Thread.sleep(350)
        return if (r) ok else ko
    }

    private fun granted(ctx: Context, perm: String) =
        ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    // ---------- Applications ----------

    private val aliases = mapOf(
        "camera" to listOf("appareil photo", "camera"),
        "photo" to listOf("appareil photo", "galerie", "photos"),
        "galerie" to listOf("galerie", "photos", "gallery"),
        "telephone" to listOf("telephone", "phone", "appels"),
        "appels" to listOf("telephone", "phone"),
        "parametres" to listOf("parametres", "reglages", "settings"),
        "reglages" to listOf("parametres", "reglages", "settings"),
        "horloge" to listOf("horloge", "clock", "alarme"),
        "calculatrice" to listOf("calculatrice", "calculator"),
        "internet" to listOf("chrome", "navigateur", "internet"),
        "navigateur" to listOf("chrome", "navigateur", "internet"),
        "sms" to listOf("messages", "sms"),
        "message" to listOf("messages", "sms"),
        "musique" to listOf("musique", "music", "youtube music", "spotify"),
        "plays store" to listOf("play store"),
        "playstore" to listOf("play store"),
        "watsap" to listOf("whatsapp"),
        "whatsap" to listOf("whatsapp"),
        "fesbouk" to listOf("facebook"),
        "face book" to listOf("facebook")
    )

    private data class AppEntry(val label: String, val norm: String, val pkg: String)

    private fun apps(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map {
            val l = it.loadLabel(pm).toString()
            AppEntry(l, Text.strip(l), it.activityInfo.packageName)
        }.distinctBy { it.pkg }
    }

    private fun bestApp(ctx: Context, name: String): AppEntry? {
        val q = Text.strip(name).trim()
        if (q.isEmpty()) return null
        val queries = (aliases[q] ?: emptyList()) + q
        var best: AppEntry? = null
        var bestScore = 0
        for (app in apps(ctx)) {
            for (qq in queries) {
                val s = Text.similarity(app.norm, Text.strip(qq))
                if (s > bestScore) {
                    bestScore = s
                    best = app
                }
            }
        }
        return if (bestScore >= 55) best else null
    }

    fun openApp(ctx: Context, name: String): String {
        val app = bestApp(ctx, name) ?: return "Je ne trouve aucune application nommée $name."
        val i = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return "Impossible de lancer ${app.label}."
        launch(ctx, i)
        Thread.sleep(900)
        return "${app.label} ouverte."
    }

    private fun listApps(ctx: Context, filter: String): String {
        val f = Text.strip(filter)
        val l = apps(ctx).filter { f.isEmpty() || it.norm.contains(f) }.map { it.label }.sorted()
        return if (l.isEmpty()) "Aucune application trouvée." else l.take(60).joinToString(", ") + (if (l.size > 60) " ... (${l.size} au total)" else "")
    }

    // ---------- Contacts, appels, messages ----------

    private fun digits(s: String) = s.filter { it.isDigit() || it == '+' }

    private fun looksLikeNumber(s: String) = s.count { it.isDigit() } >= 5 && s.all { it.isDigit() || it in "+ -.()" }

    /** Cherche un contact par nom (tolérant aux erreurs de reconnaissance). Renvoie (nom, numéro). */
    private fun contact(ctx: Context, name: String): Pair<String, String>? {
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return null
        val q = Text.strip(name).trim()
        var best: Pair<String, String>? = null
        var bestScore = 0
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val s = Text.similarity(Text.strip(n), q)
                if (s > bestScore) {
                    bestScore = s
                    best = n to num
                }
            }
        }
        return if (bestScore >= 60) best else null
    }

    private fun normalizeIntl(ctx: Context, raw: String): String {
        var d = digits(raw).removePrefix("+")
        if (d.startsWith("00")) d = d.substring(2)
        else if (d.startsWith("0")) d = Prefs.cc(ctx) + d.substring(1)
        return d
    }

    private fun call(ctx: Context, target: String): String {
        val found: Pair<String, String> = if (looksLikeNumber(target)) Pair(target, digits(target))
        else contact(ctx, target) ?: return if (!granted(ctx, Manifest.permission.READ_CONTACTS))
            "L'autorisation Contacts n'est pas accordée à HELIOS."
        else "Je ne trouve pas $target dans vos contacts."
        val label = found.first
        val number = found.second
        val uri = Uri.parse("tel:" + Uri.encode(number))
        return if (granted(ctx, Manifest.permission.CALL_PHONE)) {
            launch(ctx, Intent(Intent.ACTION_CALL, uri))
            "Appel de $label en cours."
        } else {
            launch(ctx, Intent(Intent.ACTION_DIAL, uri))
            "Numéro de $label prêt à composer (autorisation Appels non accordée)."
        }
    }

    private fun sendSms(ctx: Context, dest: String, msg: String, confirmed: Boolean): String {
        if (!confirmed) return "CONFIRMATION_REQUISE : demande à l'utilisateur de confirmer le SMS à $dest : « $msg ». Rappelle ensuite send_sms avec confirmed=true."
        if (!granted(ctx, Manifest.permission.SEND_SMS)) return "L'autorisation SMS n'est pas accordée à HELIOS."
        val found: Pair<String, String> = if (looksLikeNumber(dest)) Pair(dest, digits(dest))
        else contact(ctx, dest) ?: return "Je ne trouve pas $dest dans vos contacts."
        val label = found.first
        val number = found.second
        val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
        val parts = sm.divideMessage(msg)
        sm.sendMultipartTextMessage(digits(number), null, parts, null, null)
        return "SMS envoyé à $label."
    }

    private fun whatsapp(ctx: Context, dest: String, msg: String): String {
        val found: Pair<String, String> = if (looksLikeNumber(dest)) Pair(dest, digits(dest))
        else contact(ctx, dest) ?: return "Je ne trouve pas $dest dans vos contacts."
        val label = found.first
        val num = normalizeIntl(ctx, found.second)
        val url = "https://wa.me/$num" + if (msg.isNotEmpty()) "?text=" + Uri.encode(msg) else ""
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            i.setPackage("com.whatsapp")
            launch(ctx, i)
        } catch (_: Throwable) {
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        Thread.sleep(1200)
        return "Discussion WhatsApp avec $label ouverte."
    }

    // ---------- Web, cartes ----------

    private fun openUrl(ctx: Context, url: String): String {
        val u = if (url.startsWith("http")) url else "https://$url"
        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        Thread.sleep(900)
        return "Page ouverte : $u"
    }

    private fun navigate(ctx: Context, dest: String): String {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)))
        return try {
            i.setPackage("com.google.android.apps.maps")
            launch(ctx, i)
            "Itinéraire vers $dest lancé."
        } catch (_: Throwable) {
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest))))
            "Carte ouverte pour $dest."
        }
    }

    // ---------- Alarmes, minuteurs ----------

    private fun setAlarm(ctx: Context, h: Int, m: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h.coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, m.coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_MESSAGE, if (label.isEmpty()) "HELIOS" else label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(ctx, i)
        return "Alarme réglée à %02d:%02d.".format(h, m)
    }

    private fun setTimer(ctx: Context, s: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s.coerceAtLeast(1))
            .putExtra(AlarmClock.EXTRA_MESSAGE, if (label.isEmpty()) "HELIOS" else label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(ctx, i)
        return "Minuteur de $s secondes lancé."
    }

    // ---------- Matériel ----------

    fun flashlight(ctx: Context, on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Ce téléphone n'a pas de lampe torche accessible."
        cm.setTorchMode(id, on)
        return if (on) "Lampe allumée." else "Lampe éteinte."
    }

    fun volume(ctx: Context, action: String, level: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val st = AudioManager.STREAM_MUSIC
        when (action.lowercase()) {
            "up", "plus", "monte" -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down", "moins", "baisse" -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute", "muet" -> am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "set" -> {
                val max = am.getStreamMaxVolume(st)
                am.setStreamVolume(st, (max * level.coerceIn(0, 100) / 100), AudioManager.FLAG_SHOW_UI)
            }
            else -> return "Action de volume inconnue."
        }
        val max = am.getStreamMaxVolume(st).coerceAtLeast(1)
        return "Volume à ${am.getStreamVolume(st) * 100 / max} pour cent."
    }

    fun media(ctx: Context, action: String): String {
        val code = when (action.lowercase()) {
            "play_pause", "play", "pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next", "suivant" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "precedent" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "Commande média inconnue."
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Commande média envoyée."
    }

    fun openSettings(ctx: Context, panel: String): String {
        val act = when (panel.lowercase()) {
            "wifi", "wi-fi" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
            "internet", "data", "mobile" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
            "volume" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_VOLUME else Settings.ACTION_SOUND_SETTINGS
            "nfc" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_NFC else Settings.ACTION_NFC_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display", "ecran", "luminosite" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "son" -> Settings.ACTION_SOUND_SETTINGS
            "battery", "batterie" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "storage", "stockage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "apps", "applications" -> Settings.ACTION_APPLICATION_SETTINGS
            "accessibility", "accessibilite" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "location", "localisation", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane", "avion" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "language", "langue" -> Settings.ACTION_LOCALE_SETTINGS
            "developer", "developpeur" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            "hotspot", "partage" -> Settings.ACTION_WIRELESS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        launch(ctx, Intent(act))
        Thread.sleep(700)
        return "Réglages « $panel » ouverts."
    }

    // ---------- Diagnostic ----------

    fun diagnostic(ctx: Context): String {
        val sb = StringBuilder()
        // Batterie
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            sb.append("Batterie ${lvl * 100 / sc} pour cent${if (chg) ", en charge" else ""}, température ${"%.1f".format(temp)} degrés. ")
        }
        // Stockage
        try {
            val s = StatFs(Environment.getDataDirectory().path)
            val free = s.availableBytes / 1_073_741_824.0
            val tot = s.totalBytes / 1_073_741_824.0
            sb.append("Stockage libre ${"%.1f".format(free)} giga sur ${"%.0f".format(tot)}. ")
        } catch (_: Throwable) {
        }
        // Mémoire vive
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            sb.append("Mémoire vive libre ${mi.availMem / 1_048_576} méga sur ${mi.totalMem / 1_048_576}. ")
        } catch (_: Throwable) {
        }
        // Réseau
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val net = when {
                caps == null -> "aucun réseau"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "données mobiles"
                else -> "autre réseau"
            }
            sb.append("Réseau : $net. ")
        } catch (_: Throwable) {
        }
        sb.append("Appareil ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}, allumé depuis ${SystemClock.elapsedRealtime() / 3_600_000} heures. ")
        sb.append("Accessibilité HELIOS : ${if (HeliosAccessibilityService.instance != null) "active" else "inactive"}. ")
        sb.append("Micro : ${if (granted(ctx, Manifest.permission.RECORD_AUDIO)) "autorisé" else "non autorisé"}.")
        return sb.toString()
    }

    fun now(): String =
        SimpleDateFormat("EEEE d MMMM yyyy 'à' HH'h'mm", Locale.FRANCE).format(Date())

    // ---------- Écran (accessibilité + vision Gemini) ----------

    private fun lookAtScreen(ctx: Context, question: String): String {
        val s = HeliosAccessibilityService.instance
            ?: return "Le service d'accessibilité de HELIOS n'est pas activé."
        val jpg = s.screenshotJpeg() ?: return "Capture d'écran impossible (Android 11 minimum et accessibilité requises)."
        if (!Net.online(ctx)) return "Pas d'Internet pour analyser l'image."
        return Gemini.askWithImage(ctx, jpg, question.ifEmpty { "Décris ce qui est affiché à l'écran." })
    }

    private fun readNotifications(ctx: Context): String {
        val l = HeliosNotificationListener.latest(8)
        return if (l.isEmpty()) "Aucune notification récente (ou accès aux notifications non activé pour HELIOS)." else l.joinToString(" | ")
    }

    private fun clipboard(ctx: Context, text: String): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("helios", text))
        return "Texte copié."
    }

    private fun note(ctx: Context, action: String, text: String): String {
        val n = Prefs.notes(ctx)
        return when (action.lowercase()) {
            "add" -> {
                n.put(text)
                Prefs.saveNotes(ctx, n)
                "Note enregistrée."
            }
            "list" -> if (n.length() == 0) "Aucune note." else (0 until n.length()).joinToString(" ; ") { "${it + 1}. ${n.getString(it)}" }
            "clear" -> {
                Prefs.saveNotes(ctx, JSONArray())
                "Notes effacées."
            }
            else -> "Action de note inconnue."
        }
    }

    private fun setLanguage(ctx: Context, lang: String): String {
        val l = if (lang.lowercase().startsWith("sw")) "sw" else "fr"
        Prefs.setLang(ctx, l)
        HeliosService.instance?.restartEars()
        return if (l == "sw") "Lugha imebadilishwa kuwa Kiswahili." else "Langue réglée sur le français."
    }

    private fun voiceAccess(ctx: Context): String {
        val pkg = "com.google.android.apps.accessibility.voiceaccess"
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        return if (i != null) {
            launch(ctx, i)
            "Voice Access ouvert."
        } else {
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
            "Voice Access n'est pas installé : page de téléchargement ouverte."
        }
    }
}
