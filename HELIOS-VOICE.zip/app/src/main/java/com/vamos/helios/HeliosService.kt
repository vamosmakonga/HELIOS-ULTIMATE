package com.vamos.helios

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/**
 * Cœur de HELIOS : service de premier plan (micro) qui écoute en continu, même écran éteint ou téléphone posé,
 * attend « Helios », comprend, agit puis répond à voix haute.
 */
class HeliosService : Service(), Ears.Callback {

    companion object {
        @Volatile
        var instance: HeliosService? = null

        const val CHANNEL = "helios_listen"
        const val WINDOW_MS = 30_000L

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, HeliosService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, HeliosService::class.java))
        }
    }

    private lateinit var voice: Voice
    private var ears: Ears? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var wake: PowerManager.WakeLock? = null

    @Volatile
    private var convUntil = 0L

    @Volatile
    private var busy = false

    @Volatile
    private var turn = 0

    private var lastLevelEmit = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Bus.emit("error", "Autorisez d'abord le microphone, puis relancez HELIOS.")
            stopSelf()
            return
        }
        instance = this
        createChannel()
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (t: Throwable) {
            Bus.emit("error", "Impossible de démarrer l'écoute : ${t.message}")
            stopSelf()
            return
        }
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "helios:listen").also { it.acquire(12 * 60 * 60 * 1000L) }
        } catch (_: Throwable) {
        }
        voice = Voice(this, { ears?.muted = true }, { finishTurn() })
        startEars()
        Bus.setState("listening")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        try {
            ears?.stop()
        } catch (_: Throwable) {
        }
        try {
            voice.shutdown()
        } catch (_: Throwable) {
        }
        try {
            wake?.takeIf { it.isHeld }?.release()
        } catch (_: Throwable) {
        }
        worker.shutdownNow()
        Bus.setState("idle")
        super.onDestroy()
    }

    // ---------- Écoute ----------

    fun restartEars() {
        worker.execute {
            try {
                ears?.stop()
            } catch (_: Throwable) {
            }
            startEars()
        }
    }

    private fun startEars() {
        val lang = Prefs.lang(this)
        var e: Ears? = null
        if (lang == "fr") {
            e = try {
                SherpaEars(this, this).takeIf { it.init() }
            } catch (t: Throwable) {
                null
            }
        }
        if (e == null) e = AndroidEars(this, this, lang)
        ears = e
        e.start()
        Bus.emit("engine", e.name)
    }

    override fun onLevel(l: Float) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastLevelEmit > 120) {
            lastLevelEmit = now
            Bus.emit("level", l.toString())
        }
    }

    override fun onPartial(t: String) {
        Bus.emit("partial", t)
    }

    override fun onProblem(msg: String) {
        Bus.emit("error", msg)
    }

    override fun onFinal(t: String) {
        val raw = t.trim()
        if (raw.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        val inConversation = now < convUntil
        if (!Text.hasWake(raw) && !inConversation) {
            Bus.emit("ignored", raw)
            return
        }
        if (busy) {
            Bus.emit("ignored", raw)
            return
        }
        val cmd = Text.stripWake(raw)
        Bus.emit("heard", raw)
        if (cmd.isBlank()) {
            busy = true
            reply("Oui, je vous écoute.")
            return
        }
        run(cmd)
    }

    /** Commande tapée au clavier depuis l'interface (sans mot de réveil). */
    fun typed(text: String) {
        if (busy) return
        Bus.emit("heard", text)
        run(text.trim())
    }

    private fun run(cmd: String) {
        busy = true
        Bus.setState("thinking")
        worker.execute {
            val answer = try {
                Brain.handle(this, cmd)
            } catch (t: Throwable) {
                "Une erreur est survenue : ${t.message ?: t.javaClass.simpleName}"
            }
            reply(answer)
        }
    }

    // ---------- Réponse vocale ----------

    fun reply(text: String) {
        if (text.isBlank()) {
            finishTurn()
            return
        }
        Bus.emit("reply", text)
        Bus.setState("speaking")
        ears?.muted = true
        val myTurn = ++turn
        voice.speak(text, Prefs.lang(this))
        // filet de sécurité si la synthèse ne signale jamais la fin
        main.postDelayed({ if (busy && turn == myTurn) finishTurn() }, 15_000L + text.length * 90L)
    }

    fun silence() {
        voice.stop()
    }

    private fun finishTurn() {
        ears?.muted = false
        convUntil = SystemClock.elapsedRealtime() + WINDOW_MS
        busy = false
        Bus.setState("listening")
    }

    // ---------- Notification ----------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "HELIOS à l'écoute", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, HeliosService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("HELIOS est à l'écoute")
            .setContentText("Dites « Helios » suivi de votre demande")
            .setContentIntent(open)
            .addAction(0, "Arrêter", stop)
            .setOngoing(true)
            .build()
    }
}
