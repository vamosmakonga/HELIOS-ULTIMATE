(() => {
  'use strict';
  const STORAGE_KEY = 'helios.pwa.local.v1';
  const SETTINGS_KEY = 'helios.pwa.settings.v1';
  const HISTORY_KEY = 'helios.pwa.history.v1';
  const $ = (id) => document.getElementById(id);
  const safeParse = (value, fallback) => { try { return JSON.parse(value) ?? fallback; } catch (_) { return fallback; } };
  let state = safeParse(localStorage.getItem(STORAGE_KEY), { notes: [], tasks: [] });
  let settings = safeParse(localStorage.getItem(SETTINGS_KEY), { endpoint: '', token: '' });
  let history = safeParse(localStorage.getItem(HISTORY_KEY), []);

  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    render();
  }
  function render() {
    $('noteCount').textContent = state.notes.length;
    $('taskCount').textContent = state.tasks.length;
    renderList('notesList', state.notes, 'notes');
    renderList('tasksList', state.tasks, 'tasks');
  }
  function renderList(id, values, type) {
    const list = $(id);
    list.replaceChildren();
    if (!values.length) {
      const empty = document.createElement('li');
      empty.className = 'empty';
      empty.textContent = type === 'notes' ? 'Aucune note pour le moment.' : 'Aucune tâche pour le moment.';
      list.appendChild(empty);
      return;
    }
    values.slice(-20).reverse().forEach((item, reverseIndex) => {
      const originalIndex = values.length - 1 - reverseIndex;
      const li = document.createElement('li');
      const text = document.createElement('span');
      text.textContent = item;
      const remove = document.createElement('button');
      remove.type = 'button'; remove.className = 'remove'; remove.textContent = '×';
      remove.setAttribute('aria-label', 'Supprimer');
      remove.addEventListener('click', () => {
        state[type].splice(originalIndex, 1);
        persist();
      });
      li.append(text, remove); list.appendChild(li);
    });
  }
  function addItem(type, text) {
    const clean = String(text || '').trim();
    if (!clean) return;
    state[type].push(clean);
    persist();
  }
  function answer(text) { $('response').textContent = text; speak(text); }
  function speak(text) {
    if (!('speechSynthesis' in window)) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'fr-FR'; utterance.rate = 0.94;
    const voice = speechSynthesis.getVoices().find((v) => v.lang.toLowerCase().startsWith('fr'));
    if (voice) utterance.voice = voice;
    speechSynthesis.cancel(); speechSynthesis.speak(utterance);
  }
  async function askRemote(command) {
    if (!settings.endpoint) return false;
    try {
      const headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
      if (settings.token) headers.Authorization = `Bearer ${settings.token}`;
      const response = await fetch(settings.endpoint, { method: 'POST', headers, body: JSON.stringify({ message: command, history: history.slice(-20) }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || `Erreur HTTP ${response.status}`);
      const reply = body.reply || 'Le serveur a renvoyé une réponse vide.';
      history.push({ role: 'user', content: command }, { role: 'assistant', content: reply });
      history = history.slice(-20);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
      answer(reply);
    } catch (error) { answer(`Le moteur IA distant est indisponible : ${error.message}\nLes outils locaux restent actifs.`); }
    return true;
  }
  async function command(text) {
    const input = String(text || '').trim();
    const value = input.toLocaleLowerCase('fr-FR');
    if (!input) return;
    if (value.startsWith('note ')) { addItem('notes', input.slice(5)); answer('Note enregistrée localement.'); return; }
    if (value.startsWith('tâche ') || value.startsWith('tache ')) { addItem('tasks', input.slice(input.indexOf(' ') + 1)); answer('Tâche ajoutée à votre liste locale.'); return; }
    if (value.includes('mes notes')) { answer(state.notes.length ? 'Vos notes :\n' + state.notes.slice(-10).map((x) => '• ' + x).join('\n') : 'Vous n’avez pas encore de note.'); return; }
    if (value.includes('mes tâches') || value.includes('mes taches')) { answer(state.tasks.length ? 'Vos tâches :\n' + state.tasks.slice(-10).map((x) => '• ' + x).join('\n') : 'Votre liste de tâches est vide.'); return; }
    if (value.includes('quelle heure') || value.includes('donne l’heure') || value.includes("donne l'heure")) { answer(`Il est ${new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' }).format(new Date())}.`); return; }
    if (value.includes('quelle date') || value.includes('quel jour')) { answer(`Nous sommes le ${new Intl.DateTimeFormat('fr-FR', { dateStyle: 'full' }).format(new Date())}.`); return; }
    if (value === 'bonjour' || value.includes('bonjour helios') || value === 'salut') { answer('Bonjour. HELIOS est prêt. Que puis-je faire pour vous ?'); return; }
    if (value === 'aide' || value.includes('commandes')) { answer('Commandes hors ligne : « quelle heure », « quelle date », « note ... », « tâche ... », « mes notes », « mes tâches ». Les autres demandes passent au moteur IA si un serveur est configuré.'); return; }
    if (await askRemote(input)) return;
    answer('Cette demande nécessite le moteur IA distant. Configurez un serveur HELIOS dans la section Connectivité. En attendant, les notes, tâches et commandes locales restent utilisables hors ligne.');
  }

  $('commandForm').addEventListener('submit', (event) => { event.preventDefault(); const value = $('commandInput').value; $('commandInput').value = ''; command(value); });
  $('clearHistory').addEventListener('click', () => { history = []; localStorage.removeItem(HISTORY_KEY); answer('Mémoire de conversation IA effacée sur cet appareil.'); });
  $('noteForm').addEventListener('submit', (event) => { event.preventDefault(); addItem('notes', $('noteInput').value); $('noteInput').value = ''; });
  $('taskForm').addEventListener('submit', (event) => { event.preventDefault(); addItem('tasks', $('taskInput').value); $('taskInput').value = ''; });
  $('voiceButton').addEventListener('click', () => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) { answer('La reconnaissance vocale n’est pas disponible dans ce navigateur. Utilisez le clavier ou l’application Android.'); return; }
    const recognition = new Recognition(); recognition.lang = 'fr-FR'; recognition.interimResults = false; recognition.maxAlternatives = 1;
    $('connectionLabel').textContent = 'Microphone actif';
    recognition.onresult = (event) => { const text = event.results[0][0].transcript; $('commandInput').value = text; command(text); };
    recognition.onerror = () => { answer('La reconnaissance vocale a échoué. Vérifiez les permissions du microphone.'); };
    recognition.onend = () => { $('connectionLabel').textContent = 'Mode local prêt'; };
    try { recognition.start(); } catch (_) { answer('Le microphone est déjà utilisé ou indisponible.'); }
  });
  $('exportButton').addEventListener('click', () => {
    const data = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), ...state }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(data); const link = document.createElement('a'); link.href = url; link.download = 'helios-sauvegarde.json'; link.click(); URL.revokeObjectURL(url);
  });
  $('saveSettings').addEventListener('click', () => {
    const endpoint = $('apiEndpoint').value.trim();
    if (endpoint && !endpoint.startsWith('https://')) { $('syncStatus').textContent = 'Utilisez une adresse HTTPS pour protéger les échanges.'; return; }
    settings = { endpoint, token: $('apiToken').value.trim() };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    $('syncStatus').textContent = endpoint ? 'Configuration enregistrée sur cet appareil.' : 'Mode local uniquement.';
  });
  $('syncButton').addEventListener('click', async () => {
    if (!settings.endpoint) { $('syncStatus').textContent = 'Configurez d’abord le serveur PHP fourni dans server/. L’endpoint de synchronisation sera /api/sync.php.'; return; }
    const endpoint = settings.endpoint.replace(/assistant\.php(?:\?.*)?$/, 'sync.php');
    $('syncStatus').textContent = 'Synchronisation en cours…';
    try {
      const headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
      if (settings.token) headers.Authorization = `Bearer ${settings.token}`;
      const response = await fetch(endpoint, { method: 'POST', headers, body: JSON.stringify({ data: state }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
      if (body.data && Array.isArray(body.data.notes) && Array.isArray(body.data.tasks)) {
        state = body.data; persist();
      }
      $('syncStatus').textContent = 'Synchronisation terminée.';
    } catch (error) { $('syncStatus').textContent = `Synchronisation impossible : ${error.message}`; }
  });

  $('apiEndpoint').value = settings.endpoint || '';
  $('apiToken').value = settings.token || '';
  render();
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
})();
