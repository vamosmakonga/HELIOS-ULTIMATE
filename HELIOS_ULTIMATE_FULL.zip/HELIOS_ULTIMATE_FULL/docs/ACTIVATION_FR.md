# HELIOS 2.0 — Activer l'écoute mains libres et le contrôle du téléphone

## Ce qui a été corrigé dans cette version
- **Seul « ouvre WhatsApp » marchait** : depuis Android 11, une application ne voit pas les autres applications sauf si elle les déclare. Le manifeste déclare maintenant les actions nécessaires (appel, SMS, e-mail, cartes, recherche, caméra, alarmes, calendrier, réglages, YouTube…) et HELIOS ne bloque plus l'action avant d'essayer.
- **Accessibilité introuvable** : l'ancienne version ne contenait aucun service d'accessibilité, donc rien à activer. Il existe maintenant : « HELIOS – contrôle du téléphone ».
- **Micro qui s'arrête** : la reconnaissance vocale vivait dans l'écran de l'application. Elle tourne maintenant dans un service au premier plan (notification permanente) qui continue écran éteint.

> Problème d'installation ? Voir `docs/INSTALLATION_FR.md`.

## Mise en route (dans cet ordre)
1. Installez l'APK, ouvrez HELIOS.
2. Appuyez sur **🎧 ÉCOUTE MAINS LIBRES** et acceptez le micro et les notifications.
3. Centre de commande → **🔋 Autoriser HELIOS en arrière-plan** → « Autoriser ».
4. Centre de commande → **♿ Activer l'accessibilité** → HELIOS – contrôle du téléphone → activer.
   - Si c'est grisé ou « Paramètre restreint » : bouton **🔓 Accessibilité grisée…** → Infos de l'appli → menu ⋮ (trois points en haut à droite) → **Autoriser les paramètres restreints** → revenez activer l'accessibilité.
5. Centre de commande → **🪟 Autoriser l'affichage par-dessus les autres apps** (aide à ouvrir des applications quand HELIOS est en arrière-plan).
6. Centre de commande → **🩺 Diagnostic** : tout doit être coché ✔.

## Téléphones Tecno / Infinix / itel (HiOS, XOS)
Ces systèmes ferment les applications en arrière-plan. Faites ces réglages, sinon l'écoute s'arrête après quelques minutes :
- Applications récentes : verrouillez HELIOS (cadenas ou « Verrouiller »).
- Paramètres → Applications → HELIOS → Batterie → **Sans restriction**.
- Gestionnaire du téléphone → Démarrage automatique → HELIOS activé.
- Désactivez l'économiseur de batterie agressif (Power Marathon / Économie intelligente).

## Reconnaissance vocale
- Il faut l'application **Google** (reconnaissance vocale Google) installée et à jour.
- Pour le français hors ligne : Paramètres → Google → Paramètres des applications Google → Recherche, assistant et voix → Voix → Reconnaissance vocale hors ligne → télécharger Français.
- Sans Internet ni pack hors ligne, la reconnaissance ne peut pas fonctionner : c'est une limite d'Android.

## Comment parler
- « **Bonjour HELIOS**, quelle heure est-il ? » (tout dans la même phrase)
- ou « Bonjour HELIOS » → « Oui ? Je vous écoute. » → votre commande.
- Après une réponse, HELIOS reste attentif 10 secondes : pas besoin de redire son nom.
- HELIOS tolère les erreurs de transcription (« hélio », « elios », « Éliot »…).
- « Arrête l'écoute » coupe le micro. « Langue swahili » / « langue français » change la langue d'écoute.

## Commandes de contrôle du téléphone (accessibilité activée)
retour • accueil • applications récentes • ouvre les notifications • paramètres rapides • verrouille l'écran • capture d'écran •
clique sur [texte affiché] • écris [texte] (dans le champ sélectionné) • défile vers le bas / le haut • lis l'écran • quelle application est ouverte

HELIOS n'écrit jamais dans un champ de mot de passe et n'agit que sur commande vocale ou écrite.

## Limites honnêtes
- Android affiche un point vert quand le micro est utilisé : c'est normal et non désactivable.
- Ouvrir une application depuis l'arrière-plan peut être bloqué par Android ou par la surcouche du fabricant ; l'autorisation « par-dessus les autres apps » aide mais ne garantit rien sur tous les modèles.
- Écran verrouillé par code : HELIOS entend, mais Android peut refuser d'ouvrir certaines applications avant déverrouillage.
- Cette version est un assistant à commandes, pas une IA qui comprend tout seul. Pour une vraie conversation, configurez le serveur IA (Centre de commande).
