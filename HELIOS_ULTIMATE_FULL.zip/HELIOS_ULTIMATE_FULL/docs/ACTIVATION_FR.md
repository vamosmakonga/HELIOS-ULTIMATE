# HELIOS 2.1 — Voix, actions et écoute en arrière-plan

> Problème d'installation ? Voir `docs/INSTALLATION_FR.md`. Cette version garde le même identifiant et la même signature que la 2.0 : elle s'installe **par-dessus** sans rien perdre.

## Ce qui a été corrigé
- **HELIOS ne parlait pas** : le manifeste ne déclarait pas le moteur de synthèse vocale. Depuis Android 11, sans cette déclaration la voix ne démarre pas. C'est corrigé. De plus, HELIOS essaie maintenant le moteur par défaut puis Google, cherche le français et, s'il manque, parle dans une autre langue en vous disant quoi installer (au lieu de se taire).
- **Il ouvrait une application sans rien faire** : HELIOS exécute maintenant de vraies actions (liste plus bas) et peut enchaîner plusieurs étapes.
- **Micro et arrière-plan** : le micro reste ouvert **30 secondes après chaque réponse** (45 s quand HELIOS attend votre « oui »), sans redire « Bonjour HELIOS ». Une **bulle réacteur flottante** reste à l'écran quand vous êtes dans une autre application.

## Mise en route (dans cet ordre)
1. Installez l'APK, ouvrez HELIOS. Centre de commande → **🔊 Tester la voix**. Vous devez entendre HELIOS. Sinon lisez « Si HELIOS ne parle pas » plus bas.
2. **🎧 Écoute mains libres** : acceptez micro et notifications.
3. Centre de commande → **📇 Autoriser contacts, appels et SMS** (pour « appelle maman »).
4. **🪟 Autoriser l'affichage par-dessus les autres apps** : affiche la bulle ET permet à HELIOS d'ouvrir des applications depuis l'arrière-plan.
5. **♿ Activer l'accessibilité** (si grisé : « 🔓 Accessibilité grisée ? » → Infos de l'appli → ⋮ → Autoriser les paramètres restreints).
6. **🔋 Autoriser HELIOS en arrière-plan** (batterie).
7. **🔔 Autoriser la lecture des notifications** (pour « lis mes notifications »).
8. **🩺 Diagnostic** : tout doit être coché ✔.

## Comment parler
Dites « **Bonjour HELIOS** » puis votre demande, dans la même phrase ou après sa réponse « Oui ? Je vous écoute ».

### Diagnostic (comme Jarvis)
« Bonjour HELIOS, **fais le diagnostic** » → HELIOS lit batterie, température, stockage, mémoire, réseau, volume, état de ses propres autorisations et vous signale ce qui ne va pas.

### Actions directes
| Dites | HELIOS fait |
|---|---|
| allume / éteins la lampe | lampe torche |
| monte / baisse le volume, volume à 50, coupe le son | volume média |
| pause, reprends, suivant, précédent | lecteur de musique/vidéo en cours |
| alarme à 6 heures 30 | règle l'alarme pour de bon |
| minuteur 10 minutes | lance le minuteur pour de bon |
| combien font 12 fois 7 | calcule et dit le résultat |
| ouvre [n'importe quelle appli] | ouvre l'application (même « TikTok », « Galerie »…) |
| va sur site.com | ouvre le site |
| cherche [sujet] sur YouTube / joue [chanson] | recherche YouTube |
| emmène-moi à [lieu] | navigation Google Maps |
| lis mes notifications | lit les dernières notifications |
| lis l'écran | lit le texte affiché |
| clique sur [texte], écris [texte], défile, retour, accueil, capture d'écran | contrôle réel de l'écran (accessibilité) |

### Appels et messages (HELIOS demande toujours « Confirmez-vous ? »)
- « appelle **maman** » → « Je vais appeler Maman. Confirmez-vous ? » → « **oui** » → l'appel démarre.
- « envoie un SMS à **Jean** : j'arrive » → confirmation → envoi.
- « envoie un message **WhatsApp** à **Jean** : bonjour » → confirmation → HELIOS ouvre la discussion et touche lui-même « Envoyer » (accessibilité requise).
- Les numéros de contacts sans « + » sont complétés avec l'indicatif **243** (RDC). Autre pays : dites « code pays 254 ».
- Répondez « non » ou « annule » pour refuser.

### Enchaîner plusieurs actions
« ouvre WhatsApp **puis** clique sur Discussions » • « ouvre YouTube **puis** attends 3 secondes **puis** capture d'écran ».
HELIOS laisse le temps à chaque application de s'ouvrir entre deux étapes. Il s'arrête si une confirmation est demandée.

## Si HELIOS ne parle pas
1. Centre de commande → **🔊 Tester la voix** : lisez la ligne d'état affichée.
2. « Voix indisponible » → installez/activez **Synthèse vocale Google** (Play Store) : bouton **🗣 Réparer / installer la voix française**.
3. « Voix française absente » → même bouton, installez les données vocales **Français**.
4. « Volume média à zéro » → montez le volume média (touches de volume pendant qu'un son joue), ou dites « volume à 70 ».
5. Paramètres Android → Gestion globale → Synthèse vocale → moteur préféré : **Google**.

## Téléphones Tecno / Infinix / itel
Verrouillez HELIOS dans les applications récentes, mettez Batterie → **Sans restriction**, activez le **démarrage automatique**, et autorisez les **fenêtres pop-up en arrière-plan** si le téléphone le propose. Sans cela, le système coupe HELIOS après quelques minutes.

## Limites honnêtes
- **Ouvrir des apps depuis l'arrière-plan** : Android le bloque sauf si HELIOS a une fenêtre visible. C'est le rôle de la bulle ; sur certaines surcouches (HiOS, XOS) il faut en plus autoriser les pop-up en arrière-plan. Si une app ne s'ouvre pas, ouvrez d'abord la bulle/HELIOS puis redonnez l'ordre.
- **Le micro n'est pas « continu » au sens strict** : Android impose de relancer la reconnaissance vocale après chaque phrase (quelques dixièmes de seconde, parfois un petit bip selon le téléphone). Une reconnaissance vraiment continue demanderait un moteur hors ligne dédié (ex. Vosk) : possible comme prochaine étape.
- La reconnaissance vocale Google exige l'application Google ; le français hors ligne exige son pack téléchargé.
- **Toucher l'écran à votre place** (WhatsApp « Envoyer », « clique sur… ») dépend du texte réellement affiché par l'application et de sa langue ; les mises à jour d'une application peuvent changer ses libellés.
- HELIOS n'écrit jamais dans un champ de mot de passe et n'appelle ou n'écrit jamais sans votre « oui ».
- Le point vert « micro actif » d'Android est normal et ne peut pas être masqué.
