# Feuille de route HELIOS

## Niveau 1 — Base fonctionnelle incluse

- Application Android native avec interface HELIOS.
- Commande vocale à la demande en français, si un service vocal est disponible.
- Synthèse vocale française avec la voix fournie par le moteur Android.
- Commandes locales : heure, date, notes, tâches, ouvrir certaines applications, paramètres, appareil photo, composeur, SMS préparé, recherche web et alarmes.
- Mémoire locale des notes, tâches et dernières commandes.
- Tableau web installable avec stockage hors ligne.
- API PHP pour conversation IA et synchronisation additive.
- Contrats et registre de modules.

## Niveau 2 — Intégrations à développer et tester

- Détection « Bonjour HELIOS » avec moteur de mot-clé local, service visible, gestion batterie et compatibilité Android.
- Voix masculine sélectionnable parmi les voix réellement installées sur le téléphone.
- Biométrie via Android BiometricPrompt.
- OCR local via ML Kit Text Recognition ou moteur équivalent ; reconnaissance d'objets avec modèle embarqué.
- Intégration complète Home Assistant avec écran de configuration, liste des appareils et confirmations pour portes/serrures.
- Automatisations multi-étapes avec aperçu et confirmation avant action.
- Calendrier, alarmes et rappels système avec permissions dédiées.
- WhatsApp : préremplissage de texte et partage par l'interface Android.
- Traduction hors ligne avec modèles téléchargés.
- Synchronisation avec gestion des conflits, suppression synchronisée et comptes multi-utilisateurs.

## Niveau 3 — Intelligence avancée

- Conversation avec historique et mémoire contrôlée par l'utilisateur.
- Analyse de documents et d'images par IA, selon les choix de confidentialité.
- Assistant de programmation avec espaces de projet et éditeur.
- Résumés, planification et automatisations personnalisées.
- Mode urgence configuré par l'utilisateur (contacts, message, localisation si autorisée) sans appeler ni envoyer en secret.
- Extensions natives signées et modules distants contrôlés.

## Critères de validation

Chaque module doit avoir une description, un statut, une liste minimale d'autorisations, un test fonctionnel, un test de refus d'autorisation, une gestion d'erreur et une procédure de désactivation.
