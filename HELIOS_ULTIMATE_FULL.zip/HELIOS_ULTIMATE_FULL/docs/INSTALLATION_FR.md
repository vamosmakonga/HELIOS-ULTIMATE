# HELIOS 2.0 — Installation de l'APK (si « Application non installée »)

## Ce qui a été corrigé
- **Nouvel identifiant d'application : `com.vamos.helios.ultimate`.** Cette version s'installe **à côté** de l'ancien HELIOS, sans conflit de signature (la cause la plus fréquente de « Application non installée »).
- **Clé de signature fixe** (`android/keystore/helios.jks`) incluse dans le projet. Désormais, chaque nouvelle version construite par GitHub porte la même signature : vous pourrez **mettre à jour sans désinstaller** et sans perdre vos notes et tâches.
- Version de compilation alignée avec GitHub Actions (SDK 35).

> La clé fournie est une clé de développement partagée dans ce projet : elle sert à garder la même signature d'une version à l'autre. Elle n'est pas adaptée à une publication sur le Play Store.

## Étapes
1. Sur GitHub : onglet **Actions** → dernier « Construire HELIOS APK » → section **Artifacts** → téléchargez `HELIOS-ULTIMATE-APK`.
2. C'est un **ZIP** : extrayez-le avec le gestionnaire de fichiers, vous obtenez `app-debug.apk` (environ 1 à 3 Mo).
3. Appuyez sur `app-debug.apk` → autorisez « Installer des applis inconnues » pour cette application (Fichiers, Chrome…) → Installer.
4. L'ancien HELIOS peut rester ; vous pouvez le désinstaller après avoir vérifié que le nouveau fonctionne. L'icône du nouveau s'appelle aussi HELIOS.

## Si ça échoue encore
- Dans les journaux de l'étape **« Vérifier l'APK »** de GitHub Actions, vérifiez que la ligne `package: name='com.vamos.helios.ultimate'` apparaît et que `Verified using v2 scheme … : true`.
- Play Protect : « Plus de détails » → « Installer quand même », ou désactivez temporairement l'analyse.
- Stockage plein : libérez 200 Mo.
- Téléchargement cassé : si `app-debug.apk` pèse moins de 500 Ko ou se termine en `.zip`, retéléchargez.
- Notez le message exact d'Android (« Paquet invalide », « Conflit », « Application non installée ») et envoyez-le.
