# Serveur HELIOS — installation

Le serveur est facultatif. Il sert à relier l'assistant à un fournisseur IA compatible avec l'API Chat Completions et à synchroniser les notes/tâches.

## Prérequis

- PHP 8.1 ou plus récent (recommandé : 8.2+)
- Extensions PHP `curl`, `pdo`, `pdo_mysql`, `json`, `mbstring`
- MySQL 8 ou MariaDB compatible
- Un hébergement HTTPS
- Un fournisseur IA et une clé API pour la conversation distante (facultatif)

## Mise en place

1. Créez une base de données et importez `database/schema.sql`.
2. Copiez `config.example.php` en `config.php`.
3. Remplacez le jeton `api_token` par une chaîne aléatoire longue (au moins 32 caractères).
4. Renseignez les accès MySQL.
5. Pour l'IA, renseignez `ai_base_url`, `ai_api_key` et `ai_model`. Laissez-les vides pour utiliser uniquement la synchronisation.
6. Placez le dossier `server` derrière HTTPS. Idéalement, placez `config.php` en dehors du dossier public et adaptez le chemin dans `api/bootstrap.php`.
7. Testez `https://votre-domaine.tld/server/api/health.php`.
8. Dans HELIOS Android ou le tableau web, entrez l'URL complète de `api/assistant.php` et le même jeton.

## Synchronisation web

Le tableau web transforme l'URL `assistant.php` en `sync.php` puis envoie les notes et tâches au serveur. Le serveur stocke une copie complète par jeton. Dans cette version alpha, le serveur ne fusionne pas les modifications concurrentes : une sauvegarde remplace la précédente. Faites un export JSON avant tout test multi-appareils.

## Sécurité

- Ne publiez jamais `config.php` ni la clé IA.
- N'utilisez jamais HTTP public pour transmettre un jeton.
- Ce modèle à jeton partagé est prévu pour un prototype privé. Pour une mise en production multi-utilisateur, ajoutez comptes, jetons individuels révocables, limitation de débit, journalisation minimisée, sauvegardes et règles de rétention.
- Ne connectez pas de fonctions bancaires réelles ni d'actions physiques de serrure à cette première version.
