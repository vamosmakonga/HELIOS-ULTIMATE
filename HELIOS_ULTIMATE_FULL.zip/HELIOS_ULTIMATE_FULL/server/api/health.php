<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';
$config = helios_config();
helios_json([
    'service' => 'HELIOS API',
    'status' => 'online',
    'assistant_configured' => !empty($config['ai_api_key']) && !empty($config['ai_model']),
    'sync_available' => extension_loaded('pdo_mysql'),
]);
