<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') helios_json(['error' => 'Méthode non autorisée.'], 405);
$config = helios_config();
helios_authorize($config);
$body = helios_body(150000);
$message = trim((string)($body['message'] ?? ''));
$history = is_array($body['history'] ?? null) ? $body['history'] : [];
if ($message === '') helios_json(['error' => 'Le message est vide.'], 400);
if (mb_strlen($message, 'UTF-8') > 6000) helios_json(['error' => 'Le message dépasse la limite autorisée.'], 413);

$apiKey = (string)($config['ai_api_key'] ?? '');
$model = (string)($config['ai_model'] ?? '');
$baseUrl = (string)($config['ai_base_url'] ?? '');
if ($apiKey === '' || $model === '' || $baseUrl === '') {
    helios_json(['error' => 'Le moteur IA n’est pas configuré sur le serveur. Ajoutez HELIOS_AI_KEY, HELIOS_AI_MODEL et HELIOS_AI_BASE_URL.'], 503);
}
if (!function_exists('curl_init')) helios_json(['error' => 'L’extension PHP cURL est nécessaire pour le moteur IA.'], 503);

$messages = [
    ['role' => 'system', 'content' => 'Tu es HELIOS, un assistant personnel francophone. Réponds clairement et honnêtement. Tu ne prétends jamais contrôler le téléphone, accéder à la caméra, aux messages, aux comptes ou aux appareils si aucun outil ne t’a donné cet accès. Pour les actions sensibles, demande une confirmation et rappelle les limites de sécurité.'],
];
// Keep only a short, structured conversation window supplied by the authenticated client.
foreach (array_slice($history, -20) as $turn) {
    if (!is_array($turn)) continue;
    $role = (string)($turn['role'] ?? '');
    $content = trim((string)($turn['content'] ?? ''));
    if (!in_array($role, ['user', 'assistant'], true) || $content === '' || mb_strlen($content, 'UTF-8') > 6000) continue;
    $messages[] = ['role' => $role, 'content' => $content];
}
$messages[] = ['role' => 'user', 'content' => $message];
$payload = [
    'model' => $model,
    'messages' => $messages,
    'temperature' => 0.6,
];
$curl = curl_init($baseUrl);
curl_setopt_array($curl, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 12,
    CURLOPT_TIMEOUT => 50,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey],
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
]);
$response = curl_exec($curl);
$curlError = curl_error($curl);
$status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);
if ($response === false) helios_json(['error' => 'Connexion au fournisseur IA impossible : ' . $curlError], 502);
$decoded = json_decode($response, true);
if ($status < 200 || $status >= 300) {
    helios_json(['error' => 'Le fournisseur IA a refusé la requête (HTTP ' . $status . ').'], 502);
}
$reply = trim((string)($decoded['choices'][0]['message']['content'] ?? ''));
if ($reply === '') helios_json(['error' => 'Le fournisseur IA a renvoyé une réponse vide.'], 502);
helios_json(['reply' => $reply]);
