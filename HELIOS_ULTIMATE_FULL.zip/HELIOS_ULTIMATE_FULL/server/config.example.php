<?php
/**
 * Copy this file to config.php and replace every CHANGE_ME value.
 * Prefer environment variables and keep config.php outside the public web root.
 */
return [
    'api_token' => getenv('HELIOS_API_TOKEN') ?: 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET',
    'ai_base_url' => getenv('HELIOS_AI_BASE_URL') ?: 'https://api.openai.com/v1/chat/completions',
    'ai_api_key' => getenv('HELIOS_AI_KEY') ?: '',
    'ai_model' => getenv('HELIOS_AI_MODEL') ?: '',
    'database' => [
        'host' => getenv('HELIOS_DB_HOST') ?: '127.0.0.1',
        'port' => getenv('HELIOS_DB_PORT') ?: '3306',
        'name' => getenv('HELIOS_DB_NAME') ?: 'helios',
        'user' => getenv('HELIOS_DB_USER') ?: 'helios_user',
        'password' => getenv('HELIOS_DB_PASSWORD') ?: '',
        'charset' => 'utf8mb4',
    ],
];
