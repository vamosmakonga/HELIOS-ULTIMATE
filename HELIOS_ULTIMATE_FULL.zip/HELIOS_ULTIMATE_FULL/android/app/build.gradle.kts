plugins {
    id("com.android.application")
}

android {
    namespace = "com.vamos.helios"
    compileSdk = 35

    // Clé de signature FIXE incluse dans le projet : toutes les versions construites par GitHub
    // portent la même signature, donc Android accepte la mise à jour d'une version à l'autre.
    signingConfigs {
        create("helios") {
            storeFile = rootProject.file("keystore/helios.jks")
            storePassword = "helios2026"
            keyAlias = "helios"
            keyPassword = "helios2026"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    defaultConfig {
        // Nouvel identifiant : s'installe À CÔTÉ de l'ancien HELIOS sans conflit de signature.
        applicationId = "com.vamos.helios.ultimate"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "2.0.0-hud"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("helios")
        }
        release {
            signingConfig = signingConfigs.getByName("helios")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
