plugins {
    id("com.android.application")
}

android {
    namespace = "com.vamos.helios"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.vamos.helios"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.3.0-mains-libres"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
