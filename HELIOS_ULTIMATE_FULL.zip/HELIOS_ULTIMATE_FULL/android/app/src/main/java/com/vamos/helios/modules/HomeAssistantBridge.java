package com.vamos.helios.modules;

import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Optional REST bridge for a self-hosted Home Assistant instance. It is not wired to UI yet. */
public final class HomeAssistantBridge {
    private HomeAssistantBridge() { }

    public static void callService(String baseUrl, String accessToken, String domain,
                                   String service, String entityId, Callback callback) {
        Thread worker = new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                if (baseUrl == null || !baseUrl.startsWith("https://")) {
                    throw new IllegalArgumentException("Une URL HTTPS est obligatoire pour la maison connectée.");
                }
                String endpoint = baseUrl.replaceAll("/$", "") + "/api/services/"
                        + encodePath(domain) + "/" + encodePath(service);
                connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(15000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Authorization", "Bearer " + accessToken);
                connection.setRequestProperty("Content-Type", "application/json");
                JSONObject body = new JSONObject();
                body.put("entity_id", entityId);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = connection.getResponseCode();
                if (code >= 200 && code < 300) callback.onComplete("Commande envoyée au système domotique.");
                else callback.onFailure("Le système domotique a répondu HTTP " + code + ".");
            } catch (Exception exception) {
                callback.onFailure(exception.getMessage());
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "helios-home-assistant");
        worker.start();
    }

    private static String encodePath(String value) {
        return value == null ? "" : value.replaceAll("[^A-Za-z0-9_-]", "");
    }

    public interface Callback { void onComplete(String message); void onFailure(String message); }
}
