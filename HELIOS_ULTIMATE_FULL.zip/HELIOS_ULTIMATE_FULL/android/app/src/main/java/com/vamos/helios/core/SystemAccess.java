package com.vamos.helios.core;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.SpeechRecognizer;

import com.vamos.helios.services.HeliosAccessibilityService;
import com.vamos.helios.services.HeliosListenService;

/** Vérifie les autorisations Android dont HELIOS a besoin et ouvre les bons écrans de réglages. */
public final class SystemAccess {
    private SystemAccess() { }

    public static boolean hasAudioPermission(Context context) {
        return context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean hasPermission(Context context, String permission) {
        return context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean hasNotificationPermission(Context context) {
        if (Build.VERSION.SDK_INT < 33) return true;
        return context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean isAccessibilityEnabled(Context context) {
        try {
            String enabled = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null || enabled.isEmpty()) return false;
            ComponentName name = new ComponentName(context, HeliosAccessibilityService.class);
            String full = name.flattenToString();
            String shortName = name.flattenToShortString();
            for (String item : enabled.split(":")) {
                if (item.equalsIgnoreCase(full) || item.equalsIgnoreCase(shortName)) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    public static boolean isNotificationListenerEnabled(Context context) {
        try {
            String enabled = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
            return enabled != null && enabled.contains(context.getPackageName());
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isIgnoringBatteryOptimizations(Context context) {
        try {
            PowerManager manager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            return manager != null && manager.isIgnoringBatteryOptimizations(context.getPackageName());
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean canDrawOverlays(Context context) {
        try { return Settings.canDrawOverlays(context); } catch (Exception ignored) { return false; }
    }

    /** Ouvre un écran de réglages sans faire planter l'application s'il n'existe pas sur ce téléphone. */
    public static boolean open(Context context, Intent intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    public static boolean openAccessibilitySettings(Context context) {
        return open(context, new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    /** Écran « Infos sur l'appli » : le menu ⋮ y contient « Autoriser les paramètres restreints ». */
    public static boolean openAppDetails(Context context) {
        return open(context, new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.getPackageName(), null)));
    }

    public static boolean requestIgnoreBatteryOptimizations(Context context) {
        Intent direct = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:" + context.getPackageName()));
        if (open(context, direct)) return true;
        return open(context, new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    }

    public static boolean requestOverlayPermission(Context context) {
        return open(context, new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + context.getPackageName())));
    }

    public static String diagnostics(Context context) {
        StringBuilder out = new StringBuilder();
        line(out, hasAudioPermission(context), "Autorisation du microphone");
        line(out, hasNotificationPermission(context), "Autorisation des notifications (obligatoire pour l'écoute en arrière-plan)");
        boolean recognition = false;
        try { recognition = SpeechRecognizer.isRecognitionAvailable(context); } catch (Exception ignored) { }
        line(out, recognition, "Service de reconnaissance vocale installé (Google)");
        line(out, HeliosListenService.isRunning(), "Écoute mains libres en cours");
        line(out, isAccessibilityEnabled(context), "Service d'accessibilité HELIOS activé");
        line(out, isIgnoringBatteryOptimizations(context), "Batterie : HELIOS autorisé à tourner en arrière-plan");
        line(out, canDrawOverlays(context), "Affichage par-dessus les autres applications (ouvrir des apps en arrière-plan)");
        line(out, isNotificationListenerEnabled(context), "Accès aux notifications (pour « lis mes notifications »)");
        line(out, hasPermission(context, Manifest.permission.READ_CONTACTS), "Contacts (appeler ou écrire à un nom)");
        line(out, hasPermission(context, Manifest.permission.CALL_PHONE), "Appels directs");
        line(out, hasPermission(context, Manifest.permission.SEND_SMS), "Envoi de SMS");
        out.append(Speaker.get(context).status()).append('\n');
        out.append("\nAndroid ").append(Build.VERSION.RELEASE)
                .append(" • ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL);
        try {
            String engine = Settings.Secure.getString(context.getContentResolver(), "voice_recognition_service");
            if (engine != null && !engine.isEmpty()) out.append("\nMoteur vocal : ").append(engine);
        } catch (Exception ignored) { }
        return out.toString();
    }

    private static void line(StringBuilder out, boolean ok, String label) {
        out.append(ok ? "✔ " : "✖ ").append(label).append('\n');
    }
}
