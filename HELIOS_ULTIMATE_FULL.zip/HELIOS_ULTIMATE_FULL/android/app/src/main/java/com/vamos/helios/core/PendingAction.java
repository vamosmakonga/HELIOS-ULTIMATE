package com.vamos.helios.core;

import android.os.SystemClock;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Autorisation vocale : avant un appel, un SMS ou un message WhatsApp, HELIOS pose la question
 * et n'agit que si vous répondez « oui ». Partagé entre l'écran et le service d'écoute.
 */
public final class PendingAction {
    public interface Action { String run(); }

    private static final long LIFETIME_MS = 45_000L;
    private static final Set<String> YES = new HashSet<>(Arrays.asList(
            "oui", "ouais", "ok", "okay", "d'accord", "daccord", "confirme", "confirmer", "je confirme", "vas y", "va y",
            "fais le", "fais ca", "envoie", "envoie le", "appelle", "go", "yes", "oui confirme", "oui je confirme",
            "bien sur", "c'est bon", "ndiyo", "ndio", "sawa"));
    private static final Set<String> NO = new HashSet<>(Arrays.asList(
            "non", "annule", "annuler", "stop", "laisse tomber", "pas maintenant", "non merci", "surtout pas",
            "n'envoie pas", "n'appelle pas", "arrete", "no", "hapana", "ne le fais pas"));

    private static String question;
    private static Action action;
    private static long expiresAt;

    private PendingAction() { }

    public static synchronized void set(String description, Action pending) {
        question = description;
        action = pending;
        expiresAt = SystemClock.elapsedRealtime() + LIFETIME_MS;
    }

    public static synchronized boolean isPending() {
        if (action != null && SystemClock.elapsedRealtime() > expiresAt) clear();
        return action != null;
    }

    public static synchronized void clear() {
        question = null;
        action = null;
        expiresAt = 0L;
    }

    /**
     * @return la réponse de HELIOS si la phrase répond à une question en attente ; sinon null
     *         (et l'attente est abandonnée si l'utilisateur a changé de sujet).
     */
    public static String answer(String spoken) {
        Action toRun;
        synchronized (PendingAction.class) {
            if (!isPending()) return null;
            String text = AppResolver.normalize(spoken);
            if (YES.contains(text) || text.startsWith("oui ") || text.startsWith("ok ")) {
                toRun = action;
                clear();
            } else if (NO.contains(text) || text.startsWith("non ")) {
                clear();
                return "D'accord, j'annule.";
            } else {
                clear();
                return null;
            }
        }
        String result;
        try {
            result = toRun.run();
        } catch (Exception exception) {
            result = "Je n'ai pas pu exécuter cette action : " + exception.getMessage();
        }
        return result == null || result.isEmpty() ? "C'est fait." : result;
    }
}
