package com.vamos.helios.core;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.telephony.SmsManager;
import android.view.KeyEvent;

import com.vamos.helios.services.HeliosAccessibilityService;
import com.vamos.helios.services.HeliosListenService;

import java.util.ArrayList;
import java.util.Locale;

/** Actions réelles sur le téléphone : lampe, volume, médias, alarme, appel, SMS, WhatsApp, navigation. */
public final class DeviceActions {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static boolean torchOn = false;

    private DeviceActions() { }

    // ---- Lancer une activité, même depuis l'arrière-plan ---------------------------------------------

    /**
     * Lance une activité. Si l'accessibilité est activée, on passe par elle : Android lui permet plus souvent
     * de démarrer une application depuis l'arrière-plan.
     */
    public static void start(Context context, Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        HeliosAccessibilityService service = HeliosAccessibilityService.get();
        if (service != null) {
            try {
                service.startActivity(intent);
                return;
            } catch (ActivityNotFoundException exception) {
                throw exception;
            } catch (RuntimeException ignored) {
                // on retente avec le contexte normal
            }
        }
        context.startActivity(intent);
    }

    static boolean isInstalled(Context context, String packageName) {
        try {
            context.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException exception) {
            return false;
        }
    }

    // ---- Lampe torche ---------------------------------------------------------------------------------

    public static String torch(Context context, boolean on) {
        try {
            CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            String flashCamera = null;
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics characteristics = manager.getCameraCharacteristics(id);
                Boolean flash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flash != null && flash) {
                    Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                    if (flashCamera == null || (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK)) flashCamera = id;
                }
            }
            if (flashCamera == null) return "Ce téléphone n'a pas de lampe torche.";
            manager.setTorchMode(flashCamera, on);
            torchOn = on;
            return on ? "Lampe allumée." : "Lampe éteinte.";
        } catch (CameraAccessException | IllegalArgumentException | SecurityException exception) {
            return "Je ne peux pas contrôler la lampe pour le moment (l'appareil photo est peut-être utilisé).";
        }
    }

    public static boolean isTorchOn() { return torchOn; }

    // ---- Volume et médias -----------------------------------------------------------------------------

    private static AudioManager audio(Context context) {
        return (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
    }

    public static String volumeStep(Context context, int direction) {
        AudioManager manager = audio(context);
        int max = manager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int step = Math.max(1, max / 5);
        int target = Math.max(0, Math.min(max, manager.getStreamVolume(AudioManager.STREAM_MUSIC) + direction * step));
        manager.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI);
        return "Volume média : " + target + " sur " + max + ".";
    }

    public static String volumePercent(Context context, int percent) {
        AudioManager manager = audio(context);
        int max = manager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int target = Math.round(max * Math.max(0, Math.min(100, percent)) / 100f);
        manager.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI);
        return "Volume média : " + target + " sur " + max + ".";
    }

    public static String mute(Context context, boolean mute) {
        AudioManager manager = audio(context);
        manager.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                mute ? AudioManager.ADJUST_MUTE : AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI);
        return mute ? "Son coupé." : "Son rétabli.";
    }

    public static String mediaKey(Context context, int keyCode, String message) {
        AudioManager manager = audio(context);
        long now = SystemClock.uptimeMillis();
        manager.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0));
        manager.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0));
        return message;
    }

    // ---- Alarme et minuteur (réglés pour de bon, sans écran de confirmation) -----------------------

    public static String alarm(Context context, int hour, int minute) {
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "HELIOS")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        try {
            start(context, intent);
            return String.format(Locale.FRANCE, "Alarme réglée à %02d:%02d.", hour, minute);
        } catch (ActivityNotFoundException | SecurityException exception) {
            return "Aucune application Horloge ne peut régler cette alarme.";
        }
    }

    public static String timer(Context context, int seconds) {
        Intent intent = new Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "HELIOS")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        try {
            start(context, intent);
            return "Minuteur lancé : " + describeDuration(seconds) + ".";
        } catch (ActivityNotFoundException | SecurityException exception) {
            return "Aucune application Horloge ne peut lancer ce minuteur.";
        }
    }

    private static String describeDuration(int seconds) {
        if (seconds % 3600 == 0) return (seconds / 3600) + (seconds / 3600 > 1 ? " heures" : " heure");
        if (seconds % 60 == 0) return (seconds / 60) + (seconds / 60 > 1 ? " minutes" : " minute");
        return seconds + " secondes";
    }

    // ---- Appel, SMS, WhatsApp --------------------------------------------------------------------------

    public static String call(Context context, ContactResolver.Contact contact) {
        String number = contact.number.replaceAll("[^0-9+*#]", "");
        boolean allowed = context.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
        try {
            start(context, new Intent(allowed ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)));
            return allowed ? "J'appelle " + contact.name + "." : "Le composeur est ouvert pour " + contact.name + " : appuyez sur appeler.";
        } catch (SecurityException exception) {
            try {
                start(context, new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)));
                return "Le composeur est ouvert pour " + contact.name + " : appuyez sur appeler.";
            } catch (RuntimeException inner) {
                return "Android a bloqué l'appel.";
            }
        } catch (ActivityNotFoundException exception) {
            return "Aucune application téléphone n'est disponible.";
        }
    }

    public static String sms(Context context, ContactResolver.Contact contact, String body) {
        String number = contact.number.replaceAll("[^0-9+]", "");
        if (context.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager manager = Build.VERSION.SDK_INT >= 31
                        ? context.getSystemService(SmsManager.class) : SmsManager.getDefault();
                ArrayList<String> parts = manager.divideMessage(body);
                manager.sendMultipartTextMessage(number, null, parts, null, null);
                return "SMS envoyé à " + contact.name + ".";
            } catch (RuntimeException exception) {
                // on passe par l'application de messages ci-dessous
            }
        }
        try {
            start(context, new Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", number, null)).putExtra("sms_body", body));
            return "Le SMS pour " + contact.name + " est prêt : appuyez sur Envoyer.";
        } catch (ActivityNotFoundException | SecurityException exception) {
            return "Aucune application de messages n'est disponible.";
        }
    }

    public static String whatsapp(Context context, ContactResolver.Contact contact, String body, String countryCode) {
        String packageName = isInstalled(context, "com.whatsapp") ? "com.whatsapp"
                : (isInstalled(context, "com.whatsapp.w4b") ? "com.whatsapp.w4b" : null);
        if (packageName == null) return "WhatsApp n'est pas installé sur ce téléphone.";
        String international = ContactResolver.toInternational(contact.number, countryCode);
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/" + international + "?text=" + Uri.encode(body)));
        intent.setPackage(packageName);
        try {
            start(context, intent);
        } catch (ActivityNotFoundException | SecurityException exception) {
            return "Impossible d'ouvrir WhatsApp.";
        }
        if (HeliosAccessibilityService.get() == null) {
            return "Le message pour " + contact.name + " est prêt dans WhatsApp. Activez l'accessibilité pour que j'appuie moi-même sur Envoyer ; sinon appuyez sur Envoyer.";
        }
        autoSend(context, contact.name);
        return "J'envoie le message à " + contact.name + " sur WhatsApp.";
    }

    /** Attend que le chat WhatsApp s'ouvre, puis touche le bouton « Envoyer » (texte exact, jamais le champ de saisie). */
    private static void autoSend(final Context context, final String name) {
        final int[] attempts = {0};
        Runnable task = new Runnable() {
            @Override public void run() {
                attempts[0]++;
                HeliosAccessibilityService service = HeliosAccessibilityService.get();
                if (service != null && service.clickExact("Envoyer", "Send")) {
                    HeliosListenService.say(context, "Message envoyé à " + name + ".");
                    return;
                }
                if (attempts[0] < 18) {
                    MAIN.postDelayed(this, 700);
                } else {
                    HeliosListenService.say(context, "Je n'ai pas trouvé le bouton Envoyer. Appuyez dessus vous-même.");
                }
            }
        };
        MAIN.postDelayed(task, 2600);
    }

    // ---- Navigation, web, YouTube ----------------------------------------------------------------------

    public static String navigate(Context context, String destination) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(destination)));
        if (isInstalled(context, "com.google.android.apps.maps")) intent.setPackage("com.google.android.apps.maps");
        try {
            start(context, intent);
            return "Navigation vers " + destination + " lancée.";
        } catch (ActivityNotFoundException | SecurityException exception) {
            try {
                start(context, new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(destination))));
                return "J'ouvre la carte pour " + destination + ".";
            } catch (RuntimeException inner) {
                return "Aucune application de navigation n'est disponible.";
            }
        }
    }

    public static String openUrl(Context context, String url, String message) {
        try {
            start(context, new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            return message;
        } catch (ActivityNotFoundException | SecurityException exception) {
            return "Aucun navigateur n'est disponible.";
        }
    }

    public static String youtubeSearch(Context context, String query) {
        return openUrl(context, "https://www.youtube.com/results?search_query=" + Uri.encode(query),
                "Je cherche « " + query + " » sur YouTube.");
    }
}
