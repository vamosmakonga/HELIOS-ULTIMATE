package com.vamos.helios.services;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

/** Optional listener. It intentionally stores no notification content in this starter project. */
public class HeliosNotificationListener extends NotificationListenerService {
    private static final String TAG = "HELIOS-Notifications";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn != null) {
            // Deliberately metadata-only. Add a visible, user-controlled feature before reading content.
            Log.d(TAG, "Notification received from package: " + sbn.getPackageName());
        }
    }
}
