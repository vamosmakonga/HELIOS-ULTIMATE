package com.vamos.helios.services;

import android.app.Notification;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.List;

/**
 * Écoute les notifications uniquement si vous avez activé cet accès. Les dernières notifications restent
 * en mémoire vive (jamais écrites sur le disque ni envoyées) pour que HELIOS puisse vous les lire.
 */
public class HeliosNotificationListener extends NotificationListenerService {
    private static final int MAX = 20;
    private static final List<String> RECENT = new ArrayList<>();

    /** @return les dernières notifications, la plus récente en premier. */
    public static synchronized List<String> recent(int count) {
        List<String> result = new ArrayList<>();
        for (int i = RECENT.size() - 1; i >= 0 && result.size() < count; i--) result.add(RECENT.get(i));
        return result;
    }

    private static synchronized void remember(String entry) {
        RECENT.add(entry);
        while (RECENT.size() > MAX) RECENT.remove(0);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        if (getPackageName().equals(sbn.getPackageName())) return;
        Notification notification = sbn.getNotification();
        if ((notification.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if ((notification.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;
        Bundle extras = notification.extras;
        if (extras == null) return;
        CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);
        if (title == null && text == null) return;
        String app = sbn.getPackageName();
        try {
            PackageManager manager = getPackageManager();
            app = manager.getApplicationLabel(manager.getApplicationInfo(sbn.getPackageName(), 0)).toString();
        } catch (Exception ignored) { }
        StringBuilder entry = new StringBuilder(app);
        if (title != null && title.length() > 0) entry.append(" — ").append(title);
        if (text != null && text.length() > 0) entry.append(" : ").append(text);
        remember(entry.toString());
    }
}
