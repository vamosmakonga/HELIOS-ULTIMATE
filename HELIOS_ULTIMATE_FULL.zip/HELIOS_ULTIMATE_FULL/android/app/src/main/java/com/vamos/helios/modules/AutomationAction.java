package com.vamos.helios.modules;

/** A single approved step in a user-created automation. */
public interface AutomationAction {
    String label();
    boolean requiresConfirmation();
    void execute(Callback callback);
    interface Callback { void onComplete(String result); void onFailure(String reason); }
}
