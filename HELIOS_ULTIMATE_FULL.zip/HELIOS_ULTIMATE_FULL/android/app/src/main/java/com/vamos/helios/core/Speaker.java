package com.vamos.helios.core;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.util.Locale;
import java.util.Set;

/**
 * Voix de HELIOS : un seul moteur de synthèse vocale partagé par l'écran et le service d'écoute.
 * Il essaie le moteur par défaut, puis Google, choisit le français si possible, sinon une autre langue,
 * et explique clairement ce qui manque au lieu de rester muet.
 */
public final class Speaker {
    public interface Callback { void onDone(); }

    private static final String GOOGLE_TTS = "com.google.android.tts";
    private static Speaker instance;

    public static synchronized Speaker get(Context context) {
        if (instance == null) instance = new Speaker(context.getApplicationContext());
        return instance;
    }

    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private boolean ready = false;
    private boolean failed = false;
    private boolean frenchOk = false;
    private String languageInUse = "";
    private String engineInUse = "";
    private boolean triedGoogle = false;

    private String pendingText;
    private Callback pendingCallback;
    private Callback current;
    private String currentId;

    private final Runnable guard = this::finishCurrent;

    private Speaker(Context context) {
        this.context = context;
        init(null);
    }

    // ---- Initialisation ---------------------------------------------------------------------------

    private void init(final String enginePackage) {
        final TextToSpeech.OnInitListener listener = status -> main.post(() -> onInit(status, enginePackage));
        try {
            tts = enginePackage == null
                    ? new TextToSpeech(context, listener)
                    : new TextToSpeech(context, listener, enginePackage);
        } catch (Exception exception) {
            tts = null;
            main.post(() -> onInit(TextToSpeech.ERROR, enginePackage));
        }
    }

    private void onInit(int status, String enginePackage) {
        if (status != TextToSpeech.SUCCESS || tts == null) {
            try { if (tts != null) tts.shutdown(); } catch (Exception ignored) { }
            tts = null;
            if (enginePackage == null && !triedGoogle) {
                triedGoogle = true;
                init(GOOGLE_TTS);
                return;
            }
            failed = true;
            ready = false;
            flushPending();
            return;
        }
        engineInUse = enginePackage == null ? "moteur par défaut" : enginePackage;
        chooseLanguage();
        try {
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            tts.setSpeechRate(0.95f);
            tts.setPitch(0.9f);
        } catch (Exception ignored) { }
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) { }
            @Override public void onDone(String utteranceId) { main.post(() -> finishIfCurrent(utteranceId)); }
            @Override public void onError(String utteranceId) { main.post(() -> finishIfCurrent(utteranceId)); }
        });
        failed = false;
        ready = true;
        if (pendingText != null) {
            String text = pendingText;
            Callback callback = pendingCallback;
            pendingText = null;
            pendingCallback = null;
            speakReady(text, callback);
        }
    }

    private void chooseLanguage() {
        Locale[] french = {Locale.FRANCE, new Locale("fr", "CD"), new Locale("fr"), Locale.CANADA_FRENCH, new Locale("fr", "BE")};
        frenchOk = false;
        for (Locale locale : french) {
            try {
                if (tts.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE
                        && tts.setLanguage(locale) >= TextToSpeech.LANG_AVAILABLE) {
                    frenchOk = true;
                    languageInUse = locale.toLanguageTag();
                    break;
                }
            } catch (Exception ignored) { }
        }
        if (frenchOk) {
            pickMaleFrenchVoice();
            return;
        }
        try {
            int result = tts.setLanguage(Locale.getDefault());
            languageInUse = Locale.getDefault().toLanguageTag();
            if (result < TextToSpeech.LANG_AVAILABLE) {
                tts.setLanguage(Locale.ENGLISH);
                languageInUse = "en";
            }
        } catch (Exception ignored) { }
    }

    /** Les voix Google françaises « frb » et « frd » sont masculines. */
    private void pickMaleFrenchVoice() {
        try {
            Set<Voice> voices = tts.getVoices();
            if (voices == null) return;
            Voice fallback = null;
            for (Voice voice : voices) {
                if (voice.getLocale() == null || !"fr".equals(voice.getLocale().getLanguage())) continue;
                if (voice.isNetworkConnectionRequired()) continue;
                String name = voice.getName().toLowerCase(Locale.ROOT);
                boolean male = name.contains("-frb-") || name.contains("-frd-")
                        || ((name.contains("male") || name.contains("masculin") || name.contains("homme")) && !name.contains("female"));
                if (male) { tts.setVoice(voice); return; }
                if (fallback == null && "FR".equals(voice.getLocale().getCountry())) fallback = voice;
            }
            if (fallback != null) tts.setVoice(fallback);
        } catch (Exception ignored) { }
    }

    // ---- Parler -----------------------------------------------------------------------------------

    /** Dit le texte ; le rappel est appelé quand la voix a fini (ou immédiatement si la voix est indisponible). */
    public void speak(final String text, final Callback callback) {
        main.post(() -> speakOnMain(text, callback));
    }

    private void speakOnMain(String text, Callback callback) {
        String clean = sanitize(text);
        if (clean.isEmpty() || failed) {
            if (callback != null) callback.onDone();
            return;
        }
        if (!ready) {
            if (pendingCallback != null) pendingCallback.onDone();
            pendingText = clean;
            pendingCallback = callback;
            return;
        }
        speakReady(clean, callback);
    }

    private void speakReady(String clean, Callback callback) {
        Callback previous = current;
        current = callback;
        final String id = "helios-" + System.nanoTime();
        currentId = id;
        if (previous != null) previous.onDone();
        main.removeCallbacks(guard);
        int result;
        try {
            result = tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id);
        } catch (Exception exception) {
            result = TextToSpeech.ERROR;
        }
        if (result != TextToSpeech.SUCCESS) {
            finishCurrent();
            return;
        }
        main.postDelayed(guard, Math.min(60000L, 4000L + clean.length() * 90L));
    }

    private void finishIfCurrent(String utteranceId) {
        if (utteranceId != null && utteranceId.equals(currentId)) finishCurrent();
    }

    private void finishCurrent() {
        main.removeCallbacks(guard);
        Callback callback = current;
        current = null;
        currentId = null;
        if (callback != null) callback.onDone();
    }

    private void flushPending() {
        Callback callback = pendingCallback;
        pendingText = null;
        pendingCallback = null;
        if (callback != null) callback.onDone();
    }

    public void stop() {
        main.post(() -> {
            try { if (tts != null) tts.stop(); } catch (Exception ignored) { }
            finishCurrent();
        });
    }

    /** Retire ce que la voix lirait mal : émojis, puces, guillemets, retours à la ligne. */
    static String sanitize(String text) {
        if (text == null) return "";
        String cleaned = text
                .replaceAll("[\\p{So}\\p{Cs}\\p{Sk}]", " ")
                .replace('•', ' ').replace('●', ' ').replace('○', ' ')
                .replace('«', ' ').replace('»', ' ').replace('→', ' ').replace('▸', ' ').replace('◂', ' ')
                .replace("°C", " degrés")
                .replace("%", " pour cent")
                .replaceAll("\\s*\\n+\\s*", ". ")
                .replaceAll("\\s{2,}", " ")
                .trim();
        if (cleaned.length() > 700) {
            int cut = cleaned.lastIndexOf('.', 700);
            cleaned = cleaned.substring(0, cut > 200 ? cut + 1 : 700);
        }
        return cleaned;
    }

    // ---- État et aide -----------------------------------------------------------------------------

    public boolean isReady() { return ready; }
    public boolean isFailed() { return failed; }
    public boolean hasFrench() { return ready && frenchOk; }

    public boolean isMediaVolumeZero() {
        try {
            AudioManager manager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            return manager != null && manager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0;
        } catch (Exception exception) {
            return false;
        }
    }

    /** Phrase prête à afficher dans le diagnostic. */
    public String status() {
        if (failed) return "✖ Voix indisponible : installez ou activez « Synthèse vocale Google » (bouton « Réparer la voix »)";
        if (!ready) return "… Voix en cours d'initialisation";
        String volume = isMediaVolumeZero() ? " — ATTENTION : le volume média est à zéro" : "";
        if (!frenchOk) return "⚠ Voix française absente : HELIOS parle en « " + languageInUse + " » (installez la voix française)" + volume;
        return "✔ Voix française prête (" + languageInUse + ", " + engineInUse + ")" + volume;
    }

    /** Ouvre l'écran d'installation des données vocales, ou à défaut les réglages de synthèse vocale. */
    public static boolean openVoiceSetup(Context context) {
        Intent[] attempts = {
                new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA),
                new Intent("com.android.settings.TTS_SETTINGS"),
                new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + GOOGLE_TTS)),
                new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + GOOGLE_TTS))
        };
        for (Intent intent : attempts) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return true;
            } catch (Exception ignored) { }
        }
        return false;
    }
}
