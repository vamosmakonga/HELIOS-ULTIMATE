package com.vamos.helios.services;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Locale;

/**
 * Permet à HELIOS d'agir dans les autres applications : retour, accueil, notifications, clic sur un texte,
 * saisie, défilement, lecture de l'écran. Ne fonctionne que si l'utilisateur l'active lui-même dans les
 * réglages d'accessibilité d'Android. Les champs de mot de passe sont toujours ignorés.
 */
public class HeliosAccessibilityService extends AccessibilityService {
    private static volatile HeliosAccessibilityService instance;
    private volatile String currentPackage = "";

    /** @return le service s'il est activé et connecté, sinon null. */
    public static HeliosAccessibilityService get() { return instance; }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            currentPackage = event.getPackageName().toString();
        }
    }

    @Override public void onInterrupt() { }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    // ---- Actions globales ----------------------------------------------------------------------

    public boolean back() { return performGlobalAction(GLOBAL_ACTION_BACK); }
    public boolean home() { return performGlobalAction(GLOBAL_ACTION_HOME); }
    public boolean recents() { return performGlobalAction(GLOBAL_ACTION_RECENTS); }
    public boolean notifications() { return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); }
    public boolean quickSettings() { return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); }

    public boolean lockScreen() {
        return Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
    }

    public boolean screenshot() {
        return Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
    }

    // ---- Actions sur l'écran -------------------------------------------------------------------

    /** Clique sur le premier élément dont le texte (ou la description) contient « wanted ». */
    public boolean clickText(String wanted) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || wanted == null || wanted.trim().isEmpty()) return false;
        String query = wanted.trim();
        List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(query);
        if (found != null) {
            for (AccessibilityNodeInfo node : found) {
                if (clickNodeOrParent(node)) return true;
            }
        }
        AccessibilityNodeInfo byDescription = findByDescription(root, query.toLowerCase(Locale.ROOT), new int[]{0}, 0);
        return byDescription != null && clickNodeOrParent(byDescription);
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo start) {
        AccessibilityNodeInfo target = start;
        for (int depth = 0; target != null && depth < 7; depth++) {
            if (target.isClickable() && target.isEnabled()) {
                return target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            target = target.getParent();
        }
        return false;
    }

    private AccessibilityNodeInfo findByDescription(AccessibilityNodeInfo node, String query, int[] visited, int depth) {
        if (node == null || depth > 40 || visited[0]++ > 3000) return null;
        CharSequence description = node.getContentDescription();
        if (description != null && description.toString().toLowerCase(Locale.ROOT).contains(query)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findByDescription(node.getChild(i), query, visited, depth + 1);
            if (hit != null) return hit;
        }
        return null;
    }

    /** Écrit du texte dans le champ sélectionné. Retourne un message à dire à l'utilisateur. */
    public String typeText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "Je ne peux pas lire l'écran actuel.";
        AccessibilityNodeInfo input = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (input == null || !input.isEditable()) input = findEditable(root, 0, new int[]{0});
        if (input == null) return "Aucun champ de texte n'est sélectionné. Touchez d'abord le champ où écrire.";
        if (input.isPassword()) return "Je n'écris jamais dans un champ de mot de passe.";
        CharSequence existing = input.getText();
        boolean hasText = existing != null && existing.length() > 0 && !input.isShowingHintText();
        String full = hasText ? existing + " " + text : text;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, full);
        return input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                ? "J'ai écrit le texte." : "Ce champ refuse l'écriture automatique.";
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node, int depth, int[] visited) {
        if (node == null || depth > 40 || visited[0]++ > 3000) return null;
        if (node.isEditable() && node.isVisibleToUser()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findEditable(node.getChild(i), depth + 1, visited);
            if (hit != null) return hit;
        }
        return null;
    }

    public boolean scroll(boolean forward) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            AccessibilityNodeInfo scrollable = findScrollable(root, 0, new int[]{0});
            if (scrollable != null && scrollable.performAction(forward
                    ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                return true;
            }
        }
        return swipeVertical(forward);
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo node, int depth, int[] visited) {
        if (node == null || depth > 40 || visited[0]++ > 3000) return null;
        if (node.isScrollable() && node.isVisibleToUser()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findScrollable(node.getChild(i), depth + 1, visited);
            if (hit != null) return hit;
        }
        return null;
    }

    private boolean swipeVertical(boolean forward) {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        float x = metrics.widthPixels / 2f;
        float from = metrics.heightPixels * (forward ? 0.70f : 0.30f);
        float to = metrics.heightPixels * (forward ? 0.30f : 0.70f);
        Path path = new Path();
        path.moveTo(x, from);
        path.lineTo(x, to);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 350))
                .build();
        return dispatchGesture(gesture, null, null);
    }

    /** Résumé du texte visible à l'écran (jamais les champs de mot de passe). */
    public String readScreen() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "Je ne peux pas lire l'écran actuel.";
        StringBuilder builder = new StringBuilder();
        collectText(root, builder, 0, new int[]{0});
        String text = builder.toString().trim();
        if (text.isEmpty()) return "Je ne vois pas de texte lisible sur cet écran.";
        return text.length() > 700 ? text.substring(0, 700) + "…" : text;
    }

    private void collectText(AccessibilityNodeInfo node, StringBuilder out, int depth, int[] visited) {
        if (node == null || depth > 40 || visited[0]++ > 3000 || out.length() > 900) return;
        if (!node.isPassword() && node.isVisibleToUser()) {
            CharSequence text = node.getText();
            CharSequence description = node.getContentDescription();
            if (text != null && text.length() > 0) out.append(text).append(". ");
            else if (description != null && description.length() > 0) out.append(description).append(". ");
        }
        for (int i = 0; i < node.getChildCount(); i++) collectText(node.getChild(i), out, depth + 1, visited);
    }

    /** Nom lisible de l'application actuellement au premier plan. */
    public String currentAppLabel() {
        String pkg = currentPackage;
        if (pkg == null || pkg.isEmpty()) return "";
        try {
            PackageManager manager = getPackageManager();
            return manager.getApplicationLabel(manager.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception exception) {
            return pkg;
        }
    }
}
