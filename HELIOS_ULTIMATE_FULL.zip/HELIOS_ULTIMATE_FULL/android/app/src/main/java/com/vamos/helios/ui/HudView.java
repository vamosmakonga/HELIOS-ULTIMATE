package com.vamos.helios.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/**
 * Réacteur HUD façon Jarvis : anneaux tournants, graduations, ondes circulaires réactives à la voix,
 * cœur pulsant. Dessiné uniquement avec Canvas : aucune image, aucune bibliothèque, aucune donnée.
 */
public final class HudView extends View {
    public enum State { IDLE, LISTENING, THINKING, SPEAKING, ALERT }

    /** Source externe du niveau sonore (0..1), par exemple le service d'écoute mains libres. */
    public interface LevelSource { float level(); }

    private static final int WAVE_BARS = 72;

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final Path path = new Path();
    private final float density;

    private boolean compact = false;
    private State state = State.IDLE;
    private LevelSource levelSource;
    private float pushedLevel = 0f;
    private float level = 0f;
    private float angle = 0f;
    private float time = 0f;
    private long lastFrameNanos = 0L;
    private int color = Color.rgb(0, 200, 230);

    private String topLeft = "HELIOS // OS 2.0";
    private String topRight = "SYSTÈME EN LIGNE";
    private String bottomLeft = "";
    private String bottomRight = "";

    private float cx, cy, radius;
    private float[] minorTicks = new float[0];
    private float[] mediumTicks = new float[0];
    private float[] majorTicks = new float[0];
    private final float[] waveCos = new float[WAVE_BARS];
    private final float[] waveSin = new float[WAVE_BARS];

    public HudView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        text.setTypeface(Typeface.MONOSPACE);
        text.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < WAVE_BARS; i++) {
            double a = Math.PI * 2 * i / WAVE_BARS;
            waveCos[i] = (float) Math.cos(a);
            waveSin[i] = (float) Math.sin(a);
        }
    }

    // ---- API publique ------------------------------------------------------------------------------

    public void setState(State newState) {
        if (newState != null && newState != state) {
            state = newState;
            postInvalidateOnAnimation();
        }
    }

    public State getState() { return state; }

    /** Pousse un niveau sonore instantané (0..1), qui retombe tout seul. */
    public void pushLevel(float value) {
        pushedLevel = Math.max(pushedLevel, Math.min(1f, Math.max(0f, value)));
    }

    public void setLevelSource(LevelSource source) { this.levelSource = source; }

    /** Mode bulle flottante : seulement le réacteur, sans grille, coins ni textes. */
    public void setCompact(boolean compact) {
        this.compact = compact;
        if (getWidth() > 0) onSizeChanged(getWidth(), getHeight(), getWidth(), getHeight());
        requestLayout();
        postInvalidateOnAnimation();
    }

    public void setCornerTexts(String topLeft, String topRight, String bottomLeft, String bottomRight) {
        this.topLeft = topLeft == null ? "" : topLeft;
        this.topRight = topRight == null ? "" : topRight;
        this.bottomLeft = bottomLeft == null ? "" : bottomLeft;
        this.bottomRight = bottomRight == null ? "" : bottomRight;
        postInvalidateOnAnimation();
    }

    // ---- Géométrie -----------------------------------------------------------------------------------

    private float dp(float value) { return value * density; }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (compact) {
            cx = w / 2f;
            cy = h / 2f;
            radius = Math.max(dp(10), Math.min(w, h) / 2f - dp(3));
        } else {
            float usableHeight = h - dp(26);
            cx = w / 2f;
            cy = usableHeight / 2f + dp(2);
            radius = Math.max(dp(60), Math.min(w, usableHeight) / 2f - dp(8));
        }
        buildTicks();
    }

    private void buildTicks() {
        int total = 120;
        float outer = radius;
        int minor = 0, medium = 0, major = 0;
        for (int i = 0; i < total; i++) {
            if (i % 10 == 0) major++; else if (i % 5 == 0) medium++; else minor++;
        }
        minorTicks = new float[minor * 4];
        mediumTicks = new float[medium * 4];
        majorTicks = new float[major * 4];
        int a = 0, b = 0, c = 0;
        for (int i = 0; i < total; i++) {
            double rad = Math.toRadians(i * 3.0);
            float cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
            float length = (i % 10 == 0) ? dp(10) : (i % 5 == 0 ? dp(6) : dp(3));
            float[] target = (i % 10 == 0) ? majorTicks : (i % 5 == 0 ? mediumTicks : minorTicks);
            int index = (i % 10 == 0) ? c : (i % 5 == 0 ? b : a);
            target[index] = cos * outer;
            target[index + 1] = sin * outer;
            target[index + 2] = cos * (outer - length);
            target[index + 3] = sin * (outer - length);
            if (i % 10 == 0) c += 4; else if (i % 5 == 0) b += 4; else a += 4;
        }
    }

    // ---- Couleurs ------------------------------------------------------------------------------------

    private static int colorFor(State s) {
        switch (s) {
            case LISTENING: return Color.rgb(0, 255, 210);
            case THINKING: return Color.rgb(255, 184, 0);
            case SPEAKING: return Color.rgb(70, 170, 255);
            case ALERT: return Color.rgb(255, 70, 70);
            default: return Color.rgb(0, 200, 230);
        }
    }

    private static String labelFor(State s) {
        switch (s) {
            case LISTENING: return "J'ÉCOUTE";
            case THINKING: return "ANALYSE EN COURS";
            case SPEAKING: return "HELIOS RÉPOND";
            case ALERT: return "ALERTE";
            default: return "EN VEILLE";
        }
    }

    private static int lerp(int from, int to, float t) {
        int r = (int) (Color.red(from) + (Color.red(to) - Color.red(from)) * t);
        int g = (int) (Color.green(from) + (Color.green(to) - Color.green(from)) * t);
        int b = (int) (Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t);
        return Color.rgb(r, g, b);
    }

    private static int alpha(int base, int a) {
        return (base & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    // ---- Dessin --------------------------------------------------------------------------------------

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = System.nanoTime();
        float dt = lastFrameNanos == 0L ? 0.016f : Math.min(0.05f, (now - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = now;
        time += dt;

        float spin;
        float baseLevel;
        switch (state) {
            case LISTENING: spin = 1.0f; baseLevel = 0.07f; break;
            case THINKING: spin = 3.2f; baseLevel = 0.30f + 0.18f * (float) Math.sin(time * 11f); break;
            case SPEAKING: spin = 1.7f; baseLevel = 0.38f + 0.28f * (float) Math.abs(Math.sin(time * 7.5f)); break;
            case ALERT: spin = 0.8f; baseLevel = 0.20f + 0.20f * (float) Math.sin(time * 14f); break;
            default: spin = 0.45f; baseLevel = 0.04f; break;
        }
        angle = (angle + 30f * spin * dt) % 3600f;

        color = lerp(color, colorFor(state), Math.min(1f, dt * 6f));

        float source = pushedLevel;
        if (levelSource != null) source = Math.max(source, levelSource.level());
        pushedLevel = Math.max(0f, pushedLevel - dt * 1.6f);
        float target = Math.max(source, baseLevel);
        level += (target - level) * Math.min(1f, dt * 10f);
        level = Math.max(0f, Math.min(1f, level));

        canvas.save();
        canvas.translate(cx, cy);
        if (!compact) drawGrid(canvas);
        drawGlow(canvas);
        drawTicks(canvas);
        drawRings(canvas);
        drawWave(canvas);
        drawCore(canvas);
        canvas.restore();

        if (!compact) drawCornersAndText(canvas);

        if (isShown()) postInvalidateOnAnimation();
    }

    private void drawGrid(Canvas canvas) {
        stroke.setStrokeWidth(dp(0.6f));
        stroke.setColor(alpha(color, 26));
        float reach = radius * 1.28f;
        canvas.drawLine(-reach, 0, reach, 0, stroke);
        canvas.drawLine(0, -radius * 1.05f, 0, radius * 1.05f, stroke);
        stroke.setColor(alpha(color, 18));
        canvas.drawCircle(0, 0, radius * 1.12f, stroke);
    }

    private void drawGlow(Canvas canvas) {
        float core = radius * 0.40f;
        for (int i = 0; i < 6; i++) {
            fill.setColor(alpha(color, (int) ((30 - i * 4) * (0.7f + level))));
            canvas.drawCircle(0, 0, core * (1.15f + i * 0.40f), fill);
        }
    }

    private void drawTicks(Canvas canvas) {
        canvas.save();
        canvas.rotate(angle * 0.35f);
        stroke.setStrokeWidth(dp(1f));
        stroke.setColor(alpha(color, 70));
        canvas.drawLines(minorTicks, stroke);
        stroke.setColor(alpha(color, 130));
        canvas.drawLines(mediumTicks, stroke);
        stroke.setStrokeWidth(dp(1.8f));
        stroke.setColor(alpha(color, 230));
        canvas.drawLines(majorTicks, stroke);
        canvas.restore();
    }

    private void drawRings(Canvas canvas) {
        // Anneau moyen : trois grands arcs qui tournent en sens inverse.
        float mid = radius * 0.84f;
        oval.set(-mid, -mid, mid, mid);
        stroke.setStrokeWidth(dp(3f));
        stroke.setColor(alpha(color, 215));
        canvas.save();
        canvas.rotate(-angle);
        for (int i = 0; i < 3; i++) canvas.drawArc(oval, i * 120f, 78f, false, stroke);
        canvas.restore();

        stroke.setStrokeWidth(dp(0.8f));
        stroke.setColor(alpha(color, 90));
        canvas.drawCircle(0, 0, mid, stroke);

        // Anneau intérieur : petits segments rapides, balayage fort pendant l'analyse.
        float inner = radius * 0.58f;
        oval.set(-inner, -inner, inner, inner);
        stroke.setStrokeWidth(dp(2f));
        stroke.setColor(alpha(color, 190));
        canvas.save();
        canvas.rotate(angle * 1.7f);
        for (int i = 0; i < 6; i++) canvas.drawArc(oval, i * 60f, 24f, false, stroke);
        canvas.restore();

        if (state == State.THINKING) {
            float sweep = radius * 0.96f;
            oval.set(-sweep, -sweep, sweep, sweep);
            stroke.setStrokeWidth(dp(4f));
            stroke.setColor(alpha(color, 240));
            canvas.drawArc(oval, angle * 2.4f, 38f, false, stroke);
        }
    }

    private void drawWave(Canvas canvas) {
        float base = radius * 0.66f;
        float maxLength = radius * 0.19f;
        stroke.setStrokeWidth(dp(2f));
        stroke.setColor(alpha(color, 235));
        for (int i = 0; i < WAVE_BARS; i++) {
            float shape = 0.5f + 0.5f * (float) Math.sin(i * 0.65f + time * 6.5f);
            shape *= 0.6f + 0.4f * (float) Math.sin(i * 0.23f - time * 3.1f);
            float length = dp(2f) + maxLength * level * Math.max(0.12f, shape);
            canvas.drawLine(waveCos[i] * base, waveSin[i] * base,
                    waveCos[i] * (base + length), waveSin[i] * (base + length), stroke);
        }
    }

    private void drawCore(Canvas canvas) {
        float pulse = 1f + 0.04f * (float) Math.sin(time * 2.2f) + 0.14f * level;
        float core = radius * 0.40f * pulse;

        fill.setColor(alpha(color, 70));
        canvas.drawCircle(0, 0, core * 1.18f, fill);
        fill.setColor(Color.argb(235, 3, 14, 26));
        canvas.drawCircle(0, 0, core, fill);

        stroke.setStrokeWidth(dp(2.2f));
        stroke.setColor(alpha(color, 255));
        canvas.drawCircle(0, 0, core, stroke);

        // Triangles du réacteur (deux triangles inversés qui tournent lentement).
        for (int t = 0; t < 2; t++) {
            path.reset();
            float r = core * 0.74f;
            float start = (t == 0 ? angle * -0.6f : angle * 0.6f + 60f);
            for (int k = 0; k < 3; k++) {
                double a = Math.toRadians(start + k * 120.0 + (t == 0 ? 90.0 : 30.0));
                float px = (float) Math.cos(a) * r;
                float py = (float) Math.sin(a) * r;
                if (k == 0) path.moveTo(px, py); else path.lineTo(px, py);
            }
            path.close();
            stroke.setStrokeWidth(dp(1.4f));
            stroke.setColor(alpha(color, t == 0 ? 220 : 130));
            canvas.drawPath(path, stroke);
        }

        fill.setColor(alpha(color, 255));
        canvas.drawCircle(0, 0, core * (0.15f + 0.10f * level), fill);
        fill.setColor(alpha(Color.WHITE, 235));
        canvas.drawCircle(0, 0, core * (0.07f + 0.05f * level), fill);
    }

    private void drawCornersAndText(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        float inset = dp(6);
        float len = dp(16);
        stroke.setStrokeWidth(dp(1.6f));
        stroke.setColor(alpha(color, 170));
        canvas.drawLine(inset, inset + len, inset, inset, stroke);
        canvas.drawLine(inset, inset, inset + len, inset, stroke);
        canvas.drawLine(w - inset - len, inset, w - inset, inset, stroke);
        canvas.drawLine(w - inset, inset, w - inset, inset + len, stroke);
        canvas.drawLine(inset, h - inset - len, inset, h - inset, stroke);
        canvas.drawLine(inset, h - inset, inset + len, h - inset, stroke);
        canvas.drawLine(w - inset - len, h - inset, w - inset, h - inset, stroke);
        canvas.drawLine(w - inset, h - inset, w - inset, h - inset - len, stroke);

        text.setFakeBoldText(false);
        text.setLetterSpacing(0.08f);
        text.setTextSize(dp(9));
        text.setColor(alpha(color, 190));
        text.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(topLeft, inset + dp(8), inset + dp(14), text);
        canvas.drawText(bottomLeft, inset + dp(8), h - inset - dp(8), text);
        text.setTextAlign(Paint.Align.RIGHT);
        boolean blink = ((int) (time * 2f)) % 2 == 0;
        canvas.drawText((blink ? "● " : "○ ") + topRight, w - inset - dp(8), inset + dp(14), text);
        canvas.drawText(bottomRight, w - inset - dp(8), h - inset - dp(8), text);

        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
        text.setLetterSpacing(0.35f);
        text.setTextSize(dp(12));
        text.setColor(alpha(color, 255));
        canvas.drawText(labelFor(state), w / 2f, h - inset - dp(8), text);
        text.setFakeBoldText(false);
        text.setLetterSpacing(0f);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        lastFrameNanos = 0L;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (visibility == VISIBLE) {
            lastFrameNanos = 0L;
            postInvalidateOnAnimation();
        }
    }
}
