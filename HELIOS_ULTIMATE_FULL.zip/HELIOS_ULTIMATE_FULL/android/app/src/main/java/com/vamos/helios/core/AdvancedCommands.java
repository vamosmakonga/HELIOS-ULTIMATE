package com.vamos.helios.core;

import android.content.Context;
import android.view.KeyEvent;

import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.services.HeliosAccessibilityService;
import com.vamos.helios.services.HeliosListenService;
import com.vamos.helios.services.HeliosNotificationListener;

import java.text.Normalizer;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Les vraies actions : diagnostic, lampe, volume, médias, alarme, minuteur, appel, SMS, WhatsApp,
 * navigation, YouTube, sites web, calcul, lecture des notifications. Les actions sensibles
 * (appel, SMS, WhatsApp) demandent toujours un « oui » avant de s'exécuter.
 */
public final class AdvancedCommands {
    private static final String NEED_ACCESSIBILITY =
            "Le service d'accessibilité HELIOS n'est pas activé. Ouvrez HELIOS, Centre de commande, puis « Activer l'accessibilité ».";

    private final Context context;
    private final LocalMemoryStore memory;
    private String speech;

    public AdvancedCommands(Context context, LocalMemoryStore memory) {
        this.context = context;
        this.memory = memory;
    }

    /** Texte à dire à voix haute s'il diffère du texte affiché (sinon null). */
    public String consumeSpeech() {
        String value = speech;
        speech = null;
        return value;
    }

    public static String plainOf(String text) {
        return Normalizer.normalize(text == null ? "" : text, Normalizer.Form.NFD).replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT).replace('’', '\'');
    }

    /** @return la réponse, ou null si ce n'est pas une de ces commandes. */
    public String handle(String rawInput, String plainInput) {
        speech = null;
        String raw = rawInput.replaceAll("[.!?\\s]+$", "").trim();
        String plain = plainInput.replaceAll("[.!?\\s]+$", "").trim();
        if (raw.length() != plainInput.replaceAll("[.!?\\s]+$", "").length()) {
            // l'alignement texte d'origine / texte simplifié est perdu : on travaille sur la version simplifiée
            raw = plain;
        }
        if (plain.isEmpty()) return null;

        String answer;
        if ((answer = smallTalk(plain)) != null) return answer;
        if ((answer = diagnostic(plain)) != null) return answer;
        if ((answer = lamp(plain)) != null) return answer;
        if ((answer = volume(plain)) != null) return answer;
        if ((answer = media(plain)) != null) return answer;
        if ((answer = alarmAndTimer(plain)) != null) return answer;
        if ((answer = messages(raw, plain)) != null) return answer;
        if ((answer = call(raw, plain)) != null) return answer;
        if ((answer = navigation(raw, plain)) != null) return answer;
        if ((answer = web(raw, plain)) != null) return answer;
        if ((answer = calculation(plain)) != null) return answer;
        if ((answer = notifications(plain)) != null) return answer;
        if ((answer = settings(plain)) != null) return answer;
        return null;
    }

    // ---- Conversation de base ---------------------------------------------------------------------

    private String smallTalk(String plain) {
        if (plain.matches("^(?:bonjour|salut|bonsoir|coucou|hello|hey|jambo)$")) {
            int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            String hello = hour < 12 ? "Bonjour" : (hour < 18 ? "Bon après-midi" : "Bonsoir");
            return hello + ". HELIOS est prêt. Que puis-je faire pour vous ?";
        }
        if (plain.matches("^(?:merci|merci beaucoup|merci helios|asante|asante sana)$")) return "Avec plaisir.";
        if (plain.matches("^(?:comment (?:vas|va)[- ]tu|ca va|tu vas bien|comment ca va)$")) {
            return "Tous mes systèmes fonctionnent normalement. Et vous ?";
        }
        if (plain.matches("^(?:qui es[- ]tu|presente[- ]toi|tu es qui|comment t'appelles[- ]tu)$")) {
            return "Je suis HELIOS, votre assistant personnel. Je peux ouvrir vos applications, passer des appels, envoyer des messages, "
                    + "lire votre écran, régler des alarmes et surveiller l'état de votre téléphone. Dites par exemple : fais le diagnostic.";
        }
        return null;
    }

    private String diagnostic(String plain) {
        if (plain.contains("diagnostic") || plain.matches(".*\\b(?:etat du systeme|analyse (?:le|du) telephone|comment va le telephone|verifie (?:le|ton) (?:telephone|systeme)|bilan du telephone|rapport systeme)\\b.*")) {
            SystemReport.Result result = SystemReport.run(context, memory);
            speech = result.speech;
            return result.text;
        }
        return null;
    }

    // ---- Matériel ---------------------------------------------------------------------------------

    private String lamp(String plain) {
        if (plain.matches(".*\\b(?:allume|active|mets|met|ouvre)\\b.*\\b(?:lampe|torche|flash|lumiere)\\b.*")) return DeviceActions.torch(context, true);
        if (plain.matches(".*\\b(?:eteins|eteint|coupe|desactive|arrete|ferme)\\b.*\\b(?:lampe|torche|flash|lumiere)\\b.*")) return DeviceActions.torch(context, false);
        return null;
    }

    private String volume(String plain) {
        boolean about = plain.contains("volume") || plain.contains("le son") || plain.equals("silence") || plain.equals("mute");
        if (!about) return null;
        Matcher percent = Pattern.compile("(\\d{1,3})\\s*(?:%|pour cent|pourcent)?").matcher(plain);
        if (plain.matches(".*\\b(?:remets|remet|retablis|reactive|reactiver|reactives)\\b.*")) return DeviceActions.mute(context, false);
        if (plain.matches(".*\\b(?:maximum|a fond|au max)\\b.*")) return DeviceActions.volumePercent(context, 100);
        if (plain.matches(".*\\b(?:minimum)\\b.*")) return DeviceActions.volumePercent(context, 10);
        if (plain.matches(".*\\b(?:monte|augmente|hausse|plus fort)\\b.*")) return DeviceActions.volumeStep(context, 1);
        if (plain.matches(".*\\b(?:baisse|diminue|reduis|moins fort)\\b.*")) return DeviceActions.volumeStep(context, -1);
        if (plain.matches(".*\\b(?:coupe|mute|silence|eteins)\\b.*")) return DeviceActions.mute(context, true);
        if (percent.find()) return DeviceActions.volumePercent(context, Integer.parseInt(percent.group(1)));
        return null;
    }

    private String media(String plain) {
        if (plain.matches("^(?:pause|mets? (?:la |le )?(?:musique |video |lecture )?en pause|(?:stop|arrete|coupe) (?:la )?(?:musique|video|lecture))$")) {
            return DeviceActions.mediaKey(context, KeyEvent.KEYCODE_MEDIA_PAUSE, "Pause.");
        }
        if (plain.matches("^(?:reprends|reprend|reprendre|joue|remets|remet|continue|play|lecture)(?: (?:la|le|ma))?(?: musique| lecture| video| chanson)?$")) {
            return DeviceActions.mediaKey(context, KeyEvent.KEYCODE_MEDIA_PLAY, "Lecture.");
        }
        if (plain.matches("^(?:(?:chanson|piste|musique|morceau|video) suivante?|suivant|suivante|passe (?:la |cette )?(?:chanson|musique|piste|morceau)|next)$")) {
            return DeviceActions.mediaKey(context, KeyEvent.KEYCODE_MEDIA_NEXT, "Piste suivante.");
        }
        if (plain.matches("^(?:(?:chanson|piste|musique|morceau|video) precedente?|precedent|precedente|previous)$")) {
            return DeviceActions.mediaKey(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Piste précédente.");
        }
        return null;
    }

    private String alarmAndTimer(String plain) {
        Matcher wait = Pattern.compile("^attends?\\s+(\\d{1,3})\\s*(?:secondes?|sec|s)?$").matcher(plain);
        if (wait.find()) return "J'attends " + wait.group(1) + " secondes.";

        Matcher timer = Pattern.compile("(?:minuteur|chrono|chronometre|timer|compte a rebours)\\s*(?:de|pour)?\\s*(\\d+)\\s*(heures?|h|minutes?|min|secondes?|sec|s)\\b").matcher(plain);
        if (timer.find()) {
            long value = Long.parseLong(timer.group(1));
            String unit = timer.group(2);
            long seconds = value * (unit.startsWith("h") ? 3600 : (unit.startsWith("m") ? 60 : 1));
            if (seconds < 1 || seconds > 86400) return "Le minuteur doit durer entre 1 seconde et 24 heures.";
            return DeviceActions.timer(context, (int) seconds);
        }

        Matcher alarm = Pattern.compile("(?:alarme|reveille[- ]moi|reveil|sonne)\\b.*?\\b(?:a|pour|vers|de)\\s*(\\d{1,2})\\s*(?:heures?|h|:)\\s*(?:(\\d{1,2})|et (demie?|quart))?").matcher(plain);
        if (alarm.find()) {
            int hour = Integer.parseInt(alarm.group(1));
            int minute = 0;
            if (alarm.group(2) != null) minute = Integer.parseInt(alarm.group(2));
            else if (alarm.group(3) != null) minute = alarm.group(3).startsWith("d") ? 30 : 15;
            if ((plain.contains("du soir") || plain.contains("apres-midi") || plain.contains("apres midi")) && hour < 12) hour += 12;
            if (hour > 23 || minute > 59) return "Cette heure n'est pas valide. Dites par exemple : alarme à 6 heures 30.";
            return DeviceActions.alarm(context, hour, minute);
        }
        return null;
    }

    // ---- Appels et messages (toujours avec confirmation) --------------------------------------------

    private String contactProblem(String spoken) {
        if (ContactResolver.asNumber(spoken) == null && !ContactResolver.hasPermission(context)) {
            return "Je n'ai pas accès à vos contacts. Ouvrez HELIOS, Centre de commande, « Autoriser contacts, appels et SMS », ou donnez-moi directement le numéro.";
        }
        return "Je ne trouve pas « " + spoken + " » dans vos contacts.";
    }

    private String call(String raw, String plain) {
        Matcher match = Pattern.compile("^(?:appelle|appeler|telephone a|telephone|passe un appel a|passe un coup de fil a|compose|fais un appel a|contacte)\\s+(?:le |la |l')?(.+)$").matcher(plain);
        if (!match.find()) return null;
        String spoken = segment(raw, plain, match, 1);
        final ContactResolver.Contact contact = ContactResolver.find(context, spoken);
        if (contact == null) return contactProblem(spoken);
        boolean canCallDirectly = context.checkSelfPermission(android.Manifest.permission.CALL_PHONE)
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
        if (!canCallDirectly) return DeviceActions.call(context, contact);
        String question = "Je vais appeler " + contact.name + ". Confirmez-vous ?";
        PendingAction.set(question, () -> DeviceActions.call(context, contact));
        return question;
    }

    private String messages(String raw, String plain) {
        boolean whatsapp = plain.contains("whatsapp");
        boolean startsLikeSend = plain.matches("^(?:envoie|envoi|envoyer|ecris|ecrire|redige|dis|manda)\\b.*")
                || plain.matches("^(?:un |une )?(?:sms|message|texto|whatsapp|msg)\\b.*");
        boolean mentionsMessage = plain.matches(".*\\b(?:sms|message|texto|msg|whatsapp)\\b.*");
        // intention d'envoi nette : sinon « écris merci pour le message » reste une simple saisie de texte
        boolean strongSend = plain.matches("^(?:envoie|envoi|envoyer|dis|manda)\\b.*")
                || plain.matches("^(?:ecris|ecrire|redige)\\s+(?:a|au)\\s+.*")
                || plain.matches(".*\\b(?:sms|message|texto|msg|whatsapp)\\s+(?:a|au|pour)\\s+.*");
        if (!startsLikeSend || !mentionsMessage || !strongSend) return null;
        if (plain.matches("^(?:ouvre|lance|affiche|lis|lire)\\b.*")) return null;

        Matcher keyword = Pattern.compile("\\b(?:sms|message|texto|msg|whatsapp)\\b").matcher(plain);
        if (!keyword.find()) return null;
        Matcher to = Pattern.compile("\\b(?:a|au|pour)\\s+").matcher(plain);
        // le destinataire suit le mot « message » (« message à Jean ») ou le précède (« écris à Jean par SMS que… »)
        if (!to.find(keyword.start()) && !to.find(0)) return "À qui dois-je envoyer ce message ? Dites par exemple : envoie un message à Jean : bonjour.";
        int restStart = to.end();
        String restPlain = plain.substring(restStart);
        String restRaw = raw.length() == plain.length() ? raw.substring(restStart) : restPlain;

        String recipientPlain;
        String recipientRaw;
        String body;
        Matcher separator = Pattern.compile("\\s*:\\s*|\\s*,\\s*|\\s+(?:en )?disant(?: que)?\\s+|\\s+pour dire(?: que)?\\s+|\\s+que\\s+").matcher(restPlain);
        if (separator.find()) {
            recipientPlain = restPlain.substring(0, separator.start());
            recipientRaw = restRaw.substring(0, Math.min(separator.start(), restRaw.length()));
            body = restRaw.substring(Math.min(separator.end(), restRaw.length())).trim();
        } else {
            String[] words = restRaw.split("\\s+", 3);
            boolean article = words.length >= 3 && words[0].toLowerCase(Locale.ROOT).matches("mon|ma|mes|le|la");
            int take = article ? 2 : 1;
            String[] parts = restRaw.split("\\s+", take + 1);
            recipientRaw = parts[0] + (take == 2 && parts.length > 1 ? " " + parts[1] : "");
            recipientPlain = plainOf(recipientRaw);
            body = parts.length > take ? parts[take].trim() : "";
        }
        recipientRaw = recipientRaw.replaceAll("(?i)\\s+(?:sur|par|via)\\s+(?:whatsapp|sms|texto)$", "").trim();
        body = body.replaceFirst("(?i)^(?:sur|par|via)\\s+whatsapp\\s*[:,]?\\s*", "").trim();
        if (recipientRaw.isEmpty()) return "À qui dois-je envoyer ce message ?";
        if (body.isEmpty()) return "Que dois-je écrire à " + recipientRaw + " ? Dites par exemple : envoie un message à " + recipientRaw + " : bonjour.";

        final ContactResolver.Contact contact = ContactResolver.find(context, recipientRaw);
        if (contact == null) return contactProblem(recipientRaw);
        final String message = body;
        final String countryCode = memory.getPreference("country_code", "243");
        final boolean viaWhatsapp = whatsapp;
        String question = (viaWhatsapp
                ? "Je vais envoyer à " + contact.name + " sur WhatsApp : « " + message + " »."
                : "Je vais envoyer un SMS à " + contact.name + " : « " + message + " ».") + " Confirmez-vous ?";
        PendingAction.set(question, () -> viaWhatsapp
                ? DeviceActions.whatsapp(context, contact, message, countryCode)
                : DeviceActions.sms(context, contact, message));
        return question;
    }

    // ---- Navigation, web, YouTube -------------------------------------------------------------------

    private String navigation(String raw, String plain) {
        Matcher match = Pattern.compile("^(?:emmene[- ]moi|emmene|navigue|guide[- ]moi|conduis[- ]moi|itineraire|je veux aller|direction)\\s*(?:a|au|aux|vers|jusqu'a|jusqu'au|chez|sur)?\\s*(.+)$").matcher(plain);
        if (match.find()) return DeviceActions.navigate(context, segment(raw, plain, match, 1));

        Matcher youtube = Pattern.compile("^(?:cherche|recherche|trouve|joue|mets?|lance|ouvre)\\s+(.+?)\\s+sur\\s+youtube$").matcher(plain);
        if (youtube.find()) return DeviceActions.youtubeSearch(context, segment(raw, plain, youtube, 1));

        Matcher play = Pattern.compile("^(?:joue|jouer|fais jouer)\\s+(?:moi\\s+)?(?:la chanson |le morceau |la musique |le clip |du |de la )?(.+)$").matcher(plain);
        if (play.find()) return DeviceActions.youtubeSearch(context, segment(raw, plain, play, 1));
        return null;
    }

    private String web(String raw, String plain) {
        Matcher match = Pattern.compile("^(?:va sur|aller sur|ouvre le site|ouvre la page|ouvre le lien|visite|ouvre|lance)\\s+(.+)$").matcher(plain);
        if (!match.find()) return null;
        String candidate = match.group(1).replace(" point ", ".").replaceAll("\\s+", "");
        boolean isSite = candidate.matches("^(?:https?://)?(?:www\\.)?[a-z0-9-]+(?:\\.[a-z0-9-]+)*\\.[a-z]{2,}(?:/\\S*)?$");
        if (isSite) {
            String url = candidate.startsWith("http") ? candidate : "https://" + candidate;
            return DeviceActions.openUrl(context, url, "J'ouvre " + candidate + ".");
        }
        if (plain.startsWith("va sur") || plain.startsWith("aller sur")) {
            String spoken = segment(raw, plain, match, 1);
            AppResolver.Match app = AppResolver.find(context, spoken);
            if (app != null && AppResolver.launch(context, app)) return "J'ouvre " + app.label + ".";
            return DeviceActions.openUrl(context, "https://www.google.com/search?q=" + android.net.Uri.encode(spoken),
                    "Je cherche « " + spoken + " » sur Internet.");
        }
        return null;
    }

    // ---- Calcul, notifications, réglages -------------------------------------------------------------

    private String calculation(String plain) {
        boolean looksLikeCalc = plain.matches(".*\\b(?:combien font|combien fait|calcule|calcul|plus|moins|fois|multiplie par|divise par)\\b.*")
                || plain.matches(".*\\d\\s*[+*/x]\\s*\\d.*");
        if (!looksLikeCalc || !plain.matches(".*\\d.*")) return null;
        String result = MathEval.evaluate(plain);
        if (result == null) return null;
        speech = "Le résultat est " + result + ".";
        return "Résultat : " + result;
    }

    private String notifications(String plain) {
        if (!plain.contains("notification")) return null;
        if (plain.matches(".*\\b(?:ouvre|affiche|montre|baisse|volet|parametres)\\b.*")) return null;
        if (!plain.matches(".*\\b(?:lis|lire|quelles|quelle|mes|recentes|nouvelles|dernieres)\\b.*")) return null;
        if (!SystemAccess.isNotificationListenerEnabled(context)) {
            return "Je n'ai pas accès à vos notifications. Ouvrez HELIOS, Centre de commande, « Autoriser la lecture des notifications ».";
        }
        List<String> items = HeliosNotificationListener.recent(5);
        if (items.isEmpty()) return "Je n'ai reçu aucune nouvelle notification depuis que j'ai accès.";
        StringBuilder text = new StringBuilder("Vos dernières notifications :\n");
        StringBuilder spoken = new StringBuilder("Vos dernières notifications. ");
        for (String item : items) {
            text.append("• ").append(item).append('\n');
            spoken.append(item).append(". ");
        }
        speech = spoken.toString();
        return text.toString().trim();
    }

    private String settings(String plain) {
        Matcher country = Pattern.compile("^(?:code pays|indicatif)\\s+(?:est\\s+)?\\+?(\\d{1,3})$").matcher(plain);
        if (country.find()) {
            memory.savePreference("country_code", country.group(1));
            return "D'accord, l'indicatif pays pour WhatsApp est maintenant " + country.group(1) + ".";
        }
        if (plain.matches(".*\\b(?:masque|cache|enleve|retire|desactive)\\b.*\\bbulle\\b.*")) {
            memory.savePreference("bubble", "off");
            HeliosListenService.applyBubblePreference();
            return "Bulle masquée.";
        }
        if (plain.matches(".*\\b(?:affiche|montre|active|remets|remet)\\b.*\\bbulle\\b.*")) {
            memory.savePreference("bubble", "on");
            HeliosListenService.applyBubblePreference();
            return SystemAccess.canDrawOverlays(context) ? "Bulle affichée."
                    : "Pour afficher la bulle, autorisez « l'affichage par-dessus les autres applications » dans le Centre de commande.";
        }
        if (plain.matches("^(?:ferme|quitte|sors de)\\b.*") && plain.matches(".*\\b(?:application|appli|app|ecran|ca)\\b.*|^ferme$")) {
            HeliosAccessibilityService service = HeliosAccessibilityService.get();
            if (service == null) return NEED_ACCESSIBILITY;
            return service.home() ? "J'ai fermé l'application." : "Android a refusé cette action.";
        }
        return null;
    }

    /** Extrait un groupe du texte d'origine (avec accents et majuscules) quand l'alignement est possible. */
    private static String segment(String raw, String plain, Matcher matcher, int group) {
        if (raw.length() == plain.length()) {
            return raw.substring(matcher.start(group), matcher.end(group)).trim();
        }
        return matcher.group(group).trim();
    }
}
