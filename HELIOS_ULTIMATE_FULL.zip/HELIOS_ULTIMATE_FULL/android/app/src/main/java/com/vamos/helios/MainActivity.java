package com.vamos.helios;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.vamos.helios.core.LocalCommandEngine;
import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.modules.HeliosModule;
import com.vamos.helios.modules.ModuleRegistry;
import com.vamos.helios.modules.ModuleStatus;
import com.vamos.helios.services.RemoteAssistantClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 701;
    private LinearLayout root;
    private EditText commandInput;
    private TextView responseView;
    private TextView statusView;
    private LocalMemoryStore memory;
    private LocalCommandEngine commandEngine;
    private ModuleRegistry moduleRegistry;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private boolean voiceFallbackAttempted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        memory = new LocalMemoryStore(this);
        commandEngine = new LocalCommandEngine(this, memory);
        moduleRegistry = new ModuleRegistry();
        initializeSpeechOutput();
        buildInterface();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        root.setBackgroundColor(Color.rgb(7, 16, 29));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = new TextView(this);
        brand.setText("H E L I O S");
        brand.setTextColor(Color.rgb(64, 224, 208));
        brand.setTextSize(27);
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("ULTIMATE FULL  •  ASSISTANT PERSONNEL");
        subtitle.setTextColor(Color.rgb(165, 185, 205));
        subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(5), 0, dp(16));
        root.addView(subtitle, matchWrap());

        statusView = new TextView(this);
        statusView.setText("● NOYAU LOCAL PRÊT  |  INTERNET CONFIGURABLE");
        statusView.setTextColor(Color.rgb(116, 230, 180));
        statusView.setTextSize(12);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(12), dp(12), dp(12), dp(12));
        statusView.setBackgroundColor(Color.rgb(15, 36, 49));
        root.addView(statusView, matchWrap());

        TextView welcome = new TextView(this);
        welcome.setText("Bonjour. Je suis HELIOS.\nVotre assistant, en mode local ou connecté.");
        welcome.setTextColor(Color.WHITE);
        welcome.setTextSize(18);
        welcome.setGravity(Gravity.CENTER);
        welcome.setPadding(dp(12), dp(24), dp(12), dp(22));
        root.addView(welcome, matchWrap());

        TextView commandLabel = sectionTitle("COMMANDES VOCALES ET TEXTUELLES");
        root.addView(commandLabel, matchWrap());
        commandInput = new EditText(this);
        commandInput.setSingleLine(false);
        commandInput.setMinLines(2);
        commandInput.setTextSize(16);
        commandInput.setTextColor(Color.WHITE);
        commandInput.setHintTextColor(Color.rgb(145, 159, 176));
        commandInput.setHint("Ex. : Bonjour HELIOS, note acheter du pain…");
        commandInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        commandInput.setBackgroundColor(Color.rgb(21, 36, 53));
        commandInput.setImeOptions(EditorInfo.IME_ACTION_SEND);
        root.addView(commandInput, matchWrap());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(10), 0, dp(10));
        Button voiceButton = actionButton("🎙 Parler");
        Button sendButton = actionButton("Envoyer");
        actions.addView(voiceButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(0, dp(48), 1);
        sendParams.setMargins(dp(8), 0, 0, 0);
        actions.addView(sendButton, sendParams);
        root.addView(actions, matchWrap());
        voiceButton.setOnClickListener(v -> startVoiceInput());
        sendButton.setOnClickListener(v -> submitTypedCommand());
        commandInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitTypedCommand(); return true; }
            return false;
        });

        responseView = new TextView(this);
        responseView.setText("HELIOS vous écoute lorsque vous appuyez sur Parler.\nLe mot d'activation permanent « Bonjour HELIOS » sera ajouté avec un moteur local dédié et les autorisations nécessaires.");
        responseView.setTextColor(Color.rgb(225, 236, 245));
        responseView.setTextSize(15);
        responseView.setPadding(dp(15), dp(16), dp(15), dp(16));
        responseView.setBackgroundColor(Color.rgb(15, 30, 46));
        root.addView(responseView, matchWrap());

        root.addView(sectionTitle("ACCÈS RAPIDES"), withTopMargin(matchWrap(), 22));
        addQuickButton("📚 Mes notes", () -> showSavedItems("NOTES LOCALES", memory.getNotes()));
        addQuickButton("✅ Mes tâches", () -> showSavedItems("TÂCHES LOCALES", memory.getTasks()));
        addQuickButton("🧩 Modules et capacités", this::showModules);
        addQuickButton("🔔 Autoriser les notifications", () -> {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
            catch (Exception e) { showResponse("Écran des autorisations de notifications indisponible sur cet appareil.", false); }
        });
        addQuickButton("⚙ Configurer le serveur IA / synchronisation", this::showServerSettings);
        addQuickButton("⇄ Synchroniser mes notes et tâches", this::syncLocalData);
        addQuickButton("Effacer la mémoire de conversation IA", this::confirmClearConversation);

        TextView footer = new TextView(this);
        footer.setText("HELIOS • Prototype modulaire 1.0 • Vos notes restent sur cet appareil tant que vous ne configurez pas la synchronisation.");
        footer.setTextColor(Color.rgb(125, 145, 165));
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, 0);
        root.addView(footer, matchWrap());
    }

    private void submitTypedCommand() {
        String command = commandInput.getText().toString().trim();
        if (command.isEmpty()) return;
        commandInput.setText("");
        hideKeyboard();
        runCommand(command);
    }

    private void runCommand(String command) {
        String answer = commandEngine.execute(command);
        if (answer.startsWith("Je n'ai pas de réponse locale fiable")) {
            String endpoint = memory.getPreference("server_url", "").trim();
            String token = memory.getPreference("server_token", "").trim();
            if (!endpoint.isEmpty()) {
                showResponse("Je consulte le moteur intelligent…", false);
                org.json.JSONArray history = memory.getConversationHistory();
                memory.addConversationTurn("user", command);
                RemoteAssistantClient.ask(endpoint, token, command, history, new RemoteAssistantClient.Callback() {
                    @Override public void onSuccess(String reply) {
                        memory.addConversationTurn("assistant", reply);
                        runOnUiThread(() -> showResponse(reply, true));
                    }
                    @Override public void onError(String message) {
                        runOnUiThread(() -> showResponse(message + "\nJe reste disponible en mode local.", true));
                    }
                });
                return;
            }
        }
        showResponse(answer, true);
    }

    private void showResponse(String text, boolean speak) {
        responseView.setText(text);
        if (speak && ttsReady && textToSpeech != null) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "helios-reply");
        }
    }

    private void initializeSpeechOutput() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int languageStatus = textToSpeech.setLanguage(Locale.FRANCE);
                ttsReady = languageStatus != TextToSpeech.LANG_MISSING_DATA
                        && languageStatus != TextToSpeech.LANG_NOT_SUPPORTED;
                textToSpeech.setSpeechRate(0.94f);
                // Select a voice explicitly marked as male when the installed engine exposes that metadata.
                if (Build.VERSION.SDK_INT >= 21 && textToSpeech.getVoices() != null) {
                    Set<Voice> voices = textToSpeech.getVoices();
                    for (Voice voice : voices) {
                        String name = voice.getName().toLowerCase(Locale.ROOT);
                        boolean french = voice.getLocale() != null && "fr".equals(voice.getLocale().getLanguage());
                        boolean markedMale = name.contains("male") || name.contains("masculin") || name.contains("homme");
                        if (french && markedMale) { textToSpeech.setVoice(voice); break; }
                    }
                }
            }
        });
    }

    private void startVoiceInput() {
        voiceFallbackAttempted = false;
        startVoiceInput(true);
    }

    private void startVoiceInput(boolean preferOffline) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showResponse("Aucun service de reconnaissance vocale n'est disponible. Utilisez le champ texte ou installez une reconnaissance vocale compatible.", false);
            return;
        }
        try {
            if (speechRecognizer != null) speechRecognizer.destroy();
            if (preferOffline && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { statusView.setText("● HELIOS ÉCOUTE…"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { statusView.setText("● ANALYSE DE LA COMMANDE…"); }
                @Override public void onError(int error) {
                    if (preferOffline && !voiceFallbackAttempted
                            && (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED
                            || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) {
                        voiceFallbackAttempted = true;
                        statusView.setText("● ESSAI DE RECONNAISSANCE EN LIGNE…");
                        startVoiceInput(false);
                        return;
                    }
                    statusView.setText("● NOYAU LOCAL PRÊT");
                    String detail = error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED
                            || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE
                            ? "Le français hors ligne n'est pas disponible. Vérifiez votre connexion et le service vocal Google."
                            : "Vérifiez le microphone et le service de reconnaissance vocale.";
                    showResponse("Reconnaissance vocale impossible (code " + error + "). " + detail, false);
                }
                @Override public void onResults(Bundle results) {
                    statusView.setText("● NOYAU LOCAL PRÊT");
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) runCommand(matches.get(0));
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, preferOffline
                    ? "Parlez à HELIOS (mode hors ligne)" : "Parlez à HELIOS (mode connecté)");
            speechRecognizer.startListening(intent);
        } catch (Exception exception) {
            showResponse("Démarrage de la reconnaissance vocale impossible : " + exception.getMessage(), false);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startVoiceInput();
        } else if (requestCode == REQUEST_AUDIO) {
            showResponse("L'accès au microphone a été refusé. Vous pouvez continuer avec le clavier.", false);
        }
    }

    private void syncLocalData() {
        String endpoint = memory.getPreference("server_url", "").trim();
        String token = memory.getPreference("server_token", "").trim();
        if (endpoint.isEmpty()) {
            showResponse("Configurez d'abord l'URL du serveur HELIOS.", false);
            return;
        }
        org.json.JSONObject data = new org.json.JSONObject();
        try {
            data.put("notes", new org.json.JSONArray(memory.getNotes()));
            data.put("tasks", new org.json.JSONArray(memory.getTasks()));
        } catch (org.json.JSONException exception) {
            showResponse("Préparation de la synchronisation impossible.", false);
            return;
        }
        showResponse("Synchronisation en cours…", false);
        RemoteAssistantClient.sync(endpoint, token, data, new RemoteAssistantClient.Callback() {
            @Override public void onSuccess(String reply) {
                runOnUiThread(() -> {
                    try {
                        org.json.JSONObject merged = new org.json.JSONObject(reply);
                        memory.replaceSyncedItems(jsonArrayToStrings(merged.optJSONArray("notes")), jsonArrayToStrings(merged.optJSONArray("tasks")));
                        showResponse("Synchronisation terminée. Notes et tâches locales mises à jour.", false);
                    } catch (org.json.JSONException exception) {
                        showResponse("Le serveur a répondu, mais les données reçues sont illisibles.", false);
                    }
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> showResponse(message, false));
            }
        });
    }

    private List<String> jsonArrayToStrings(org.json.JSONArray array) {
        ArrayList<String> values = new ArrayList<>();
        if (array == null) return values;
        for (int i = 0; i < array.length(); i++) values.add(array.optString(i, ""));
        return values;
    }

    private void showServerSettings() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(8), dp(6), dp(8), dp(6));
        EditText endpoint = new EditText(this);
        endpoint.setSingleLine(true);
        endpoint.setHint("https://votre-domaine.tld/api/assistant.php");
        endpoint.setText(memory.getPreference("server_url", ""));
        EditText token = new EditText(this);
        token.setSingleLine(true);
        token.setHint("Jeton d'accès HELIOS (facultatif si serveur local)");
        token.setText(memory.getPreference("server_token", ""));
        form.addView(endpoint, matchWrap());
        form.addView(token, matchWrap());
        new AlertDialog.Builder(this)
                .setTitle("Connexion au serveur HELIOS")
                .setMessage("Le serveur permet la conversation IA et la synchronisation. Utilisez une adresse HTTPS publique. Ne partagez jamais votre jeton.")
                .setView(form)
                .setNegativeButton("Annuler", null)
                .setNeutralButton("Effacer", (dialog, which) -> {
                    memory.savePreference("server_url", "");
                    memory.savePreference("server_token", "");
                    showResponse("Configuration du serveur effacée.", false);
                })
                .setPositiveButton("Enregistrer", (dialog, which) -> {
                    String url = endpoint.getText().toString().trim();
                    if (!url.isEmpty() && !url.startsWith("https://")) {
                        Toast.makeText(this, "Utilisez HTTPS pour protéger les échanges.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    memory.savePreference("server_url", url);
                    memory.savePreference("server_token", token.getText().toString().trim());
                    showResponse(url.isEmpty() ? "Mode local uniquement." : "Serveur enregistré. Envoyez une question pour tester la connexion.", false);
                }).show();
    }

    private void confirmClearConversation() {
        new AlertDialog.Builder(this)
                .setTitle("Effacer la mémoire IA ?")
                .setMessage("Cette action supprime l'historique de conversation enregistré localement sur cet appareil. Les notes et les tâches ne seront pas touchées.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Effacer", (dialog, which) -> {
                    memory.clearConversationHistory();
                    showResponse("Mémoire de conversation effacée sur cet appareil.", false);
                }).show();
    }

    private void showModules() {
        List<HeliosModule> modules = moduleRegistry.all();
        String[] labels = new String[modules.size()];
        for (int i = 0; i < modules.size(); i++) {
            HeliosModule module = modules.get(i);
            labels[i] = module.displayName() + " — " + statusLabel(module.status()) + "\n" + module.description();
        }
        new AlertDialog.Builder(this)
                .setTitle("Modules HELIOS")
                .setItems(labels, (dialog, which) -> {
                    HeliosModule selected = modules.get(which);
                    showResponse(selected.displayName() + "\nÉtat : " + statusLabel(selected.status()) + "\n" + selected.description(), false);
                })
                .setPositiveButton("Fermer", null)
                .show();
    }

    private String statusLabel(ModuleStatus status) {
        switch (status) {
            case READY: return "disponible";
            case NEEDS_PERMISSION: return "autorisation à accorder";
            case NEEDS_CONFIGURATION: return "configuration requise";
            default: return "à développer";
        }
    }

    private void showSavedItems(String title, List<String> values) {
        if (values.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(title).setMessage("Aucun élément enregistré.").setPositiveButton("OK", null).show();
            return;
        }
        StringBuilder content = new StringBuilder();
        int start = Math.max(0, values.size() - 30);
        for (int i = start; i < values.size(); i++) content.append("• ").append(values.get(i)).append("\n\n");
        new AlertDialog.Builder(this).setTitle(title).setMessage(content.toString()).setPositiveButton("Fermer", null).show();
    }

    private void addQuickButton(String label, Runnable action) {
        Button button = actionButton(label);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(dp(15), 0, dp(12), 0);
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(8);
        root.addView(button, params);
        button.setOnClickListener(v -> action.run());
    }

    private TextView sectionTitle(String title) {
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(Color.rgb(64, 224, 208));
        label.setTextSize(11);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setPadding(0, dp(10), 0, dp(8));
        return label;
    }

    private Button actionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextAllCaps(false);
        button.setTextColor(Color.rgb(7, 16, 29));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(64, 224, 208)));
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams withTopMargin(LinearLayout.LayoutParams params, int margin) {
        params.topMargin = margin;
        return params;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void hideKeyboard() {
        try {
            android.view.inputmethod.InputMethodManager manager = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            manager.hideSoftInputFromWindow(commandInput.getWindowToken(), 0);
        } catch (Exception ignored) { }
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) { speechRecognizer.cancel(); speechRecognizer.destroy(); speechRecognizer = null; }
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        super.onDestroy();
    }
}
