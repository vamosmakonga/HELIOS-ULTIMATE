package com.vamos.helios;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.vamos.helios.core.HeliosBrain;
import com.vamos.helios.core.Speaker;
import com.vamos.helios.core.SystemAccess;
import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.modules.HeliosModule;
import com.vamos.helios.modules.ModuleRegistry;
import com.vamos.helios.modules.ModuleStatus;
import com.vamos.helios.services.HeliosListenService;
import com.vamos.helios.services.RemoteAssistantClient;
import com.vamos.helios.ui.HudView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Écran principal : réacteur HUD façon Jarvis, tableau de bord, journal, raccourcis et centre de commande. */
public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 701;
    private static final int REQUEST_HANDSFREE = 702;
    private static final int REQUEST_CONTACTS = 703;

    private static final int C_BG_TOP = Color.rgb(2, 8, 16);
    private static final int C_BG_BOTTOM = Color.rgb(5, 22, 38);
    private static final int C_MAIN = Color.rgb(0, 225, 255);
    private static final int C_TEXT = Color.rgb(206, 233, 244);
    private static final int C_DIM = Color.rgb(120, 156, 176);
    private static final int C_PANEL = Color.argb(120, 6, 30, 48);
    private static final int C_OK = Color.rgb(0, 255, 170);
    private static final int C_WARN = Color.rgb(255, 120, 90);
    private static final int C_DARK = Color.rgb(2, 12, 22);

    /** Raccourcis : { texte du bouton, commande envoyée }. Toutes ces commandes existent dans le moteur. */
    private static final String[][] CHIPS = {
            {"🩺 Diagnostic", "fais le diagnostic"},
            {"🔦 Lampe", "allume la lampe"},
            {"🔊 Volume +", "monte le volume"},
            {"🔉 Volume −", "baisse le volume"},
            {"⏯ Pause", "pause"},
            {"🔔 Lis mes notifs", "lis mes notifications"},
            {"🕐 Heure", "quelle heure"},
            {"📅 Date", "quelle date"},
            {"🔋 Batterie", "batterie"},
            {"📚 Notes", "mes notes"},
            {"✓ Tâches", "mes tâches"},
            {"📶 Wi-Fi", "ouvre wifi"},
            {"🔵 Bluetooth", "ouvre bluetooth"},
            {"💬 WhatsApp", "ouvre whatsapp"},
            {"▶ YouTube", "ouvre youtube"},
            {"📷 Caméra", "appareil photo"},
            {"⏰ Alarme", "alarme"},
            {"🗓 Agenda", "ouvre le calendrier"},
            {"🎵 Musique", "ouvre musique"},
            {"⚙ Réglages", "paramètres"},
            {"◀ Retour", "retour"},
            {"⌂ Accueil", "accueil"},
            {"🔔 Notifs", "ouvre les notifications"},
            {"👁 Lis l'écran", "lis l'écran"},
            {"🖼 Capture", "capture d'écran"},
            {"🚨 Urgence", "mode urgence"},
            {"❓ Aide", "aide"},
    };

    private static final String COMMAND_HELP =
            "DIAGNOSTIC ET ÉTAT\n• fais le diagnostic (rapport parlé complet)\n• quelle heure / quelle date / batterie\n• lis mes notifications\n\n"
            + "ACTIONS DIRECTES\n• allume / éteins la lampe\n• monte / baisse le volume, volume à 50, coupe le son\n• pause / reprends / suivant / précédent\n• alarme à 6 heures 30 / minuteur 10 minutes\n• combien font 12 fois 7\n\n"
            + "APPLICATIONS\n• ouvre [n'importe quelle application]\n• ouvre WhatsApp / YouTube / musique / calendrier\n• va sur [site.com]\n• cherche [sujet] sur YouTube / joue [chanson]\n• emmène-moi à [lieu]\n\n"
            + "APPELS ET MESSAGES (avec confirmation « oui »)\n• appelle [nom ou numéro]\n• envoie un SMS à [nom] : [texte]\n• envoie un message WhatsApp à [nom] : [texte]\n\n"
            + "ENCHAÎNER PLUSIEURS ACTIONS\n• ouvre WhatsApp puis clique sur Discussions\n• ouvre YouTube puis attends 3 secondes puis capture d'écran\n\n"
            + "CONTRÔLE DU TÉLÉPHONE (accessibilité activée)\n• retour / accueil / applications récentes\n• ouvre les notifications / paramètres rapides\n• capture d'écran / verrouille l'écran / ferme l'application\n• clique sur [texte affiché] / écris [texte]\n• défile vers le bas / le haut / lis l'écran\n\n"
            + "MÉMOIRE\n• note [texte] / mes notes\n• tâche [texte] / mes tâches\n• rappelle-moi [texte]\n\n"
            + "RÉGLAGES\n• arrête l'écoute\n• langue swahili / langue français\n• masque / affiche la bulle\n• code pays 243 (pour WhatsApp)\n• mode urgence (ouvre le composeur)";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SpannableStringBuilder logBuilder = new SpannableStringBuilder();

    private LocalMemoryStore memory;
    private HeliosBrain brain;
    private ModuleRegistry moduleRegistry;
    private SpeechRecognizer speechRecognizer;
    private boolean voiceHintShown = false;
    private boolean voiceFallbackAttempted = false;
    private boolean receiverRegistered = false;
    private String lastHeard = "";
    private int tick = 0;

    private LinearLayout root;
    private HudView hud;
    private TextView statusView;
    private TextView clockView;
    private TextView accessLineView;
    private TextView logView;
    private ScrollView logScroll;
    private EditText commandInput;
    private TextView micButton;
    private TextView handsFreeButton;
    private TextView tileTime, tileTimeSub, tileBattery, tileBatterySub, tileNotes, tileTasks;

    private final Runnable settleRunnable = () -> {
        hud.setState(baseState());
        setStatus(HeliosListenService.isRunning() ? "● HELIOS ÉCOUTE EN ARRIÈRE-PLAN" : "● EN VEILLE — PRÊT");
    };

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            tick++;
            updateClock();
            if (tick % 4 == 0) refreshDashboard();
            handler.postDelayed(this, 1000);
        }
    };

    /** Reçoit du service mains libres ce qui a été entendu et répondu. */
    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || hud == null) return;
            String state = intent.getStringExtra(HeliosListenService.EXTRA_STATE);
            String heard = intent.getStringExtra(HeliosListenService.EXTRA_HEARD);
            String reply = intent.getStringExtra(HeliosListenService.EXTRA_REPLY);
            if ("error".equals(state)) {
                hud.setState(HudView.State.ALERT);
                setStatus("● ÉCOUTE MAINS LIBRES : ERREUR");
                if (reply != null) appendLog("SYSTÈME", reply, C_WARN);
                settleLater(4000);
            } else if ("stopped".equals(state)) {
                hud.setState(HudView.State.IDLE);
                setStatus("● EN VEILLE — PRÊT");
            } else if ("listening".equals(state)) {
                hud.setState(HudView.State.LISTENING);
                setStatus("● HELIOS ÉCOUTE EN ARRIÈRE-PLAN");
            } else if ("thinking".equals(state)) {
                hud.setState(HudView.State.THINKING);
                setStatus("● ANALYSE…");
                logHeard(heard);
            } else if ("awake".equals(state)) {
                logHeard(heard);
                if (reply != null) {
                    appendLog("HELIOS", reply, C_MAIN);
                    lastHeard = ""; // permet de répéter deux fois la même commande
                    hud.setState(HudView.State.SPEAKING);
                    setStatus("● HELIOS RÉPOND");
                    settleLater(Math.min(20000L, 1500L + reply.length() * 70L));
                }
            }
            refreshDashboard();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        memory = new LocalMemoryStore(this);
        brain = new HeliosBrain(this, memory);
        moduleRegistry = new ModuleRegistry();
        initializeSpeechOutput();
        buildInterface();
        appendLog("SYSTÈME", "HELIOS en ligne. Dites « Bonjour HELIOS » (écoute mains libres) ou touchez un raccourci.", C_DIM);
        refreshDashboard();
    }

    // ------------------------------------------------------------------------------------------------
    // Interface
    // ------------------------------------------------------------------------------------------------

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        GradientDrawable background = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{C_BG_TOP, C_BG_BOTTOM});
        scroll.setBackground(background);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(26));
        scroll.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        // En-tête : nom + horloge
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = new TextView(this);
        brand.setText("H E L I O S");
        brand.setTextColor(C_MAIN);
        brand.setTextSize(24);
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        clockView = new TextView(this);
        clockView.setTextColor(C_TEXT);
        clockView.setTextSize(13);
        clockView.setTypeface(Typeface.MONOSPACE);
        header.addView(clockView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header, matchWrap());

        statusView = new TextView(this);
        statusView.setTextColor(C_OK);
        statusView.setTextSize(11);
        statusView.setTypeface(Typeface.MONOSPACE);
        statusView.setPadding(0, dp(2), 0, dp(6));
        root.addView(statusView, matchWrap());
        setStatus("● EN VEILLE — PRÊT");

        // Réacteur HUD
        hud = new HudView(this);
        hud.setLevelSource(HeliosListenService::getLevel);
        root.addView(hud, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));

        // Tableau de bord
        LinearLayout tiles = new LinearLayout(this);
        tiles.setOrientation(LinearLayout.HORIZONTAL);
        tiles.setPadding(0, dp(10), 0, 0);
        LinearLayout timeTile = makeTile("HEURE");
        tileTime = (TextView) timeTile.getChildAt(1);
        tileTimeSub = (TextView) timeTile.getChildAt(2);
        LinearLayout batteryTile = makeTile("BATTERIE");
        tileBattery = (TextView) batteryTile.getChildAt(1);
        tileBatterySub = (TextView) batteryTile.getChildAt(2);
        LinearLayout notesTile = makeTile("NOTES");
        tileNotes = (TextView) notesTile.getChildAt(1);
        ((TextView) notesTile.getChildAt(2)).setText("enregistrées");
        LinearLayout tasksTile = makeTile("TÂCHES");
        tileTasks = (TextView) tasksTile.getChildAt(1);
        ((TextView) tasksTile.getChildAt(2)).setText("à faire");
        addTile(tiles, timeTile, 1.25f, false);
        addTile(tiles, batteryTile, 1f, false);
        addTile(tiles, notesTile, 1f, false);
        addTile(tiles, tasksTile, 1f, true);
        notesTile.setOnClickListener(v -> showSavedItems("NOTES LOCALES", memory.getNotes()));
        tasksTile.setOnClickListener(v -> showSavedItems("TÂCHES LOCALES", memory.getTasks()));
        root.addView(tiles, matchWrap());

        accessLineView = new TextView(this);
        accessLineView.setTextSize(11);
        accessLineView.setTypeface(Typeface.MONOSPACE);
        accessLineView.setPadding(dp(4), dp(10), dp(4), dp(2));
        accessLineView.setOnClickListener(v -> showDiagnostics());
        root.addView(accessLineView, matchWrap());

        // Écoute mains libres
        handsFreeButton = hudButton("", true);
        handsFreeButton.setOnClickListener(v -> toggleHandsFree());
        LinearLayout.LayoutParams handsFreeParams = matchWrap();
        handsFreeParams.topMargin = dp(8);
        root.addView(handsFreeButton, handsFreeParams);

        // Raccourcis de commandes
        root.addView(sectionTitle("RACCOURCIS — TOUCHEZ POUR EXÉCUTER"), matchWrap());
        HorizontalScrollView chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        for (String[] chip : CHIPS) {
            TextView view = hudButton(chip[0], false);
            view.setTextSize(13);
            view.setPadding(dp(14), dp(10), dp(14), dp(10));
            final String command = chip[1];
            view.setOnClickListener(v -> submit(command));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.rightMargin = dp(8);
            chipRow.addView(view, params);
        }
        chipScroll.addView(chipRow);
        root.addView(chipScroll, matchWrap());

        // Journal de conversation
        root.addView(sectionTitle("JOURNAL DE CONVERSATION"), matchWrap());
        logScroll = new ScrollView(this);
        logScroll.setBackground(box(C_PANEL, Color.argb(110, 0, 225, 255), 10));
        logScroll.setOnTouchListener((v, event) -> {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            return false;
        });
        logView = new TextView(this);
        logView.setTextColor(C_TEXT);
        logView.setTextSize(13);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setPadding(dp(12), dp(10), dp(12), dp(10));
        logScroll.addView(logView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(logScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(210)));

        // Saisie : champ + micro + envoyer
        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(0, dp(10), 0, 0);
        commandInput = new EditText(this);
        commandInput.setSingleLine(true);
        commandInput.setTextSize(15);
        commandInput.setTextColor(Color.WHITE);
        commandInput.setHintTextColor(C_DIM);
        commandInput.setHint("Écrire une commande…");
        commandInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        commandInput.setBackground(box(C_PANEL, Color.argb(160, 0, 225, 255), 24));
        commandInput.setImeOptions(EditorInfo.IME_ACTION_SEND);
        inputRow.addView(commandInput, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        micButton = hudButton("🎙", false);
        micButton.setTextSize(18);
        LinearLayout.LayoutParams micParams = new LinearLayout.LayoutParams(dp(50), dp(48));
        micParams.leftMargin = dp(8);
        inputRow.addView(micButton, micParams);
        TextView sendButton = hudButton("➤", true);
        sendButton.setTextSize(18);
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(50), dp(48));
        sendParams.leftMargin = dp(8);
        inputRow.addView(sendButton, sendParams);
        root.addView(inputRow, matchWrap());
        micButton.setOnClickListener(v -> startSingleVoiceInput());
        sendButton.setOnClickListener(v -> submitTypedCommand());
        commandInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitTypedCommand(); return true; }
            return false;
        });

        buildCommandCenter();

        TextView footer = new TextView(this);
        footer.setText("HELIOS 2.0 • Vos notes et tâches restent sur ce téléphone tant que la synchronisation n'est pas configurée.");
        footer.setTextColor(Color.rgb(90, 118, 138));
        footer.setTextSize(10);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(20), 0, 0);
        root.addView(footer, matchWrap());
    }

    private void buildCommandCenter() {
        TextView toggle = hudButton("☷  CENTRE DE COMMANDE  •  OUVRIR", false);
        LinearLayout.LayoutParams toggleParams = matchWrap();
        toggleParams.topMargin = dp(16);
        root.addView(toggle, toggleParams);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(6), dp(10), dp(12));
        panel.setBackground(box(C_PANEL, Color.argb(90, 0, 225, 255), 10));
        panel.setVisibility(View.GONE);
        root.addView(panel, matchWrap());
        toggle.setOnClickListener(v -> {
            boolean opening = panel.getVisibility() != View.VISIBLE;
            panel.setVisibility(opening ? View.VISIBLE : View.GONE);
            toggle.setText(opening ? "☷  CENTRE DE COMMANDE  •  FERMER" : "☷  CENTRE DE COMMANDE  •  OUVRIR");
        });

        panelLabel(panel, "AUTORISATIONS");
        addPanelButton(panel, "♿ Activer l'accessibilité (contrôle du téléphone)", this::enableAccessibility);
        addPanelButton(panel, "🔓 Accessibilité grisée ? Paramètres restreints", this::showRestrictedSettingsHelp);
        addPanelButton(panel, "🔋 Autoriser HELIOS en arrière-plan (batterie)", () -> {
            if (!SystemAccess.requestIgnoreBatteryOptimizations(this)) respond("Écran de batterie indisponible sur cet appareil.", false);
        });
        addPanelButton(panel, "🪟 Autoriser l'affichage par-dessus les autres apps", () -> {
            if (!SystemAccess.requestOverlayPermission(this)) respond("Écran indisponible sur cet appareil.", false);
        });
        addPanelButton(panel, "🔔 Autoriser la lecture des notifications", () -> {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
            catch (Exception e) { respond("Écran des autorisations de notifications indisponible sur cet appareil.", false); }
        });
        addPanelButton(panel, "📇 Autoriser contacts, appels et SMS", this::requestActionPermissions);
        addPanelButton(panel, "🩺 Diagnostic : micro, écoute, accessibilité", this::showDiagnostics);
        addPanelButton(panel, "🔊 Tester la voix de HELIOS", this::testVoice);
        addPanelButton(panel, "🗣 Réparer / installer la voix française", () -> {
            if (!Speaker.openVoiceSetup(this)) respond("Impossible d'ouvrir les réglages de synthèse vocale. Installez « Synthèse vocale Google » depuis le Play Store.", false);
        });

        panelLabel(panel, "MÉMOIRE");
        addPanelButton(panel, "📚 Mes notes", () -> showSavedItems("NOTES LOCALES", memory.getNotes()));
        addPanelButton(panel, "✓ Mes tâches", () -> showSavedItems("TÂCHES LOCALES", memory.getTasks()));
        addPanelButton(panel, "＋ Ajouter une note", () -> promptMemoryEntry(false));
        addPanelButton(panel, "＋ Ajouter une tâche", () -> promptMemoryEntry(true));

        panelLabel(panel, "SYSTÈME");
        addPanelButton(panel, "📖 Toutes les commandes disponibles", this::showCommandHelp);
        addPanelButton(panel, "🧩 Modules et capacités", this::showModules);
        addPanelButton(panel, "⚙ Configurer le serveur IA / synchronisation", this::showServerSettings);
        addPanelButton(panel, "⇄ Synchroniser mes notes et tâches", this::syncLocalData);
        addPanelButton(panel, "🗑 Effacer la mémoire de conversation IA", this::confirmClearConversation);
    }

    // ---- Tableau de bord ---------------------------------------------------------------------------

    private LinearLayout makeTile(String title) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        tile.setPadding(dp(4), dp(8), dp(4), dp(8));
        tile.setBackground(box(C_PANEL, Color.argb(120, 0, 225, 255), 10));
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(C_DIM);
        label.setTextSize(9);
        label.setTypeface(Typeface.MONOSPACE);
        label.setGravity(Gravity.CENTER);
        tile.addView(label, matchWrap());
        TextView value = new TextView(this);
        value.setTextColor(C_MAIN);
        value.setTextSize(19);
        value.setTypeface(Typeface.DEFAULT_BOLD);
        value.setGravity(Gravity.CENTER);
        value.setSingleLine(true);
        tile.addView(value, matchWrap());
        TextView sub = new TextView(this);
        sub.setTextColor(C_DIM);
        sub.setTextSize(9);
        sub.setGravity(Gravity.CENTER);
        sub.setSingleLine(true);
        tile.addView(sub, matchWrap());
        return tile;
    }

    private void addTile(LinearLayout row, LinearLayout tile, float weight, boolean last) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        if (!last) params.rightMargin = dp(6);
        row.addView(tile, params);
    }

    private void updateClock() {
        Date now = new Date();
        String time = new SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(now);
        clockView.setText(time);
        tileTime.setText(new SimpleDateFormat("HH:mm", Locale.FRANCE).format(now));
        tileTimeSub.setText(new SimpleDateFormat("EEE d MMM", Locale.FRANCE).format(now));
    }

    private void refreshDashboard() {
        if (tileNotes == null) return;
        updateClock();
        tileNotes.setText(String.valueOf(memory.getNotes().size()));
        tileTasks.setText(String.valueOf(memory.getTasks().size()));
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
            int percent = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
            tileBattery.setText(percent >= 0 ? percent + "%" : "--");
            tileBattery.setTextColor(percent >= 0 && percent <= 15 && !charging ? C_WARN : C_MAIN);
            tileBatterySub.setText(charging ? "en charge ⚡" : "sur batterie");
        }
        accessLineView.setText(accessLine());
        updateHandsFreeButton();
        boolean on = HeliosListenService.isRunning();
        hud.setCornerTexts("HELIOS // OS 2.0", "SYSTÈME EN LIGNE",
                "VOIX " + memory.getPreference("voice_lang", "fr-FR").toUpperCase(Locale.ROOT),
                on ? "MAINS LIBRES : ON" : "MAINS LIBRES : OFF");
    }

    private CharSequence accessLine() {
        SpannableStringBuilder builder = new SpannableStringBuilder();
        appendStatus(builder, "MICRO", SystemAccess.hasAudioPermission(this));
        appendStatus(builder, "ACCESSIBILITÉ", SystemAccess.isAccessibilityEnabled(this));
        appendStatus(builder, "ÉCOUTE", HeliosListenService.isRunning());
        appendStatus(builder, "ARRIÈRE-PLAN", SystemAccess.isIgnoringBatteryOptimizations(this));
        return builder;
    }

    private void appendStatus(SpannableStringBuilder builder, String label, boolean ok) {
        int start = builder.length();
        builder.append(ok ? "● " : "○ ").append(label).append("  ");
        builder.setSpan(new ForegroundColorSpan(ok ? C_OK : C_WARN), start, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void updateHandsFreeButton() {
        if (handsFreeButton == null) return;
        boolean on = HeliosListenService.isRunning();
        handsFreeButton.setText(on
                ? "⏹  ÉCOUTE MAINS LIBRES : ACTIVE\nDites « Bonjour HELIOS » — toucher pour arrêter"
                : "🎧  ACTIVER L'ÉCOUTE MAINS LIBRES\nDites « Bonjour HELIOS » téléphone posé");
        handsFreeButton.setTextColor(on ? C_DARK : C_MAIN);
        handsFreeButton.setBackground(on
                ? pressable(C_OK, Color.rgb(0, 200, 140), C_OK, 12)
                : pressable(C_PANEL, Color.argb(200, 0, 90, 110), C_MAIN, 12));
    }

    // ------------------------------------------------------------------------------------------------
    // Journal et état
    // ------------------------------------------------------------------------------------------------

    private void appendLog(String who, String text, int color) {
        if (logView == null || text == null || text.trim().isEmpty()) return;
        String time = new SimpleDateFormat("HH:mm", Locale.FRANCE).format(new Date());
        SpannableStringBuilder entry = new SpannableStringBuilder();
        String header = time + "  " + who + "\n";
        entry.append(header);
        entry.setSpan(new ForegroundColorSpan(color), 0, header.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int bodyStart = entry.length();
        entry.append(text).append("\n\n");
        entry.setSpan(new ForegroundColorSpan(C_TEXT), bodyStart, bodyStart + text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        logBuilder.append(entry);
        if (logBuilder.length() > 9000) {
            int cut = logBuilder.length() - 6000;
            int boundary = logBuilder.toString().indexOf("\n\n", cut);
            if (boundary > 0) cut = boundary + 2;
            logBuilder.delete(0, cut);
        }
        logView.setText(logBuilder);
        logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void logHeard(String heard) {
        if (heard == null || heard.trim().isEmpty() || heard.equals(lastHeard)) return;
        lastHeard = heard;
        appendLog("VOUS", heard, Color.rgb(150, 190, 255));
    }

    private void setStatus(String text) {
        if (statusView != null) statusView.setText(text);
    }

    private HudView.State baseState() {
        return HeliosListenService.isRunning() ? HudView.State.LISTENING : HudView.State.IDLE;
    }

    private void settleLater(long delayMs) {
        handler.removeCallbacks(settleRunnable);
        handler.postDelayed(settleRunnable, delayMs);
    }

    /** Affiche et (si demandé) dit la réponse. */
    private void respond(String text, boolean speak) {
        respondFull(text, speak ? text : "");
    }

    /** display = texte affiché ; speech = texte dit (null = identique au texte affiché, "" = ne rien dire). */
    private void respondFull(String display, String speech) {
        appendLog("HELIOS", display, C_MAIN);
        refreshDashboard();
        String toSay = speech == null ? display : speech;
        if (toSay.trim().isEmpty()) {
            settleLater(700);
            return;
        }
        hud.setState(HudView.State.SPEAKING);
        setStatus("● HELIOS RÉPOND");
        long guard = Math.min(30000L, 3000L + toSay.length() * 80L);
        if (HeliosListenService.isRunning()) {
            HeliosListenService.say(this, toSay);
        } else {
            Speaker speaker = Speaker.get(this);
            warnAboutVoice(speaker);
            speaker.speak(toSay, () -> settleLater(300));
        }
        settleLater(guard);
    }

    /** Une seule fois par session : dit pourquoi HELIOS ne se fait pas entendre. */
    private void warnAboutVoice(Speaker speaker) {
        if (voiceHintShown) return;
        if (speaker.isFailed() || (speaker.isReady() && !speaker.hasFrench()) || speaker.isMediaVolumeZero()) {
            voiceHintShown = true;
            appendLog("SYSTÈME", speaker.status() + "\nCentre de commande → « Réparer / installer la voix française ».", C_WARN);
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Commandes
    // ------------------------------------------------------------------------------------------------

    private void submitTypedCommand() {
        String command = commandInput.getText().toString().trim();
        if (command.isEmpty()) return;
        commandInput.setText("");
        hideKeyboard();
        submit(command);
    }

    private void submit(String command) {
        appendLog("VOUS", command, Color.rgb(150, 190, 255));
        runCommand(command);
    }

    private void runCommand(String command) {
        hud.setState(HudView.State.THINKING);
        setStatus("● ANALYSE…");
        brain.handle(command, (display, speech) -> runOnUiThread(() -> respondFull(display, speech)));
    }

    // ------------------------------------------------------------------------------------------------
    // Voix dans l'application (une phrase) et synthèse vocale
    // ------------------------------------------------------------------------------------------------

    private void initializeSpeechOutput() {
        Speaker.get(this); // démarre le moteur vocal et choisit la langue
    }

    private void startSingleVoiceInput() {
        if (HeliosListenService.isRunning()) {
            respond("L'écoute mains libres est déjà active : dites simplement « Bonjour HELIOS » suivi de votre commande.", false);
            return;
        }
        voiceFallbackAttempted = false;
        startVoiceInput(true);
    }

    private void startVoiceInput(boolean preferOffline) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Aucun service de reconnaissance vocale n'est disponible. Installez ou activez l'application Google, ou utilisez le champ texte.", false);
            return;
        }
        final String language = memory.getPreference("voice_lang", "fr-FR");
        try {
            if (speechRecognizer != null) speechRecognizer.destroy();
            if (preferOffline && Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    hud.setState(HudView.State.LISTENING);
                    setStatus("● HELIOS ÉCOUTE…");
                }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { hud.pushLevel((rmsdB + 2f) / 12f); }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() {
                    hud.setState(HudView.State.THINKING);
                    setStatus("● ANALYSE…");
                }
                @Override public void onError(int error) {
                    if (preferOffline && !voiceFallbackAttempted
                            && (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED
                            || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) {
                        voiceFallbackAttempted = true;
                        setStatus("● ESSAI DE RECONNAISSANCE EN LIGNE…");
                        startVoiceInput(false);
                        return;
                    }
                    hud.setState(HudView.State.ALERT);
                    String detail;
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        detail = "Je n'ai rien entendu. Touchez le micro et parlez.";
                    } else if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED
                            || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE) {
                        detail = "Cette langue n'est pas disponible hors ligne. Vérifiez votre connexion et le service vocal Google.";
                    } else {
                        detail = "Vérifiez le microphone et le service de reconnaissance vocale (code " + error + ").";
                    }
                    appendLog("SYSTÈME", detail, C_WARN);
                    settleLater(2500);
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null
                            : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) {
                        submit(matches.get(0));
                    } else {
                        settleLater(300);
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            speechRecognizer.startListening(intent);
        } catch (Exception exception) {
            respond("Démarrage de la reconnaissance vocale impossible : " + exception.getMessage(), false);
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Écoute mains libres, accessibilité, diagnostic
    // ------------------------------------------------------------------------------------------------

    private void toggleHandsFree() {
        if (HeliosListenService.isRunning()) {
            startService(new Intent(this, HeliosListenService.class).setAction(HeliosListenService.ACTION_STOP));
            handler.postDelayed(this::refreshDashboard, 500);
            respond("Écoute mains libres arrêtée.", false);
            return;
        }
        if (speechRecognizer != null) speechRecognizer.cancel(); // un seul micro à la fois
        ArrayList<String> missing = new ArrayList<>();
        if (!SystemAccess.hasAudioPermission(this)) missing.add(Manifest.permission.RECORD_AUDIO);
        if (!SystemAccess.hasNotificationPermission(this)) missing.add("android.permission.POST_NOTIFICATIONS");
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQUEST_HANDSFREE);
            return;
        }
        startHandsFree();
    }

    private void startHandsFree() {
        if (!SystemAccess.hasAudioPermission(this)) {
            respond("Le microphone est nécessaire pour l'écoute mains libres.", false);
            return;
        }
        try {
            startForegroundService(new Intent(this, HeliosListenService.class).setAction(HeliosListenService.ACTION_START));
        } catch (Exception exception) {
            respond("Impossible de démarrer l'écoute : " + exception.getMessage(), false);
            return;
        }
        hud.setState(HudView.State.LISTENING);
        setStatus("● HELIOS ÉCOUTE EN ARRIÈRE-PLAN");
        appendLog("HELIOS", "Écoute mains libres activée. Dites : « Bonjour HELIOS, quelle heure est-il ? ». Pour qu'elle survive écran éteint, autorisez aussi HELIOS en arrière-plan (Centre de commande).", C_MAIN);
        handler.postDelayed(this::refreshDashboard, 700);
    }

    private void enableAccessibility() {
        if (SystemAccess.isAccessibilityEnabled(this)) {
            respond("Le service d'accessibilité HELIOS est déjà activé.", false);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Activer le contrôle du téléphone")
                .setMessage("Dans l'écran qui s'ouvre : Applications installées (ou Services téléchargés) → HELIOS – contrôle du téléphone → activer.\n\n"
                        + "Si l'interrupteur est grisé ou Android dit « Paramètre restreint », utilisez le bouton « Accessibilité grisée ».\n\n"
                        + "HELIOS n'agit que sur votre commande et n'écrit jamais dans les champs de mot de passe.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Ouvrir", (dialog, which) -> {
                    if (!SystemAccess.openAccessibilitySettings(this)) respond("Réglages d'accessibilité indisponibles sur cet appareil.", false);
                }).show();
    }

    private void showRestrictedSettingsHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Autoriser les paramètres restreints")
                .setMessage("Android bloque l'accessibilité des applications installées hors Play Store.\n\n"
                        + "1. Appuyez sur « Ouvrir Infos de l'appli ».\n"
                        + "2. Touchez les trois points ⋮ en haut à droite.\n"
                        + "3. Choisissez « Autoriser les paramètres restreints » (confirmez avec l'empreinte ou le code).\n"
                        + "4. Revenez et activez le service HELIOS dans Accessibilité.\n\n"
                        + "Si ⋮ n'apparaît pas : essayez d'abord d'activer l'accessibilité une fois (le message de blocage fait apparaître l'option), puis revenez ici.")
                .setNegativeButton("Fermer", null)
                .setPositiveButton("Ouvrir Infos de l'appli", (dialog, which) -> {
                    if (!SystemAccess.openAppDetails(this)) respond("Écran des infos de l'application indisponible.", false);
                }).show();
    }

    private void showDiagnostics() {
        new AlertDialog.Builder(this)
                .setTitle("Diagnostic HELIOS")
                .setMessage(SystemAccess.diagnostics(this))
                .setPositiveButton("Fermer", null)
                .show();
    }

    private void requestActionPermissions() {
        ArrayList<String> missing = new ArrayList<>();
        for (String permission : new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS}) {
            if (!SystemAccess.hasPermission(this, permission)) missing.add(permission);
        }
        if (missing.isEmpty()) {
            respond("Contacts, appels et SMS sont déjà autorisés. Dites : appelle [nom] ou envoie un message à [nom] : [texte].", false);
            return;
        }
        requestPermissions(missing.toArray(new String[0]), REQUEST_CONTACTS);
    }

    private void testVoice() {
        Speaker speaker = Speaker.get(this);
        respondFull("Test de la voix.\n" + speaker.status(),
                "Bonjour, je suis HELIOS. Si vous m'entendez, ma voix fonctionne.");
    }

    private void showCommandHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Commandes disponibles")
                .setMessage(COMMAND_HELP)
                .setPositiveButton("Fermer", null)
                .show();
    }

    // ------------------------------------------------------------------------------------------------
    // Cycle de vie
    // ------------------------------------------------------------------------------------------------

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(HeliosListenService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(statusReceiver, filter);
        receiverRegistered = true;
        HeliosListenService.setUiVisible(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard();
        handler.removeCallbacks(ticker);
        handler.postDelayed(ticker, 1000);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(statusReceiver); } catch (IllegalArgumentException ignored) { }
            receiverRegistered = false;
        }
        HeliosListenService.setUiVisible(false);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) { speechRecognizer.cancel(); speechRecognizer.destroy(); speechRecognizer = null; }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_HANDSFREE) {
            // Les notifications refusées n'empêchent pas l'écoute ; seul le micro est indispensable.
            if (SystemAccess.hasAudioPermission(this)) startHandsFree();
            else respond("L'accès au microphone a été refusé. L'écoute mains libres a besoin du micro.", false);
            return;
        }
        if (requestCode == REQUEST_CONTACTS) {
            int granted = 0;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted++;
            respond(granted == grantResults.length && granted > 0
                    ? "Contacts, appels et SMS autorisés. Essayez : « Bonjour HELIOS, appelle [nom] »."
                    : "Certaines autorisations ont été refusées. Sans contacts, je ne peux appeler que par numéro ; sans SMS, j'ouvre l'application de messages.", true);
            return;
        }
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                voiceFallbackAttempted = false;
                startVoiceInput(true);
            } else {
                respond("L'accès au microphone a été refusé. Vous pouvez continuer avec le clavier.", false);
            }
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Mémoire locale, serveur, modules
    // ------------------------------------------------------------------------------------------------

    private void syncLocalData() {
        String endpoint = memory.getPreference("server_url", "").trim();
        String token = memory.getPreference("server_token", "").trim();
        if (endpoint.isEmpty()) {
            respond("Configurez d'abord l'URL du serveur HELIOS.", false);
            return;
        }
        org.json.JSONObject data = new org.json.JSONObject();
        try {
            data.put("notes", new org.json.JSONArray(memory.getNotes()));
            data.put("tasks", new org.json.JSONArray(memory.getTasks()));
        } catch (org.json.JSONException exception) {
            respond("Préparation de la synchronisation impossible.", false);
            return;
        }
        respond("Synchronisation en cours…", false);
        RemoteAssistantClient.sync(endpoint, token, data, new RemoteAssistantClient.Callback() {
            @Override public void onSuccess(String reply) {
                runOnUiThread(() -> {
                    try {
                        org.json.JSONObject merged = new org.json.JSONObject(reply);
                        memory.replaceSyncedItems(jsonArrayToStrings(merged.optJSONArray("notes")), jsonArrayToStrings(merged.optJSONArray("tasks")));
                        respond("Synchronisation terminée. Notes et tâches locales mises à jour.", false);
                    } catch (org.json.JSONException exception) {
                        respond("Le serveur a répondu, mais les données reçues sont illisibles.", false);
                    }
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> respond(message, false));
            }
        });
    }

    private List<String> jsonArrayToStrings(org.json.JSONArray array) {
        ArrayList<String> values = new ArrayList<>();
        if (array == null) return values;
        for (int i = 0; i < array.length(); i++) values.add(array.optString(i, ""));
        return values;
    }

    private void showServerSettings() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(8), dp(6), dp(8), dp(6));
        EditText endpoint = new EditText(this);
        endpoint.setSingleLine(true);
        endpoint.setHint("https://votre-domaine.tld/api/assistant.php");
        endpoint.setText(memory.getPreference("server_url", ""));
        EditText token = new EditText(this);
        token.setSingleLine(true);
        token.setHint("Jeton d'accès HELIOS (facultatif si serveur local)");
        token.setText(memory.getPreference("server_token", ""));
        form.addView(endpoint, matchWrap());
        form.addView(token, matchWrap());
        new AlertDialog.Builder(this)
                .setTitle("Connexion au serveur HELIOS")
                .setMessage("Le serveur permet la conversation IA et la synchronisation. Utilisez une adresse HTTPS publique. Ne partagez jamais votre jeton.")
                .setView(form)
                .setNegativeButton("Annuler", null)
                .setNeutralButton("Effacer", (dialog, which) -> {
                    memory.savePreference("server_url", "");
                    memory.savePreference("server_token", "");
                    respond("Configuration du serveur effacée.", false);
                })
                .setPositiveButton("Enregistrer", (dialog, which) -> {
                    String url = endpoint.getText().toString().trim();
                    if (!url.isEmpty() && !url.startsWith("https://")) {
                        Toast.makeText(this, "Utilisez HTTPS pour protéger les échanges.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    memory.savePreference("server_url", url);
                    memory.savePreference("server_token", token.getText().toString().trim());
                    respond(url.isEmpty() ? "Mode local uniquement." : "Serveur enregistré. Envoyez une question pour tester la connexion.", false);
                }).show();
    }

    private void confirmClearConversation() {
        new AlertDialog.Builder(this)
                .setTitle("Effacer la mémoire IA ?")
                .setMessage("Cette action supprime l'historique de conversation enregistré localement sur cet appareil. Les notes et les tâches ne seront pas touchées.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Effacer", (dialog, which) -> {
                    memory.clearConversationHistory();
                    respond("Mémoire de conversation effacée sur cet appareil.", false);
                }).show();
    }

    private void showModules() {
        List<HeliosModule> modules = moduleRegistry.all();
        String[] labels = new String[modules.size()];
        for (int i = 0; i < modules.size(); i++) {
            HeliosModule module = modules.get(i);
            labels[i] = module.displayName() + " — " + statusLabel(module.status()) + "\n" + module.description();
        }
        new AlertDialog.Builder(this)
                .setTitle("Modules HELIOS")
                .setItems(labels, (dialog, which) -> {
                    HeliosModule selected = modules.get(which);
                    respond(selected.displayName() + "\nÉtat : " + statusLabel(selected.status()) + "\n" + selected.description(), false);
                })
                .setPositiveButton("Fermer", null)
                .show();
    }

    private String statusLabel(ModuleStatus status) {
        switch (status) {
            case READY: return "disponible";
            case NEEDS_PERMISSION: return "autorisation à accorder";
            case NEEDS_CONFIGURATION: return "configuration requise";
            default: return "à développer";
        }
    }

    private void showSavedItems(String title, List<String> values) {
        if (values.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(title).setMessage("Aucun élément enregistré.").setPositiveButton("OK", null).show();
            return;
        }
        StringBuilder content = new StringBuilder();
        int start = Math.max(0, values.size() - 30);
        for (int i = start; i < values.size(); i++) content.append("• ").append(values.get(i)).append("\n\n");
        new AlertDialog.Builder(this).setTitle(title).setMessage(content.toString()).setPositiveButton("Fermer", null).show();
    }

    private void promptMemoryEntry(boolean task) {
        EditText field = new EditText(this);
        field.setHint(task ? "Ex. : Étudier JavaScript" : "Ex. : Appeler mon client demain");
        new AlertDialog.Builder(this)
                .setTitle(task ? "Nouvelle tâche" : "Nouvelle note")
                .setView(field)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Enregistrer", (dialog, which) -> {
                    String value = field.getText().toString().trim();
                    if (value.isEmpty()) {
                        Toast.makeText(this, "Écrivez d'abord un texte.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (task) memory.addTask(value); else memory.addNote(value);
                    respond(task ? "Tâche enregistrée sur ce téléphone." : "Note enregistrée sur ce téléphone.", true);
                }).show();
    }

    // ------------------------------------------------------------------------------------------------
    // Fabrication des éléments visuels
    // ------------------------------------------------------------------------------------------------

    private GradientDrawable box(int fill, int strokeColor, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private StateListDrawable pressable(int fill, int pressedFill, int strokeColor, int radiusDp) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, box(pressedFill, strokeColor, radiusDp));
        states.addState(new int[]{}, box(fill, strokeColor, radiusDp));
        return states;
    }

    /** Bouton HUD. strong = plein (action principale), sinon contour lumineux. */
    private TextView hudButton(String label, boolean strong) {
        TextView button = new TextView(this);
        button.setText(label);
        button.setGravity(Gravity.CENTER);
        button.setTextSize(strong ? 14 : 13);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setClickable(true);
        button.setFocusable(true);
        button.setPadding(dp(12), dp(12), dp(12), dp(12));
        if (strong) {
            button.setTextColor(C_DARK);
            button.setBackground(pressable(C_MAIN, Color.rgb(0, 170, 200), C_MAIN, 12));
        } else {
            button.setTextColor(C_MAIN);
            button.setBackground(pressable(C_PANEL, Color.argb(200, 0, 90, 110), Color.argb(190, 0, 225, 255), 12));
        }
        return button;
    }

    private void addPanelButton(LinearLayout panel, String label, Runnable action) {
        TextView button = hudButton(label, false);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(dp(14), dp(12), dp(10), dp(12));
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(6);
        panel.addView(button, params);
        button.setOnClickListener(v -> action.run());
    }

    private void panelLabel(LinearLayout panel, String title) {
        TextView label = sectionTitle(title);
        label.setPadding(dp(2), dp(10), 0, dp(2));
        panel.addView(label, matchWrap());
    }

    private TextView sectionTitle(String title) {
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(C_MAIN);
        label.setTextSize(10);
        label.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        label.setLetterSpacing(0.12f);
        label.setPadding(dp(2), dp(16), 0, dp(6));
        return label;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void hideKeyboard() {
        try {
            android.view.inputmethod.InputMethodManager manager =
                    (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            manager.hideSoftInputFromWindow(commandInput.getWindowToken(), 0);
        } catch (Exception ignored) { }
    }
}
