package com.vamos.helios.core;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.Normalizer;
import java.util.Locale;

/** Calcul à la voix : « combien font 12 fois 7 », « 250 plus 130 moins 20 »… */
public final class MathEval {
    private MathEval() { }

    /** @return le résultat prêt à dire, ou null si la phrase n'est pas un calcul. */
    public static String evaluate(String spoken) {
        String expression = prepare(spoken);
        if (expression == null) return null;
        try {
            Parser parser = new Parser(expression);
            double value = parser.parseExpression();
            if (parser.position != expression.length() || Double.isNaN(value) || Double.isInfinite(value)) return null;
            return format(value);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    private static String prepare(String spoken) {
        if (spoken == null) return null;
        String text = Normalizer.normalize(spoken, Normalizer.Form.NFD).replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT);
        text = text.replaceAll("combien (?:font|fait|est|vaut|ca fait)|calcule|calcul|quel est le resultat de|resultat de|egale?|\\?", " ");
        text = text.replace(',', '.');
        text = text.replaceAll("(?<=\\d)\\s*x\\s*(?=\\d)", "*");
        text = text.replaceAll("\\bmultiplie(?:e)? par\\b|\\bfois\\b", "*");
        text = text.replaceAll("\\bdivise(?:e)? par\\b", "/");
        text = text.replaceAll("\\bplus\\b", "+").replaceAll("\\bmoins\\b", "-");
        text = text.replaceAll("\\s+", "");
        if (text.isEmpty() || !text.matches("[0-9+\\-*/().]+") || !text.matches(".*[0-9].*")) return null;
        if (!text.matches(".*[+\\-*/].*")) return null;
        return text;
    }

    private static String format(double value) {
        BigDecimal number = new BigDecimal(value).setScale(4, RoundingMode.HALF_UP).stripTrailingZeros();
        String plain = number.toPlainString();
        return plain.replace('.', ',');
    }

    private static final class Parser {
        private final String text;
        int position = 0;

        Parser(String text) { this.text = text; }

        double parseExpression() {
            double value = parseTerm();
            while (position < text.length()) {
                char c = text.charAt(position);
                if (c == '+') { position++; value += parseTerm(); }
                else if (c == '-') { position++; value -= parseTerm(); }
                else break;
            }
            return value;
        }

        double parseTerm() {
            double value = parseFactor();
            while (position < text.length()) {
                char c = text.charAt(position);
                if (c == '*') { position++; value *= parseFactor(); }
                else if (c == '/') {
                    position++;
                    double divisor = parseFactor();
                    if (divisor == 0) throw new ArithmeticException("division par zéro");
                    value /= divisor;
                } else break;
            }
            return value;
        }

        double parseFactor() {
            if (position >= text.length()) throw new IllegalArgumentException("fin inattendue");
            char c = text.charAt(position);
            if (c == '-') { position++; return -parseFactor(); }
            if (c == '+') { position++; return parseFactor(); }
            if (c == '(') {
                position++;
                double value = parseExpression();
                if (position >= text.length() || text.charAt(position) != ')') throw new IllegalArgumentException("parenthèse");
                position++;
                return value;
            }
            int start = position;
            while (position < text.length() && (Character.isDigit(text.charAt(position)) || text.charAt(position) == '.')) position++;
            if (start == position) throw new IllegalArgumentException("nombre attendu");
            return Double.parseDouble(text.substring(start, position));
        }
    }
}
