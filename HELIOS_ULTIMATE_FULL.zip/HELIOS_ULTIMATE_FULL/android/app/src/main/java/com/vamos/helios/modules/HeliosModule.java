package com.vamos.helios.modules;

/** Contract implemented by every native HELIOS feature module. */
public interface HeliosModule {
    String id();
    String displayName();
    String description();
    ModuleStatus status();
}
