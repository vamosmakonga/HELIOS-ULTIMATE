package com.vamos.helios.core;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Détection tolérante du mot d'activation « HELIOS ».
 * Le moteur vocal d'Android transcrit souvent le mot de travers (« hélio », « elios », « Éliot »…),
 * donc on compare de façon floue au lieu d'exiger l'orthographe exacte.
 */
public final class WakeWord {
    private static final String TARGET = "helios";
    private static final Set<String> KNOWN = new HashSet<>(Arrays.asList(
            "helios", "elios", "helio", "elio", "helyos", "elyos", "heliot", "eliot",
            "helliot", "elliot", "helious", "helioss", "elios", "ellios", "hellios", "helios"));

    private WakeWord() { }

    /**
     * @return null si le mot d'activation est absent ; "" s'il est seul ;
     *         sinon la suite de la phrase (la commande).
     */
    public static String commandAfterWake(String transcript) {
        if (transcript == null) return null;
        String[] words = transcript.trim().split("\\s+");
        for (int i = 0; i < words.length; i++) {
            if (isWake(normalize(words[i]))) return join(words, i + 1);
            if (i + 1 < words.length && isWake(normalize(words[i] + words[i + 1]))) return join(words, i + 2);
        }
        return null;
    }

    static boolean isWake(String n) {
        if (n.length() < 4 || n.length() > 8) return false;
        if (KNOWN.contains(n)) return true;
        if (n.equals("elias") || n.equals("helas")) return false; // prénoms courants, pas le mot d'activation
        char first = n.charAt(0);
        if (first != 'h' && first != 'e') return false;
        if (n.indexOf('l') < 0) return false;
        return levenshtein(n, TARGET) <= 1 || levenshtein(n, "elios") <= 1;
    }

    static String normalize(String word) {
        String decomposed = Normalizer.normalize(word, Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }

    private static String join(String[] words, int from) {
        StringBuilder builder = new StringBuilder();
        for (int i = from; i < words.length; i++) {
            if (builder.length() > 0) builder.append(' ');
            builder.append(words[i]);
        }
        return builder.toString().replaceFirst("^[\\s,;:.!?-]+", "").trim();
    }

    private static int levenshtein(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous; previous = current; current = swap;
        }
        return previous[b.length()];
    }
}
