package com.vamos.helios.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import com.vamos.helios.MainActivity;

/**
 * Bulle flottante HELIOS : un petit réacteur qui reste par-dessus les autres applications.
 * Toucher = ouvrir HELIOS ; glisser = déplacer. Une fenêtre visible permet aussi à HELIOS de lancer
 * des applications depuis l'arrière-plan (Android l'interdit sinon).
 */
public final class OverlayBubble {
    private final Context context;
    private final WindowManager windowManager;
    private HudView view;
    private WindowManager.LayoutParams params;
    private boolean visible = false;
    private int savedX = -1;
    private int savedY = -1;

    public OverlayBubble(Context context) {
        this.context = context;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
    }

    public boolean isVisible() { return visible; }

    private int dp(int value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }

    /** @return false si l'autorisation « par-dessus les autres applications » manque. */
    public boolean show(HudView.LevelSource levelSource) {
        if (visible) return true;
        try {
            if (!Settings.canDrawOverlays(context)) return false;
            view = new HudView(context);
            view.setCompact(true);
            view.setLevelSource(levelSource);
            int size = dp(74);
            params = new WindowManager.LayoutParams(size, size,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            params.x = savedX >= 0 ? savedX : dp(8);
            params.y = savedY >= 0 ? savedY : dp(150);
            view.setOnTouchListener(new DragListener());
            windowManager.addView(view, params);
            visible = true;
            return true;
        } catch (Exception exception) {
            view = null;
            visible = false;
            return false;
        }
    }

    public void hide() {
        if (!visible || view == null) return;
        try {
            savedX = params.x;
            savedY = params.y;
            windowManager.removeView(view);
        } catch (Exception ignored) { }
        view = null;
        visible = false;
    }

    public void setState(HudView.State state) {
        if (view != null) view.setState(state);
    }

    private final class DragListener implements View.OnTouchListener {
        private float downRawX, downRawY;
        private int startX, startY;
        private boolean moved;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = event.getRawX();
                    downRawY = event.getRawY();
                    startX = params.x;
                    startY = params.y;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = event.getRawX() - downRawX;
                    float dy = event.getRawY() - downRawY;
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                    if (moved) {
                        params.x = Math.max(0, startX + Math.round(dx));
                        params.y = Math.max(0, startY + Math.round(dy));
                        try { windowManager.updateViewLayout(view, params); } catch (Exception ignored) { }
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        Intent open = new Intent(context, MainActivity.class)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        try { context.startActivity(open); } catch (Exception ignored) { }
                    }
                    return true;
                default:
                    return false;
            }
        }
    }
}
