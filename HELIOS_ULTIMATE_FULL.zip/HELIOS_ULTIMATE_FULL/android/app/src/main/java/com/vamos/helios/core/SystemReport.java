package com.vamos.helios.core;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;

import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.services.HeliosListenService;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Diagnostic complet du téléphone : un rapport écrit et un résumé parlé, comme « Jarvis, fais le diagnostic ». */
public final class SystemReport {
    public static final class Result {
        public final String text;
        public final String speech;
        Result(String text, String speech) { this.text = text; this.speech = speech; }
    }

    private SystemReport() { }

    public static Result run(Context context, LocalMemoryStore memory) {
        List<String> lines = new ArrayList<>();
        List<String> alerts = new ArrayList<>();
        StringBuilder speech = new StringBuilder("Diagnostic terminé. ");

        // Batterie
        Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int percent = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
            int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
            float temperature = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            String health = healthLabel(battery.getIntExtra(BatteryManager.EXTRA_HEALTH, -1));
            lines.add(String.format(Locale.FRANCE, "Batterie : %d %% • %s • %.0f °C • santé %s",
                    percent, charging ? "en charge" : "sur batterie", temperature, health));
            speech.append("Batterie à ").append(percent).append(" pour cent")
                    .append(charging ? ", en charge. " : ". ");
            if (percent >= 0 && percent <= 20 && !charging) alerts.add("batterie faible, branchez le chargeur");
            if (temperature >= 42f) alerts.add("le téléphone chauffe : " + Math.round(temperature) + " degrés");
        }

        // Stockage
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
            double free = stat.getAvailableBytes() / 1_073_741_824d;
            double total = stat.getTotalBytes() / 1_073_741_824d;
            lines.add(String.format(Locale.FRANCE, "Stockage : %.1f Go libres sur %.0f Go", free, total));
            speech.append(String.format(Locale.FRANCE, "Stockage : %.0f gigaoctets libres sur %.0f. ", free, total));
            if (total > 0 && free / total < 0.10) alerts.add("stockage presque plein");
        } catch (Exception ignored) { }

        // Mémoire vive
        try {
            ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            double free = info.availMem / 1_073_741_824d;
            double total = info.totalMem / 1_073_741_824d;
            lines.add(String.format(Locale.FRANCE, "Mémoire vive : %.1f Go disponibles sur %.1f Go", free, total));
            speech.append(String.format(Locale.FRANCE, "Mémoire vive : %.1f gigaoctet disponible. ", free));
            if (info.lowMemory) alerts.add("mémoire vive très basse, fermez des applications");
        } catch (Exception ignored) { }

        // Réseau
        String network = networkLabel(context);
        lines.add("Réseau : " + network);
        speech.append("Connexion : ").append(network).append(". ");
        if (network.startsWith("aucune")) alerts.add("pas de connexion Internet");

        // Volume, démarrage, applications
        try {
            AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            int volume = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
            int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            lines.add("Volume média : " + volume + " sur " + max);
            if (volume == 0) alerts.add("le volume média est à zéro, je ne pourrai pas me faire entendre");
        } catch (Exception ignored) { }
        long minutes = SystemClock.elapsedRealtime() / 60000L;
        lines.add(String.format(Locale.FRANCE, "Allumé depuis : %d h %02d", minutes / 60, minutes % 60));
        try {
            Intent launcher = new Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER);
            lines.add("Applications installées : " + context.getPackageManager().queryIntentActivities(launcher, 0).size());
        } catch (Exception ignored) { }
        lines.add("Système : Android " + Build.VERSION.RELEASE + " • " + Build.MANUFACTURER + " " + Build.MODEL);

        // État de HELIOS lui-même
        boolean mic = SystemAccess.hasAudioPermission(context);
        boolean accessibility = SystemAccess.isAccessibilityEnabled(context);
        boolean listening = HeliosListenService.isRunning();
        boolean overlay = SystemAccess.canDrawOverlays(context);
        boolean contacts = context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
        lines.add("HELIOS : micro " + mark(mic) + " • écoute " + mark(listening) + " • accessibilité " + mark(accessibility)
                + " • bulle/arrière-plan " + mark(overlay) + " • contacts " + mark(contacts));
        lines.add("Voix : " + Speaker.get(context).status());
        lines.add("Mémoire : " + memory.getNotes().size() + " notes, " + memory.getTasks().size() + " tâches");

        if (!accessibility) alerts.add("l'accessibilité est désactivée : je ne peux pas encore toucher l'écran à votre place");
        if (!overlay) alerts.add("l'affichage par-dessus les autres applications n'est pas autorisé : j'aurai du mal à ouvrir des applications en arrière-plan");
        if (!contacts) alerts.add("l'accès aux contacts manque pour appeler par nom");
        if (!SystemAccess.isIgnoringBatteryOptimizations(context)) alerts.add("Android peut me couper en arrière-plan : autorisez HELIOS dans les réglages de batterie");

        StringBuilder text = new StringBuilder("DIAGNOSTIC COMPLET\n");
        for (String line : lines) text.append("• ").append(line).append('\n');
        if (alerts.isEmpty()) {
            text.append("\nAucune anomalie détectée.");
            speech.append("Aucune anomalie détectée. Tous les systèmes sont opérationnels.");
        } else {
            text.append("\nÀ surveiller :\n");
            speech.append(alerts.size() == 1 ? "Un point à surveiller : " : alerts.size() + " points à surveiller. ");
            for (int i = 0; i < alerts.size(); i++) {
                text.append("⚠ ").append(alerts.get(i)).append('\n');
                if (i < 3) speech.append(alerts.get(i)).append(". ");
            }
        }
        return new Result(text.toString().trim(), speech.toString().trim());
    }

    private static String mark(boolean ok) { return ok ? "✔" : "✖"; }

    private static String healthLabel(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "bonne";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "surchauffe";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "défaillante";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "surtension";
            case BatteryManager.BATTERY_HEALTH_COLD: return "froide";
            default: return "inconnue";
        }
    }

    private static String networkLabel(Context context) {
        try {
            ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network active = manager.getActiveNetwork();
            if (active == null) return "aucune connexion";
            NetworkCapabilities capabilities = manager.getNetworkCapabilities(active);
            if (capabilities == null) return "aucune connexion";
            String kind = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi"
                    : capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "données mobiles"
                    : capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "câble" : "réseau";
            boolean internet = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            return kind + (internet ? ", Internet disponible" : ", sans accès Internet");
        } catch (Exception exception) {
            return "état inconnu";
        }
    }
}
