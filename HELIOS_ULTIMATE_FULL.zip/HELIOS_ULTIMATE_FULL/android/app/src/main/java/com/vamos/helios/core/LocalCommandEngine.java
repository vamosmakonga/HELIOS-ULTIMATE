package com.vamos.helios.core;

import android.content.Context;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;

import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.services.HeliosAccessibilityService;
import com.vamos.helios.services.HeliosListenService;

import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small offline command router. New command families should be added as separate modules. */
public final class LocalCommandEngine {
    /** Début de la réponse renvoyée quand aucune commande locale ne correspond. */
    public static final String NO_LOCAL_ANSWER = "Je n'ai pas de réponse locale fiable";
    private static final String NEED_ACCESSIBILITY =
            "Le service d'accessibilité HELIOS n'est pas activé. Ouvrez HELIOS, Centre de commande, puis « Activer l'accessibilité ».";

    private final Context context;
    private final LocalMemoryStore memory;

    public LocalCommandEngine(Context context, LocalMemoryStore memory) {
        this.context = context;
        this.memory = memory;
    }

    public String execute(String rawCommand) {
        String raw = rawCommand == null ? "" : rawCommand.trim();
        String command = raw.toLowerCase(Locale.ROOT);
        command = command.replaceFirst("^(bonjour|salut|ok)?\\s*helios[,:;.!?]?\\s*", "").trim();
        if (command.isEmpty()) return "Bonjour. HELIOS est prêt. Que puis-je faire pour vous ?";
        raw = raw.replaceFirst("(?i)^(bonjour|salut|ok)?\\s*helios[,:;.!?]?\\s*", "").trim();
        if (raw.isEmpty()) raw = "bonjour";
        memory.rememberLastCommand(raw);

        if (containsAny(command, "bonjour helios", "salut helios", "bonjour", "salut")) {
            return "Bonjour. HELIOS est prêt. Que puis-je faire pour vous ?";
        }
        if (containsAny(command, "quelle heure", "donne l'heure", "il est quelle heure")) {
            return "Il est " + new SimpleDateFormat("HH:mm", Locale.FRANCE).format(new Date()) + ".";
        }
        if (containsAny(command, "quelle date", "on est quel jour", "date d'aujourd'hui")) {
            return "Nous sommes le " + new SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(new Date()) + ".";
        }
        if (startsWithAny(command, "note ", "ajoute une note ", "ajoute note ", "prends note ", "prend note ", "enregistre une note ", "écris une note ", "ecris une note ", "ajoute une note ", "ajoute-moi une note ", "ajoute moi une note ")) {
            String note = raw.replaceFirst("(?i)^(note|ajoute une note|ajoute note|prends note|prend note|enregistre une note|écris une note|ecris une note|ajoute-moi une note|ajoute moi une note)\\s*", "").trim();
            if (note.isEmpty()) return "Dites : note suivie du texte à conserver.";
            memory.addNote(note);
            return "Note enregistrée sur cet appareil.";
        }
        if (containsAny(command, "mes notes", "affiche les notes", "liste les notes")) {
            List<String> notes = memory.getNotes();
            if (notes.isEmpty()) return "Vous n'avez pas encore de note.";
            return "Vos dernières notes :\n" + tail(notes, 8);
        }
        if (startsWithAny(command, "rappelle-moi ", "rappelle moi ")) {
            String reminder = raw.replaceFirst("(?i)^rappelle[- ]moi\\s*", "").trim();
            if (reminder.isEmpty()) return "Dites : rappelle-moi suivi du rappel à conserver.";
            memory.addTask("Rappel : " + reminder);
            return "Rappel ajouté à votre liste locale. Il ne déclenche pas encore de notification programmée.";
        }
        if (startsWithAny(command, "tache ", "tâche ", "ajoute une tâche ", "ajoute une tache ", "ajoute tâche ", "ajoute tache ", "crée une tâche ", "cree une tache ", "nouvelle tâche ", "nouvelle tache ", "ajoute-moi une tâche ", "ajoute moi une tâche ", "crée tâche ", "cree tache ")) {
            String task = raw.replaceFirst("(?i)^(tache|tâche|ajoute une tâche|ajoute une tache|ajoute tâche|ajoute tache|crée une tâche|cree une tache|nouvelle tâche|nouvelle tache|ajoute-moi une tâche|ajoute moi une tâche|crée tâche|cree tache)\\s*", "").trim();
            if (task.isEmpty()) return "Dites : tâche suivie du travail à faire.";
            memory.addTask(task);
            return "Tâche enregistrée dans votre liste locale.";
        }
        if (containsAny(command, "mes tâches", "mes taches", "affiche les tâches", "affiche les taches")) {
            List<String> tasks = memory.getTasks();
            if (tasks.isEmpty()) return "Votre liste de tâches est vide.";
            return "Vos tâches :\n" + tail(tasks, 8);
        }
        String systemAnswer = systemCommand(command, raw);
        if (systemAnswer != null) return systemAnswer;
        if (containsAny(command, "batterie", "niveau de batterie", "charge restante")) {
            Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery == null) return "Je ne peux pas lire l'état de la batterie pour le moment.";
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int percent = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
            int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL ? "Le téléphone est en charge." : "Le téléphone n'est pas en charge.";
            return percent >= 0 ? "Batterie : " + percent + " %. " + charging : charging;
        }
        if (containsAny(command, "ouvre wifi", "ouvre wi-fi", "paramètres wifi", "parametres wifi")) {
            return launch(new Intent(Settings.ACTION_WIFI_SETTINGS), "J'ouvre les paramètres Wi-Fi.");
        }
        if (containsAny(command, "ouvre bluetooth", "paramètres bluetooth", "parametres bluetooth")) {
            return launch(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "J'ouvre les paramètres Bluetooth.");
        }
        if (startsWithAny(command, "minuteur ", "chrono ", "chronomètre ", "chronometre ")) {
            String amount = raw.replaceFirst("(?i)^(minuteur|chrono|chronomètre|chronometre)\\s*", "").trim().toLowerCase(Locale.ROOT);
            java.util.regex.Matcher timer = java.util.regex.Pattern.compile("(\\d+)\\s*(h|heure|heures|min|minute|minutes|s|sec|seconde|secondes)?").matcher(amount);
            if (!timer.find()) return "Dites par exemple : minuteur 5 minutes, minuteur 30 secondes ou minuteur 1 heure.";
            int value = Integer.parseInt(timer.group(1));
            String unit = timer.group(2) == null ? "minutes" : timer.group(2);
            int seconds = value * (unit.startsWith("h") ? 3600 : (unit.startsWith("s") ? 1 : 60));
            if (seconds < 1 || seconds > 86400) return "Le minuteur doit être compris entre 1 seconde et 24 heures.";
            Intent setTimer = new Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "HELIOS")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            return launch(setTimer, "Je prépare le minuteur. Vérifiez-le puis confirmez dans l'application Horloge.");
        }
        if (startsWithAny(command, "événement ", "evenement ", "ajoute événement ", "ajoute evenement ")) {
            String title = raw.replaceFirst("(?i)^(ajoute )?(événement|evenement)\\s*", "").trim();
            if (title.isEmpty()) return "Dites : événement suivi du titre à ajouter au calendrier.";
            Intent event = new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title);
            return launch(event, "Je prépare l'événement dans votre calendrier. Vérifiez la date et enregistrez-le.");
        }
        if (containsAny(command, "paramètres", "parametres", "réglages android", "reglages android")) {
            return launch(new Intent(Settings.ACTION_SETTINGS), "J'ouvre les paramètres Android.");
        }
        if (containsAny(command, "appareil photo", "ouvre la caméra", "ouvre la camera", "prends une photo")) {
            return launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE), "J'ouvre l'appareil photo.");
        }
        if (containsAny(command, "alarme", "réveil", "reveil", "ouvre l'horloge")) {
            if (tryStart(new Intent(AlarmClock.ACTION_SHOW_ALARMS))) return "J'ouvre les alarmes. Vérifiez l'heure avant de confirmer.";
            return launch(new Intent(AlarmClock.ACTION_SET_ALARM), "J'ouvre les alarmes. Vérifiez l'heure avant de confirmer.");
        }
        if (containsAny(command, "ouvre le calendrier", "ouvre l'agenda", "mon calendrier")) {
            return launch(new Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI), "J'ouvre le calendrier.");
        }
        if (startsWithAny(command, "recherche ", "cherche sur internet ", "cherche ")) {
            String query = raw.replaceFirst("(?i)^(recherche|cherche sur internet|cherche)\\s*", "").trim();
            if (query.isEmpty()) return "Que dois-je rechercher ?";
            Intent search = new Intent(Intent.ACTION_WEB_SEARCH);
            search.putExtra("query", query);
            if (tryStart(search)) return "Je lance la recherche sur Internet.";
            return launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))),
                    "Je lance la recherche sur Internet.");
        }
        if (startsWithAny(command, "appelle ", "compose le ", "compose ")) {
            String number = raw.replaceFirst("(?i)^(appelle|compose le|compose)\\s*", "").trim();
            String dialable = number.replaceAll("[^0-9+*#]", "");
            return launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + dialable)),
                    "J'ouvre le composeur. Vous gardez la confirmation de l'appel.");
        }
        if (startsWithAny(command, "sms ", "message à ", "message a ")) {
            String target = raw.replaceFirst("(?i)^(sms|message à|message a)\\s*", "").trim();
            return launch(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(target))),
                    "J'ouvre votre application SMS pour préparer le message.");
        }
        if (startsWithAny(command, "whatsapp message ", "message whatsapp ")) {
            String text = raw.replaceFirst("(?i)^(whatsapp message|message whatsapp)\\s*", "").trim();
            if (text.isEmpty()) return "Dites : WhatsApp message suivi du texte à partager.";
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, text);
            try {
                Intent chooser = Intent.createChooser(share, "Choisir une application pour envoyer le message");
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(chooser);
                return "Texte préparé. Choisissez WhatsApp et vérifiez le destinataire avant l'envoi.";
            } catch (ActivityNotFoundException exception) {
                return "Aucune application compatible avec le partage n'est disponible.";
            }
        }
        if (startsWithAny(command, "email ", "e-mail ", "courriel ")) {
            String address = raw.replaceFirst("(?i)^(email|e-mail|courriel)\\s*", "").trim();
            return launch(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(address))),
                    "J'ouvre l'application e-mail pour préparer votre message.");
        }
        if (startsWithAny(command, "carte ", "itinéraire ", "itineraire ", "localise ")) {
            String place = raw.replaceFirst("(?i)^(carte|itinéraire|itineraire|localise)\\s*", "").trim();
            return launch(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))),
                    "J'ouvre une application de cartes pour ce lieu.");
        }
        if (containsAny(command, "ouvre whatsapp", "lance whatsapp")) {
            if (launchPackage("com.whatsapp")) return "WhatsApp est ouvert.";
            if (launchPackage("com.whatsapp.w4b")) return "WhatsApp Business est ouvert.";
            return "WhatsApp n'est pas installé ou n'est pas visible par Android.";
        }
        if (containsAny(command, "ouvre musique", "lance musique", "ouvre lecteur audio")) {
            Intent music = new Intent(Intent.ACTION_MAIN);
            music.addCategory(Intent.CATEGORY_APP_MUSIC);
            return launch(music, "J'ouvre votre lecteur de musique.");
        }
        if (containsAny(command, "ouvre youtube", "lance youtube")) {
            if (launchPackage("com.google.android.youtube")) return "YouTube est ouvert.";
            return launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.youtube.com")), "J'ouvre YouTube dans le navigateur.");
        }
        if (startsWithAny(command, "ouvre ", "lance ")) {
            String wanted = raw.replaceFirst("(?i)^(ouvre|lance)\\s*", "").trim();
            if (openAppByLabel(wanted)) return "J'ouvre " + wanted + ".";
            return "Je ne trouve pas l'application « " + wanted + " ». Essayez son nom exact.";
        }
        if (containsAny(command, "urgence", "aide urgente", "mode urgence")) {
            return launch(new Intent(Intent.ACTION_DIAL),
                    "Mode urgence : le composeur s'ouvre. Composez le numéro d'urgence officiel de votre région et appelez uniquement en cas de besoin réel.");
        }
        if (containsAny(command, "aide", "que peux-tu faire", "commandes disponibles")) {
            return "Commandes locales : heure, date, niveau de batterie, notes, tâches, rappels, minuteur 5 minutes, événement [titre], ouvre Wi-Fi, ouvre Bluetooth, ouvre une application, appareil photo, paramètres, WhatsApp, SMS, appel (confirmation manuelle), e-mail, carte, musique, recherche Internet et mode urgence.";
        }
        return NO_LOCAL_ANSWER + " à cette demande. Le mode conversation IA nécessite de configurer le serveur HELIOS. Je peux déjà gérer les notes, les tâches et les commandes Android disponibles.";
    }

    /**
     * Commandes qui agissent sur le téléphone lui-même (accessibilité), la langue d'écoute et l'arrêt de l'écoute.
     * @return la réponse, ou null si la phrase n'est pas une commande système.
     */
    private String systemCommand(String command, String raw) {
        String plain = Normalizer.normalize(command, Normalizer.Form.NFD).replaceAll("\\p{M}", "")
                .replace('’', '\'').trim();

        if (containsAny(plain, "arrete l'ecoute", "arrete d'ecouter", "desactive l'ecoute", "eteins l'ecoute", "stop l'ecoute")) {
            if (HeliosListenService.isRunning()) {
                context.startService(new Intent(context, HeliosListenService.class)
                        .setAction(HeliosListenService.ACTION_STOP));
            }
            return "D'accord, j'arrête l'écoute mains libres.";
        }
        if (containsAny(plain, "langue swahili", "parle swahili", "ecoute en swahili", "kiswahili")) {
            memory.savePreference("voice_lang", "sw-KE");
            return "D'accord, j'écoute maintenant en swahili.";
        }
        if (containsAny(plain, "langue francais", "parle francais", "ecoute en francais")) {
            memory.savePreference("voice_lang", "fr-FR");
            return "D'accord, j'écoute maintenant en français.";
        }

        boolean back = plain.equals("retour") || plain.equals("retour arriere")
                || containsAny(plain, "reviens en arriere", "va en arriere", "bouton retour");
        boolean home = plain.equals("accueil")
                || containsAny(plain, "ecran d'accueil", "va a l'accueil", "retour a l'accueil", "bouton accueil");
        boolean recents = containsAny(plain, "applications recentes", "apps recentes", "applis recentes", "multitache");
        boolean notifications = containsAny(plain, "ouvre les notifications", "affiche les notifications",
                "montre les notifications", "baisse le volet", "volet de notifications");
        boolean quick = containsAny(plain, "parametres rapides", "reglages rapides");
        boolean lock = containsAny(plain, "verrouille l'ecran", "verrouille le telephone", "bloque l'ecran", "verrouille ecran");
        boolean shot = containsAny(plain, "capture d'ecran", "capture ecran", "prends une capture", "screenshot");
        boolean readScreen = containsAny(plain, "lis l'ecran", "lis ecran", "que vois-tu", "que vois tu",
                "qu'y a-t-il a l'ecran", "qu'est-ce qui est affiche");
        boolean whichApp = containsAny(plain, "quelle application est ouverte", "quelle app est ouverte", "quelle appli est ouverte");
        boolean scroll = plain.contains("defile") || plain.startsWith("descends") || plain.startsWith("remonte")
                || plain.equals("scroll");

        Matcher click = Pattern.compile("(?i)^(clique sur|clique|appuie sur|touche|tape sur|presse)\\s+(?:le bouton |la touche |l'ic[oô]ne |l'icone )?(.+)$").matcher(raw);
        Matcher type = Pattern.compile("(?i)^(écris|ecris|tape|saisis|dicte)\\s+(.+)$").matcher(raw);
        boolean isClick = click.find();
        boolean isType = !isClick && type.find();

        boolean any = back || home || recents || notifications || quick || lock || shot || readScreen
                || whichApp || scroll || isClick || isType;
        if (!any) return null;

        HeliosAccessibilityService service = HeliosAccessibilityService.get();
        if (service == null) return NEED_ACCESSIBILITY;

        if (back) return service.back() ? "Retour." : "Android a refusé l'action retour.";
        if (home) return service.home() ? "Écran d'accueil." : "Android a refusé l'action accueil.";
        if (recents) return service.recents() ? "Applications récentes." : "Android a refusé cette action.";
        if (notifications) return service.notifications() ? "Voici vos notifications." : "Android a refusé cette action.";
        if (quick) return service.quickSettings() ? "Paramètres rapides ouverts." : "Android a refusé cette action.";
        if (lock) return service.lockScreen() ? "Écran verrouillé." : "Le verrouillage nécessite Android 9 ou plus.";
        if (shot) return service.screenshot() ? "Capture d'écran prise." : "La capture nécessite Android 9 ou plus.";
        if (readScreen) return service.readScreen();
        if (whichApp) {
            String label = service.currentAppLabel();
            return label.isEmpty() ? "Je ne sais pas encore quelle application est ouverte." : "L'application ouverte est " + label + ".";
        }
        if (scroll) {
            boolean up = plain.contains("haut") || plain.startsWith("remonte");
            return service.scroll(!up) ? (up ? "Je remonte." : "Je descends.") : "Je n'ai rien trouvé à faire défiler.";
        }
        if (isClick) {
            String target = click.group(2).trim();
            return service.clickText(target) ? "J'ai touché « " + target + " »."
                    : "Je ne trouve pas « " + target + " » à l'écran.";
        }
        return service.typeText(type.group(2).trim());
    }

    private boolean openAppByLabel(String wanted) {
        PackageManager manager = context.getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = manager.queryIntentActivities(launcher, 0);
        for (ResolveInfo app : apps) {
            CharSequence label = app.loadLabel(manager);
            if (label != null && label.toString().toLowerCase(Locale.ROOT).contains(wanted.toLowerCase(Locale.ROOT))) {
                Intent start = manager.getLaunchIntentForPackage(app.activityInfo.packageName);
                if (start != null) {
                    try { start.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(start); return true; }
                    catch (ActivityNotFoundException | SecurityException ignored) { return false; }
                }
            }
        }
        return false;
    }

    private boolean launchPackage(String packageName) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent == null) return false;
        try { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent); return true; }
        catch (ActivityNotFoundException | SecurityException exception) { return false; }
    }

    /** Essaie de lancer l'intent ; false si aucune application ne peut le traiter. */
    private boolean tryStart(Intent intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return true;
        } catch (ActivityNotFoundException | SecurityException exception) {
            return false;
        }
    }

    /**
     * Lance directement l'action. On ne teste plus resolveActivity() avant : depuis Android 11 ce test renvoie
     * « introuvable » pour presque toutes les applications non déclarées dans le manifeste, ce qui bloquait
     * toutes les commandes sauf WhatsApp.
     */
    private String launch(Intent intent, String success) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return success;
        } catch (ActivityNotFoundException exception) {
            return "Aucune application compatible n'est installée pour cette action.";
        } catch (SecurityException exception) {
            return "Android a bloqué cette action.";
        }
    }

    private boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }

    private boolean startsWithAny(String text, String... values) {
        for (String value : values) if (text.startsWith(value)) return true;
        return false;
    }

    private String tail(List<String> values, int max) {
        StringBuilder builder = new StringBuilder();
        int start = Math.max(0, values.size() - max);
        for (int i = start; i < values.size(); i++) builder.append("• ").append(values.get(i)).append("\n");
        return builder.toString().trim();
    }
}
