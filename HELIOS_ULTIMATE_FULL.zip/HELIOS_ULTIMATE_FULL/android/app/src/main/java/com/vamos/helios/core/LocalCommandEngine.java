package com.vamos.helios.core;

import android.app.Activity;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;

import com.vamos.helios.data.LocalMemoryStore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Small offline command router. New command families should be added as separate modules. */
public final class LocalCommandEngine {
    private final Activity activity;
    private final LocalMemoryStore memory;

    public LocalCommandEngine(Activity activity, LocalMemoryStore memory) {
        this.activity = activity;
        this.memory = memory;
    }

    public String execute(String rawCommand) {
        String raw = rawCommand == null ? "" : rawCommand.trim();
        String command = raw.toLowerCase(Locale.ROOT);
        if (command.isEmpty()) return "Je n'ai pas entendu de commande.";
        memory.rememberLastCommand(raw);

        if (containsAny(command, "bonjour helios", "salut helios", "bonjour", "salut")) {
            return "Bonjour. HELIOS est prêt. Que puis-je faire pour vous ?";
        }
        if (containsAny(command, "quelle heure", "donne l'heure", "il est quelle heure")) {
            return "Il est " + new SimpleDateFormat("HH:mm", Locale.FRANCE).format(new Date()) + ".";
        }
        if (containsAny(command, "quelle date", "on est quel jour", "date d'aujourd'hui")) {
            return "Nous sommes le " + new SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(new Date()) + ".";
        }
        if (startsWithAny(command, "note ", "ajoute une note ", "enregistre une note ")) {
            String note = raw.replaceFirst("(?i)^(note|ajoute une note|enregistre une note)\\s*", "").trim();
            if (note.isEmpty()) return "Dites : note suivie du texte à conserver.";
            memory.addNote(note);
            return "Note enregistrée sur cet appareil.";
        }
        if (containsAny(command, "mes notes", "affiche les notes", "liste les notes")) {
            List<String> notes = memory.getNotes();
            if (notes.isEmpty()) return "Vous n'avez pas encore de note.";
            return "Vos dernières notes :\n" + tail(notes, 8);
        }
        if (startsWithAny(command, "rappelle-moi ", "rappelle moi ")) {
            String reminder = raw.replaceFirst("(?i)^rappelle[- ]moi\\s*", "").trim();
            if (reminder.isEmpty()) return "Dites : rappelle-moi suivi du rappel à conserver.";
            memory.addTask("Rappel : " + reminder);
            return "Rappel ajouté à votre liste locale. Il ne déclenche pas encore de notification programmée.";
        }
        if (startsWithAny(command, "tache ", "tâche ", "ajoute une tâche ", "ajoute une tache ")) {
            String task = raw.replaceFirst("(?i)^(tache|tâche|ajoute une tâche|ajoute une tache)\\s*", "").trim();
            if (task.isEmpty()) return "Dites : tâche suivie du travail à faire.";
            memory.addTask(task);
            return "Tâche enregistrée dans votre liste locale.";
        }
        if (containsAny(command, "mes tâches", "mes taches", "affiche les tâches", "affiche les taches")) {
            List<String> tasks = memory.getTasks();
            if (tasks.isEmpty()) return "Votre liste de tâches est vide.";
            return "Vos tâches :\n" + tail(tasks, 8);
        }
        if (containsAny(command, "batterie", "niveau de batterie", "charge restante")) {
            Intent battery = activity.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery == null) return "Je ne peux pas lire l'état de la batterie pour le moment.";
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int percent = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
            int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL ? "Le téléphone est en charge." : "Le téléphone n'est pas en charge.";
            return percent >= 0 ? "Batterie : " + percent + " %. " + charging : charging;
        }
        if (containsAny(command, "ouvre wifi", "ouvre wi-fi", "paramètres wifi", "parametres wifi")) {
            return launch(new Intent(Settings.ACTION_WIFI_SETTINGS), "J'ouvre les paramètres Wi-Fi.");
        }
        if (containsAny(command, "ouvre bluetooth", "paramètres bluetooth", "parametres bluetooth")) {
            return launch(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "J'ouvre les paramètres Bluetooth.");
        }
        if (startsWithAny(command, "minuteur ", "chrono ", "chronomètre ", "chronometre ")) {
            String amount = raw.replaceFirst("(?i)^(minuteur|chrono|chronomètre|chronometre)\\s*", "").trim().toLowerCase(Locale.ROOT);
            java.util.regex.Matcher timer = java.util.regex.Pattern.compile("(\\d+)\\s*(h|heure|heures|min|minute|minutes|s|sec|seconde|secondes)?").matcher(amount);
            if (!timer.find()) return "Dites par exemple : minuteur 5 minutes, minuteur 30 secondes ou minuteur 1 heure.";
            int value = Integer.parseInt(timer.group(1));
            String unit = timer.group(2) == null ? "minutes" : timer.group(2);
            int seconds = value * (unit.startsWith("h") ? 3600 : (unit.startsWith("s") ? 1 : 60));
            if (seconds < 1 || seconds > 86400) return "Le minuteur doit être compris entre 1 seconde et 24 heures.";
            Intent setTimer = new Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "HELIOS")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            return launch(setTimer, "Je prépare le minuteur. Vérifiez-le puis confirmez dans l'application Horloge.");
        }
        if (startsWithAny(command, "événement ", "evenement ", "ajoute événement ", "ajoute evenement ")) {
            String title = raw.replaceFirst("(?i)^(ajoute )?(événement|evenement)\\s*", "").trim();
            if (title.isEmpty()) return "Dites : événement suivi du titre à ajouter au calendrier.";
            Intent event = new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title);
            return launch(event, "Je prépare l'événement dans votre calendrier. Vérifiez la date et enregistrez-le.");
        }
        if (containsAny(command, "paramètres", "parametres", "réglages android", "reglages android")) {
            return launch(new Intent(Settings.ACTION_SETTINGS), "J'ouvre les paramètres Android.");
        }
        if (containsAny(command, "appareil photo", "ouvre la caméra", "ouvre la camera", "prends une photo")) {
            return launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE), "J'ouvre l'appareil photo.");
        }
        if (containsAny(command, "alarme", "réveil", "reveil", "ouvre l'horloge")) {
            Intent intent = new Intent(AlarmClock.ACTION_SHOW_ALARMS);
            if (!canHandle(intent)) intent = new Intent(AlarmClock.ACTION_SET_ALARM);
            return launch(intent, "J'ouvre les alarmes. Vérifiez l'heure avant de confirmer.");
        }
        if (containsAny(command, "ouvre le calendrier", "ouvre l'agenda", "mon calendrier")) {
            return launch(new Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI), "J'ouvre le calendrier.");
        }
        if (startsWithAny(command, "recherche ", "cherche sur internet ", "cherche ")) {
            String query = raw.replaceFirst("(?i)^(recherche|cherche sur internet|cherche)\\s*", "").trim();
            if (query.isEmpty()) return "Que dois-je rechercher ?";
            Intent search = new Intent(Intent.ACTION_WEB_SEARCH);
            search.putExtra("query", query);
            if (!canHandle(search)) search = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)));
            return launch(search, "Je lance la recherche sur Internet.");
        }
        if (startsWithAny(command, "appelle ", "compose le ", "compose ")) {
            String number = raw.replaceFirst("(?i)^(appelle|compose le|compose)\\s*", "").trim();
            String dialable = number.replaceAll("[^0-9+*#]", "");
            return launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + dialable)),
                    "J'ouvre le composeur. Vous gardez la confirmation de l'appel.");
        }
        if (startsWithAny(command, "sms ", "message à ", "message a ")) {
            String target = raw.replaceFirst("(?i)^(sms|message à|message a)\\s*", "").trim();
            return launch(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(target))),
                    "J'ouvre votre application SMS pour préparer le message.");
        }
        if (startsWithAny(command, "whatsapp message ", "message whatsapp ")) {
            String text = raw.replaceFirst("(?i)^(whatsapp message|message whatsapp)\\s*", "").trim();
            if (text.isEmpty()) return "Dites : WhatsApp message suivi du texte à partager.";
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, text);
            try {
                activity.startActivity(Intent.createChooser(share, "Choisir une application pour envoyer le message"));
                return "Texte préparé. Choisissez WhatsApp et vérifiez le destinataire avant l'envoi.";
            } catch (ActivityNotFoundException exception) {
                return "Aucune application compatible avec le partage n'est disponible.";
            }
        }
        if (startsWithAny(command, "email ", "e-mail ", "courriel ")) {
            String address = raw.replaceFirst("(?i)^(email|e-mail|courriel)\\s*", "").trim();
            return launch(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(address))),
                    "J'ouvre l'application e-mail pour préparer votre message.");
        }
        if (startsWithAny(command, "carte ", "itinéraire ", "itineraire ", "localise ")) {
            String place = raw.replaceFirst("(?i)^(carte|itinéraire|itineraire|localise)\\s*", "").trim();
            return launch(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))),
                    "J'ouvre une application de cartes pour ce lieu.");
        }
        if (containsAny(command, "ouvre whatsapp", "lance whatsapp")) {
            if (launchPackage("com.whatsapp")) return "WhatsApp est ouvert.";
            if (launchPackage("com.whatsapp.w4b")) return "WhatsApp Business est ouvert.";
            return "WhatsApp n'est pas installé ou n'est pas visible par Android.";
        }
        if (containsAny(command, "ouvre musique", "lance musique", "ouvre lecteur audio")) {
            Intent music = new Intent(Intent.ACTION_MAIN);
            music.addCategory(Intent.CATEGORY_APP_MUSIC);
            return launch(music, "J'ouvre votre lecteur de musique.");
        }
        if (containsAny(command, "ouvre youtube", "lance youtube")) {
            if (launchPackage("com.google.android.youtube")) return "YouTube est ouvert.";
            return launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.youtube.com")), "J'ouvre YouTube dans le navigateur.");
        }
        if (startsWithAny(command, "ouvre ", "lance ")) {
            String wanted = raw.replaceFirst("(?i)^(ouvre|lance)\\s*", "").trim();
            if (openAppByLabel(wanted)) return "J'ouvre " + wanted + ".";
            return "Je ne trouve pas l'application « " + wanted + " ». Essayez son nom exact.";
        }
        if (containsAny(command, "urgence", "aide urgente", "mode urgence")) {
            return launch(new Intent(Intent.ACTION_DIAL),
                    "Mode urgence : le composeur s'ouvre. Composez le numéro d'urgence officiel de votre région et appelez uniquement en cas de besoin réel.");
        }
        if (containsAny(command, "aide", "que peux-tu faire", "commandes disponibles")) {
            return "Commandes locales : heure, date, niveau de batterie, notes, tâches, rappels, minuteur 5 minutes, événement [titre], ouvre Wi-Fi, ouvre Bluetooth, ouvre une application, appareil photo, paramètres, WhatsApp, SMS, appel (confirmation manuelle), e-mail, carte, musique, recherche Internet et mode urgence.";
        }
        return "Je n'ai pas de réponse locale fiable à cette demande. Le mode conversation IA nécessite de configurer le serveur HELIOS. Je peux déjà gérer les notes, les tâches et les commandes Android disponibles.";
    }

    private boolean openAppByLabel(String wanted) {
        PackageManager manager = activity.getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = manager.queryIntentActivities(launcher, 0);
        for (ResolveInfo app : apps) {
            CharSequence label = app.loadLabel(manager);
            if (label != null && label.toString().toLowerCase(Locale.ROOT).contains(wanted.toLowerCase(Locale.ROOT))) {
                Intent start = manager.getLaunchIntentForPackage(app.activityInfo.packageName);
                if (start != null) {
                    try { activity.startActivity(start); return true; }
                    catch (ActivityNotFoundException ignored) { return false; }
                }
            }
        }
        return false;
    }

    private boolean launchPackage(String packageName) {
        Intent intent = activity.getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent == null) return false;
        try { activity.startActivity(intent); return true; }
        catch (ActivityNotFoundException exception) { return false; }
    }

    private String launch(Intent intent, String success) {
        try {
            if (!canHandle(intent)) return "Cette action n'est pas prise en charge par une application installée.";
            activity.startActivity(intent);
            return success;
        } catch (ActivityNotFoundException | SecurityException exception) {
            return "Android a bloqué cette action ou aucune application compatible n'est installée.";
        }
    }

    private boolean canHandle(Intent intent) {
        return intent.resolveActivity(activity.getPackageManager()) != null;
    }

    private boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }

    private boolean startsWithAny(String text, String... values) {
        for (String value : values) if (text.startsWith(value)) return true;
        return false;
    }

    private String tail(List<String> values, int max) {
        StringBuilder builder = new StringBuilder();
        int start = Math.max(0, values.size() - max);
        for (int i = start; i < values.size(); i++) builder.append("• ").append(values.get(i)).append("\n");
        return builder.toString().trim();
    }
}
