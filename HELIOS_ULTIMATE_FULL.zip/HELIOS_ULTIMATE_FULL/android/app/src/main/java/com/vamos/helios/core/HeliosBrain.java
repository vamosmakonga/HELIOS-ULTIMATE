package com.vamos.helios.core;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.services.RemoteAssistantClient;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Point d'entrée unique d'une phrase :
 * 1. une réponse « oui / non » à une demande de confirmation en attente ;
 * 2. une suite d'actions (« ouvre YouTube puis cherche musique ») exécutée étape par étape ;
 * 3. une commande locale ; 4. le serveur IA si configuré.
 * À appeler depuis le thread principal.
 */
public final class HeliosBrain {
    /** display = texte affiché ; speech = texte à dire (null = dire le texte affiché). */
    public interface Reply { void onReply(String display, String speech); }

    private static final Pattern STRONG_SPLIT = Pattern.compile("\\s+(?:puis|ensuite|et ensuite|et puis|apres ca|après ça|après|apres)\\s+", Pattern.CASE_INSENSITIVE);
    private static final Pattern SOFT_SPLIT = Pattern.compile("\\s+et\\s+", Pattern.CASE_INSENSITIVE);
    private static final Pattern WAIT = Pattern.compile("^attends?\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE);
    private static final String VERBS =
            "ouvre|ouvrir|lance|lancer|demarre|clique|appuie|touche|tape|ecris|saisis|defile|descends|remonte|retour|accueil|attends|attend|"
            + "cherche|recherche|lis|capture|appelle|envoie|joue|monte|baisse|allume|eteins|ferme|va|active|desactive|dis|affiche|montre|"
            + "coupe|verrouille|compose|fais|pause|reprends|suivant|precedent|prends|emmene|navigue|regle|mets|met|calcule|diagnostic";

    private final LocalMemoryStore memory;
    private final LocalCommandEngine engine;
    private final Handler handler = new Handler(Looper.getMainLooper());

    public HeliosBrain(Context context, LocalMemoryStore memory) {
        this.memory = memory;
        this.engine = new LocalCommandEngine(context, memory);
    }

    public void handle(String rawCommand, Reply reply) {
        String command = rawCommand == null ? "" : rawCommand.trim();
        String stripped = command.replaceFirst("(?i)^(bonjour|salut|ok|d’accord|d'accord)?\\s*helios[,:;.!?]?\\s*", "").trim();
        if (!stripped.isEmpty()) command = stripped;

        String confirmation = PendingAction.answer(command);
        if (confirmation != null) {
            reply.onReply(confirmation, null);
            return;
        }

        List<String> steps = splitSteps(command);
        if (steps.size() > 1) {
            runSteps(steps, 0, new StringBuilder(), reply);
        } else {
            handleOne(command, reply);
        }
    }

    // ---- Une commande ---------------------------------------------------------------------------------

    private void handleOne(final String command, final Reply reply) {
        String answer = engine.execute(command);
        String speech = engine.consumeSpeech();
        if (answer.startsWith(LocalCommandEngine.NO_LOCAL_ANSWER)) {
            String endpoint = memory.getPreference("server_url", "").trim();
            String token = memory.getPreference("server_token", "").trim();
            if (!endpoint.isEmpty()) {
                org.json.JSONArray history = memory.getConversationHistory();
                memory.addConversationTurn("user", command);
                RemoteAssistantClient.ask(endpoint, token, command, history, new RemoteAssistantClient.Callback() {
                    @Override public void onSuccess(String text) {
                        memory.addConversationTurn("assistant", text);
                        reply.onReply(text, null);
                    }
                    @Override public void onError(String message) {
                        reply.onReply(message + " Je reste disponible en mode local.", null);
                    }
                });
                return;
            }
        }
        reply.onReply(answer, speech);
    }

    // ---- Plusieurs actions à la suite ----------------------------------------------------------------

    private List<String> splitSteps(String command) {
        List<String> result = new ArrayList<>();
        for (String part : STRONG_SPLIT.split(command)) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) result.add(trimmed);
        }
        // « et » ne coupe que si chaque morceau commence par un verbe d'action.
        List<String> refined = new ArrayList<>();
        for (String part : result) {
            String[] pieces = SOFT_SPLIT.split(part);
            boolean allActions = pieces.length > 1;
            for (String piece : pieces) {
                if (!startsWithVerb(piece)) { allActions = false; break; }
            }
            if (allActions) {
                for (String piece : pieces) refined.add(piece.trim());
            } else {
                refined.add(part);
            }
        }
        if (refined.size() < 2) return singleton(command);
        for (String part : refined) {
            if (!startsWithVerb(part)) return singleton(command);
        }
        return refined;
    }

    private List<String> singleton(String command) {
        List<String> single = new ArrayList<>();
        single.add(command);
        return single;
    }

    private boolean startsWithVerb(String text) {
        String plain = AdvancedCommands.plainOf(text).trim();
        if (plain.matches("^(?:note|tache|rappelle).*")) return false;
        return plain.matches("^(?:" + VERBS + ")\\b.*");
    }

    private void runSteps(final List<String> steps, final int index, final StringBuilder summary, final Reply reply) {
        if (index >= steps.size()) {
            reply.onReply(summary.toString().trim(), "Terminé. J'ai exécuté " + steps.size() + " actions.");
            return;
        }
        final String step = steps.get(index);
        handleOne(step, (display, speech) -> handler.post(() -> {
            summary.append("▸ ").append(display).append('\n');
            if (PendingAction.isPending()) {
                // une confirmation est demandée : on s'arrête ici et on pose la question
                reply.onReply(summary.toString().trim(), speech != null ? speech : display);
                return;
            }
            handler.postDelayed(() -> runSteps(steps, index + 1, summary, reply), delayAfter(step));
        }));
    }

    private long delayAfter(String step) {
        Matcher wait = WAIT.matcher(AdvancedCommands.plainOf(step).trim());
        if (wait.find()) return Math.min(120, Integer.parseInt(wait.group(1))) * 1000L;
        String plain = AdvancedCommands.plainOf(step).trim();
        if (plain.matches("^(?:ouvre|ouvrir|lance|lancer|demarre|va|appelle|envoie|emmene|navigue|cherche|recherche).*")) return 3800L;
        return 1500L;
    }
}
