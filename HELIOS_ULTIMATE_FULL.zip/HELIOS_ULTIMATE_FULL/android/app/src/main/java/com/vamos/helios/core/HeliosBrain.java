package com.vamos.helios.core;

import android.content.Context;

import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.services.RemoteAssistantClient;

/** Point d'entrée unique d'une phrase : commande locale d'abord, serveur IA ensuite si configuré. */
public final class HeliosBrain {
    public interface Reply { void onReply(String text); }

    private final LocalMemoryStore memory;
    private final LocalCommandEngine engine;

    public HeliosBrain(Context context, LocalMemoryStore memory) {
        this.memory = memory;
        this.engine = new LocalCommandEngine(context, memory);
    }

    /** La réponse peut arriver sur un autre thread quand le serveur IA est consulté. */
    public void handle(String rawCommand, Reply reply) {
        String command = rawCommand == null ? "" : rawCommand.trim();
        String stripped = command.replaceFirst("(?i)^(bonjour|salut|ok|d’accord|d'accord)?\\s*helios[,:;.!?]?\\s*", "").trim();
        if (!stripped.isEmpty()) command = stripped;
        final String finalCommand = command;

        String answer = engine.execute(finalCommand);
        if (answer.startsWith(LocalCommandEngine.NO_LOCAL_ANSWER)) {
            String endpoint = memory.getPreference("server_url", "").trim();
            String token = memory.getPreference("server_token", "").trim();
            if (!endpoint.isEmpty()) {
                org.json.JSONArray history = memory.getConversationHistory();
                memory.addConversationTurn("user", finalCommand);
                RemoteAssistantClient.ask(endpoint, token, finalCommand, history, new RemoteAssistantClient.Callback() {
                    @Override public void onSuccess(String text) {
                        memory.addConversationTurn("assistant", text);
                        reply.onReply(text);
                    }
                    @Override public void onError(String message) {
                        reply.onReply(message + " Je reste disponible en mode local.");
                    }
                });
                return;
            }
        }
        reply.onReply(answer);
    }
}
