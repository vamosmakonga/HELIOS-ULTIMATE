package com.vamos.helios.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Explicit registry keeps feature modules isolated and discoverable. */
public final class ModuleRegistry {
    private final List<HeliosModule> modules = new ArrayList<>();

    public ModuleRegistry() {
        add("core", "Noyau local", "Commandes simples, notes et tâches", ModuleStatus.READY);
        add("voice", "Assistant vocal", "Reconnaissance à la demande et synthèse vocale", ModuleStatus.NEEDS_PERMISSION);
        add("android", "Contrôle Android", "Ouverture d'apps et intents système autorisés", ModuleStatus.READY);
        add("memory", "Mémoire", "Préférences et mémoire locale sur l'appareil", ModuleStatus.READY);
        add("vision", "Vision artificielle", "Caméra, OCR et analyse d'images", ModuleStatus.PLANNED);
        add("security", "Sécurité", "Biométrie, contrôle des accès et alertes", ModuleStatus.NEEDS_CONFIGURATION);
        add("home", "Maison connectée", "Connecteur Home Assistant / appareils compatibles", ModuleStatus.NEEDS_CONFIGURATION);
        add("internet", "Internet", "Recherche et services en ligne", ModuleStatus.NEEDS_CONFIGURATION);
        add("communication", "Communication", "Préparation WhatsApp, SMS et emails", ModuleStatus.READY);
        add("productivity", "Productivité", "Notes, tâches, calendrier et alarmes", ModuleStatus.READY);
        add("developer", "Informatique", "Assistant de programmation et outils de code", ModuleStatus.NEEDS_CONFIGURATION);
        add("media", "Multimédia", "Ouverture des applications audio et vidéo", ModuleStatus.READY);
        add("automation", "Automatisation", "Scénarios multi-actions", ModuleStatus.PLANNED);
        add("translate", "Traduction", "Traduction en ligne ou moteur local", ModuleStatus.NEEDS_CONFIGURATION);
        add("finance", "Assistant financier", "Budgets et calculs locaux, sans connexion bancaire", ModuleStatus.PLANNED);
        add("sync", "Synchronisation", "Sauvegarde entre appareils via serveur", ModuleStatus.NEEDS_CONFIGURATION);
        add("plugins", "Extensions", "Contrats de modules et registre", ModuleStatus.READY);
    }

    private void add(String id, String name, String description, ModuleStatus status) {
        modules.add(new BasicModule(id, name, description, status));
    }

    public List<HeliosModule> all() {
        return Collections.unmodifiableList(modules);
    }

    private static final class BasicModule implements HeliosModule {
        private final String id, name, description;
        private final ModuleStatus status;
        BasicModule(String id, String name, String description, ModuleStatus status) {
            this.id = id; this.name = name; this.description = description; this.status = status;
        }
        public String id() { return id; }
        public String displayName() { return name; }
        public String description() { return description; }
        public ModuleStatus status() { return status; }
    }
}
