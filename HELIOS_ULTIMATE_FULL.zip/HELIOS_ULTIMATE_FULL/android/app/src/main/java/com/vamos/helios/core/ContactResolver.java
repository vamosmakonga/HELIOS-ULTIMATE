package com.vamos.helios.core;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;

/** Retrouve un contact (nom dit à voix haute) ou accepte directement un numéro. */
public final class ContactResolver {
    public static final class Contact {
        public final String name;
        public final String number;
        Contact(String name, String number) { this.name = name; this.number = number; }
    }

    private ContactResolver() { }

    public static boolean hasPermission(Context context) {
        return context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }

    /** « 0812 345 678 » ou « +243 81 234 5678 » → numéro ; sinon null. */
    public static String asNumber(String spoken) {
        if (spoken == null) return null;
        String compact = spoken.replaceAll("[\\s.\\-()]", "");
        if (compact.matches("\\+?[0-9]{5,15}")) return compact;
        return null;
    }

    /**
     * @return le contact, ou null si introuvable / permission absente (voir hasPermission pour distinguer).
     */
    public static Contact find(Context context, String spoken) {
        String number = asNumber(spoken);
        if (number != null) return new Contact(number, number);
        if (!hasPermission(context)) return null;
        String query = AppResolver.normalize(spoken);
        if (query.isEmpty()) return null;

        Contact best = null;
        int bestScore = 0;
        try (Cursor cursor = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null, null)) {
            if (cursor == null) return null;
            while (cursor.moveToNext()) {
                String name = cursor.getString(0);
                String phone = cursor.getString(1);
                if (name == null || phone == null) continue;
                int score = score(AppResolver.normalize(name), query);
                if (score > bestScore) {
                    bestScore = score;
                    best = new Contact(name, phone);
                }
            }
        } catch (Exception exception) {
            return null;
        }
        return bestScore >= 55 ? best : null;
    }

    private static int score(String name, String query) {
        if (name.isEmpty()) return 0;
        if (name.equals(query)) return 100;
        if (name.startsWith(query)) return 90;
        String[] nameTokens = name.split(" ");
        for (String token : nameTokens) if (token.equals(query)) return 85;
        if (name.contains(query)) return 70;
        String[] queryTokens = query.split(" ");
        int matched = 0;
        for (String token : queryTokens) if (name.contains(token)) matched++;
        if (matched == queryTokens.length) return 75;
        // Erreurs de transcription vocale : un caractère de différence.
        if (query.length() >= 4) {
            for (String token : nameTokens) {
                if (token.length() >= 4 && distance(token, query) <= 1) return 60;
            }
            if (distance(name, query) <= 2) return 58;
        }
        return 0;
    }

    private static int distance(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous; previous = current; current = swap;
        }
        return previous[b.length()];
    }

    /** Numéro au format international pour wa.me (ex. 0812345678 → 243812345678). */
    public static String toInternational(String number, String countryCode) {
        String digits = number.replaceAll("[^0-9+]", "");
        if (digits.startsWith("+")) return digits.substring(1);
        if (digits.startsWith("00")) return digits.substring(2);
        if (digits.startsWith("0")) return countryCode + digits.substring(1);
        if (digits.length() <= 9) return countryCode + digits;
        return digits;
    }
}
