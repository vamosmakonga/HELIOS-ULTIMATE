package com.vamos.helios.services;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Optional secure-server bridge. Secrets for the AI provider stay on the server, never in the APK. */
public final class RemoteAssistantClient {
    public interface Callback {
        void onSuccess(String answer);
        void onError(String message);
    }

    private RemoteAssistantClient() { }

    public static void sync(String endpoint, String accessToken, org.json.JSONObject data, Callback callback) {
        String syncEndpoint = endpoint.replaceFirst("assistant\\.php(?:\\?.*)?$", "sync.php");
        Thread thread = new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(syncEndpoint);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(25000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Accept", "application/json");
                if (accessToken != null && !accessToken.trim().isEmpty()) {
                    connection.setRequestProperty("Authorization", "Bearer " + accessToken.trim());
                }
                org.json.JSONObject body = new org.json.JSONObject();
                body.put("data", data);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder response = new StringBuilder();
                if (stream != null) {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) response.append(line);
                    }
                }
                org.json.JSONObject json = new org.json.JSONObject(response.toString());
                if (status >= 200 && status < 300) {
                    callback.onSuccess(json.optJSONObject("data") == null ? "Synchronisation terminée." : json.getJSONObject("data").toString());
                } else {
                    callback.onError(json.optString("error", "Serveur HELIOS : HTTP " + status));
                }
            } catch (Exception exception) {
                callback.onError("Synchronisation impossible : " + exception.getMessage());
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "helios-sync");
        thread.start();
    }

    public static void ask(String endpoint, String accessToken, String message, org.json.JSONArray history, Callback callback) {
        Thread thread = new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(endpoint);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(25000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Accept", "application/json");
                if (accessToken != null && !accessToken.trim().isEmpty()) {
                    connection.setRequestProperty("Authorization", "Bearer " + accessToken.trim());
                }
                JSONObject body = new JSONObject();
                body.put("message", message);
                body.put("history", history == null ? new org.json.JSONArray() : history);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300
                        ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder response = new StringBuilder();
                if (stream != null) {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) response.append(line);
                    }
                }
                JSONObject json = new JSONObject(response.toString());
                if (status >= 200 && status < 300) {
                    String reply = json.optString("reply", "").trim();
                    if (reply.isEmpty()) throw new IllegalStateException("Réponse du serveur vide.");
                    callback.onSuccess(reply);
                } else {
                    callback.onError(json.optString("error", "Serveur HELIOS : HTTP " + status));
                }
            } catch (Exception exception) {
                callback.onError("Connexion impossible : " + exception.getMessage());
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "helios-remote-assistant");
        thread.start();
    }
}
