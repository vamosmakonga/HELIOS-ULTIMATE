package com.vamos.helios.core;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Trouve n'importe quelle application installée à partir de ce que dit l'utilisateur. */
public final class AppResolver {
    public static final class Match {
        public final String packageName;
        public final String label;
        Match(String packageName, String label) { this.packageName = packageName; this.label = label; }
    }

    /** Noms parlés → mots possibles dans le nom de l'application (selon la marque du téléphone). */
    private static final Map<String, String[]> ALIASES = new HashMap<>();
    static {
        ALIASES.put("telephone", new String[]{"telephone", "phone", "appels", "dialer", "composeur"});
        ALIASES.put("appels", new String[]{"telephone", "phone", "appels"});
        ALIASES.put("messages", new String[]{"messages", "sms", "messagerie"});
        ALIASES.put("sms", new String[]{"messages", "sms", "messagerie"});
        ALIASES.put("galerie", new String[]{"galerie", "photos", "gallery", "album"});
        ALIASES.put("photos", new String[]{"photos", "galerie", "gallery"});
        ALIASES.put("camera", new String[]{"appareil photo", "camera", "cam"});
        ALIASES.put("appareil photo", new String[]{"appareil photo", "camera"});
        ALIASES.put("parametres", new String[]{"parametres", "reglages", "settings"});
        ALIASES.put("reglages", new String[]{"parametres", "reglages", "settings"});
        ALIASES.put("calculatrice", new String[]{"calculatrice", "calculator", "calcul"});
        ALIASES.put("horloge", new String[]{"horloge", "clock", "montre", "reveil"});
        ALIASES.put("contacts", new String[]{"contacts", "repertoire", "carnet"});
        ALIASES.put("navigateur", new String[]{"chrome", "navigateur", "browser", "internet", "firefox", "opera"});
        ALIASES.put("internet", new String[]{"chrome", "navigateur", "browser", "internet"});
        ALIASES.put("play store", new String[]{"play store", "google play", "play"});
        ALIASES.put("playstore", new String[]{"play store", "google play"});
        ALIASES.put("fichiers", new String[]{"fichiers", "files", "gestionnaire", "file manager", "mes fichiers"});
        ALIASES.put("musique", new String[]{"musique", "music", "lecteur", "spotify", "youtube music", "boomplay"});
        ALIASES.put("carte", new String[]{"maps", "cartes", "carte"});
        ALIASES.put("maps", new String[]{"maps", "cartes"});
        ALIASES.put("agenda", new String[]{"agenda", "calendrier", "calendar"});
        ALIASES.put("calendrier", new String[]{"calendrier", "agenda", "calendar"});
        ALIASES.put("notes", new String[]{"notes", "bloc notes", "memo", "keep"});
        ALIASES.put("mail", new String[]{"gmail", "mail", "email", "courriel"});
        ALIASES.put("email", new String[]{"gmail", "mail", "email"});
        ALIASES.put("facebook", new String[]{"facebook"});
        ALIASES.put("messenger", new String[]{"messenger"});
        ALIASES.put("tiktok", new String[]{"tiktok", "tik tok"});
        ALIASES.put("instagram", new String[]{"instagram"});
        ALIASES.put("telegram", new String[]{"telegram"});
        ALIASES.put("youtube", new String[]{"youtube"});
    }

    private AppResolver() { }

    public static String normalize(String text) {
        if (text == null) return "";
        String decomposed = Normalizer.normalize(text, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return decomposed.toLowerCase(Locale.ROOT).replace('’', '\'')
                .replaceAll("[^a-z0-9]+", " ").trim();
    }

    /** Retire les petits mots : « l'application », « mon », « le »… */
    public static String stripFiller(String spoken) {
        String q = normalize(spoken);
        q = q.replaceFirst("^(?:l ?)?(?:application|appli|app)\\s+", "");
        q = q.replaceFirst("^(?:l|le|la|les|mon|ma|mes|un|une|de|du|des)\\s+", "");
        q = q.replaceFirst("^(?:application|appli|app)\\s+", "");
        q = q.replaceAll("\\s+(?:application|appli|app)$", "");
        return q.trim();
    }

    /** @return la meilleure application correspondante, ou null. */
    public static Match find(Context context, String spoken) {
        String query = stripFiller(spoken);
        if (query.isEmpty()) return null;
        String[] keywords = ALIASES.containsKey(query) ? ALIASES.get(query) : new String[]{query};

        PackageManager manager = context.getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = manager.queryIntentActivities(launcher, 0);

        Match best = null;
        int bestScore = 0;
        int bestLength = Integer.MAX_VALUE;
        for (ResolveInfo app : apps) {
            String packageName = app.activityInfo.packageName;
            if (packageName.equals(context.getPackageName())) continue;
            CharSequence rawLabel = app.loadLabel(manager);
            if (rawLabel == null) continue;
            String label = normalize(rawLabel.toString());
            if (label.isEmpty()) continue;
            int score = 0;
            for (String keyword : keywords) score = Math.max(score, score(label, packageName, keyword));
            if (score > bestScore || (score == bestScore && score > 0 && label.length() < bestLength)) {
                bestScore = score;
                bestLength = label.length();
                best = new Match(packageName, rawLabel.toString());
            }
        }
        return bestScore >= 40 ? best : null;
    }

    private static int score(String label, String packageName, String query) {
        if (label.equals(query)) return 100;
        if (label.startsWith(query + " ") || label.startsWith(query)) return 85;
        if (label.contains(query)) return 65;
        if (query.length() >= 4 && query.contains(label) && label.length() >= 3) return 50;
        String[] tokens = query.split(" ");
        if (tokens.length > 1) {
            boolean all = true;
            for (String token : tokens) if (!label.contains(token)) { all = false; break; }
            if (all) return 60;
        }
        if (query.length() >= 4 && packageName.toLowerCase(Locale.ROOT).contains(query.replace(" ", ""))) return 45;
        return 0;
    }

    public static boolean launch(Context context, Match match) {
        if (match == null) return false;
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(match.packageName);
        if (intent == null) return false;
        try {
            DeviceActions.start(context, intent);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }
}
