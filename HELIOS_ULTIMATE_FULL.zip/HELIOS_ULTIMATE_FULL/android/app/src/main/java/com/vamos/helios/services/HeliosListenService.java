package com.vamos.helios.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import com.vamos.helios.MainActivity;
import com.vamos.helios.core.HeliosBrain;
import com.vamos.helios.core.SystemAccess;
import com.vamos.helios.core.WakeWord;
import com.vamos.helios.data.LocalMemoryStore;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Écoute mains libres : service au premier plan (notification permanente) qui garde le micro ouvert,
 * attend « Bonjour HELIOS », exécute la commande puis répond à voix haute. Fonctionne téléphone posé,
 * écran éteint, tant qu'Android ne tue pas le service (voir docs/ACTIVATION_FR.md pour la batterie).
 */
public class HeliosListenService extends Service {
    public static final String ACTION_START = "com.vamos.helios.action.START_LISTEN";
    public static final String ACTION_STOP = "com.vamos.helios.action.STOP_LISTEN";
    /** Diffusion interne vers MainActivity : état, texte entendu, réponse. */
    public static final String ACTION_STATUS = "com.vamos.helios.action.STATUS";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_HEARD = "heard";
    public static final String EXTRA_REPLY = "reply";

    private static final String CHANNEL_ID = "helios_listen";
    private static final int NOTIFICATION_ID = 4101;
    private static final long CONVERSATION_WINDOW_MS = 10_000L;
    private static final long WAKE_ONLY_WINDOW_MS = 12_000L;

    private static volatile boolean running = false;
    private static volatile float micLevel = 0f;

    public static boolean isRunning() { return running; }

    /** Niveau sonore du micro (0..1), lu par le réacteur HUD de l'écran principal. */
    public static float getLevel() { return running ? micLevel : 0f; }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private LocalMemoryStore memory;
    private HeliosBrain brain;
    private PowerManager.WakeLock wakeLock;

    private boolean destroyed = false;
    private boolean speaking = false;
    private boolean stopAfterSpeech = false;
    private boolean offlinePreferred = true;
    private long awakeUntil = 0L;
    private int consecutiveErrors = 0;

    private final Runnable restartRunnable = this::startListening;
    private final Runnable speakGuard = () -> { if (speaking) afterSpeaking(); };

    @Override
    public void onCreate() {
        super.onCreate();
        memory = new LocalMemoryStore(this);
        brain = new HeliosBrain(this, memory);
        createChannel();
        initTts();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!SystemAccess.hasAudioPermission(this)) {
            broadcast("error", null, "Autorisation du microphone manquante.");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            try {
                Notification notification = buildNotification("HELIOS écoute — dites « Bonjour HELIOS »");
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
                } else {
                    startForeground(NOTIFICATION_ID, notification);
                }
            } catch (Exception exception) {
                // Android 14+ refuse de démarrer un service micro depuis l'arrière-plan.
                broadcast("error", null, "Android a refusé le service d'écoute : " + exception.getMessage()
                        + ". Ouvrez HELIOS puis appuyez sur le bouton mains libres.");
                stopSelf();
                return START_NOT_STICKY;
            }
            running = true;
            acquireWakeLock();
            broadcast("listening", null, null);
            handler.post(restartRunnable);
        }
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        destroyed = true;
        running = false;
        micLevel = 0f;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        broadcast("stopped", null, null);
        super.onDestroy();
    }

    // ---- Écoute ---------------------------------------------------------------------------------

    private void startListening() {
        if (destroyed || speaking) return;
        if (!SystemAccess.hasAudioPermission(this)) { stopSelf(); return; }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            broadcast("error", null, "Aucun service de reconnaissance vocale sur ce téléphone. Installez ou activez l'application Google.");
            stopSelf();
            return;
        }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(listener);
            }
            String language = memory.getPreference("voice_lang", "fr-FR");
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offlinePreferred);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
            recognizer.startListening(intent);
        } catch (Exception exception) {
            destroyRecognizer();
            scheduleRestart(1500);
        }
    }

    private void scheduleRestart(long delayMs) {
        if (destroyed) return;
        handler.removeCallbacks(restartRunnable);
        handler.postDelayed(restartRunnable, delayMs);
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) {
            micLevel = Math.max(0f, Math.min(1f, (rmsdB + 2f) / 12f));
        }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { micLevel = 0f; }
        @Override public void onPartialResults(Bundle partialResults) { }
        @Override public void onEvent(int eventType, Bundle params) { }

        @Override
        public void onError(int error) {
            if (destroyed || speaking) return;
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    scheduleRestart(250); // silence normal : on relance simplement
                    return;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    broadcast("error", null, "Autorisation du microphone refusée par Android.");
                    stopSelf();
                    return;
                case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED:
                case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE:
                    if (offlinePreferred) { offlinePreferred = false; scheduleRestart(300); return; }
                    broadcast("error", null, "Langue de reconnaissance indisponible (code " + error + ").");
                    scheduleRestart(8000);
                    return;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                    offlinePreferred = true; // pas d'Internet : on retente avec le modèle hors ligne
                    break;
                default:
                    break;
            }
            consecutiveErrors++;
            destroyRecognizer();
            long delay = Math.min(1000L * consecutiveErrors, 10_000L);
            if (consecutiveErrors == 3) {
                broadcast("error", null, "Le moteur vocal rencontre des erreurs (code " + error + "). Nouvelle tentative…");
            }
            scheduleRestart(delay);
        }

        @Override
        public void onResults(Bundle results) {
            consecutiveErrors = 0;
            ArrayList<String> alternatives = results == null ? null
                    : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            handleUtterance(alternatives);
            if (!speaking) scheduleRestart(200);
        }
    };

    // ---- Compréhension ---------------------------------------------------------------------------

    private void handleUtterance(List<String> alternatives) {
        if (alternatives == null || alternatives.isEmpty()) return;
        long now = SystemClock.elapsedRealtime();
        String heard = alternatives.get(0);
        String command = null;
        boolean wakeFound = false;
        for (String alternative : alternatives) {
            String after = WakeWord.commandAfterWake(alternative);
            if (after != null) { wakeFound = true; command = after; heard = alternative; break; }
        }
        if (wakeFound) {
            if (command.isEmpty()) {
                awakeUntil = now + WAKE_ONLY_WINDOW_MS;
                broadcast("awake", heard, "Oui ? Je vous écoute.");
                speak("Oui ? Je vous écoute.");
                return;
            }
        } else if (now < awakeUntil) {
            command = heard; // conversation en cours : pas besoin de redire le mot d'activation
        } else {
            broadcast("listening", heard, null); // bruit ou conversation autour : on ignore
            return;
        }
        execute(heard, command);
    }

    private void execute(String heard, String command) {
        String plain = Normalizer.normalize(command, Normalizer.Form.NFD).replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT).replace('’', '\'');
        if (plain.contains("arrete l'ecoute") || plain.contains("arrete d'ecouter")
                || plain.contains("desactive l'ecoute") || plain.contains("eteins l'ecoute")) {
            stopAfterSpeech = true;
            broadcast("awake", heard, "D'accord, j'arrête l'écoute mains libres.");
            speak("D'accord, j'arrête l'écoute mains libres.");
            return;
        }
        broadcast("thinking", heard, null);
        speaking = true; // bloque la relance pendant le traitement (surtout si le serveur IA répond plus tard)
        stopRecognizerNow();
        handler.postDelayed(speakGuard, 30_000L);
        brain.handle(command, reply -> handler.post(() -> {
            broadcast("awake", heard, reply);
            speakNow(reply);
        }));
    }

    // ---- Voix ------------------------------------------------------------------------------------

    private void speak(String text) {
        speaking = true;
        stopRecognizerNow();
        speakNow(text);
    }

    private void speakNow(String text) {
        handler.removeCallbacks(speakGuard);
        speaking = true;
        if (!ttsReady || tts == null || text == null || text.trim().isEmpty()) {
            afterSpeaking();
            return;
        }
        String spoken = text.length() > 600 ? text.substring(0, 600) : text;
        handler.postDelayed(speakGuard, 20_000L);
        int result = tts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "helios-" + SystemClock.elapsedRealtime());
        if (result != TextToSpeech.SUCCESS) afterSpeaking();
    }

    private void afterSpeaking() {
        handler.removeCallbacks(speakGuard);
        speaking = false;
        if (stopAfterSpeech) { stopSelf(); return; }
        awakeUntil = SystemClock.elapsedRealtime() + CONVERSATION_WINDOW_MS;
        scheduleRestart(400);
    }

    private void stopRecognizerNow() {
        micLevel = 0f;
        handler.removeCallbacks(restartRunnable);
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
        }
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS || tts == null) return;
            int language = tts.setLanguage(Locale.FRANCE);
            ttsReady = language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED;
            tts.setSpeechRate(0.94f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { handler.post(() -> afterSpeaking()); }
                @Override public void onError(String utteranceId) { handler.post(() -> afterSpeaking()); }
            });
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    for (Voice voice : voices) {
                        String name = voice.getName().toLowerCase(Locale.ROOT);
                        boolean french = voice.getLocale() != null && "fr".equals(voice.getLocale().getLanguage());
                        boolean male = name.contains("male") || name.contains("masculin") || name.contains("homme");
                        if (french && male && !name.contains("female")) { tts.setVoice(voice); break; }
                    }
                }
            } catch (Exception ignored) { }
        });
    }

    // ---- Notification, batterie, diffusion ---------------------------------------------------------

    private void createChannel() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Écoute HELIOS", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Indique que HELIOS écoute en mode mains libres.");
        channel.setShowBadge(false);
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification(String text) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, HeliosListenService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Arrêter", stop).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("HELIOS")
                .setContentText(text)
                .setContentIntent(open)
                .addAction(stopAction)
                .setOngoing(true)
                .build();
    }

    private void acquireWakeLock() {
        try {
            PowerManager manager = (PowerManager) getSystemService(POWER_SERVICE);
            if (manager == null) return;
            wakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "helios:listen");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(12L * 60L * 60L * 1000L);
        } catch (Exception ignored) { }
    }

    private void broadcast(String state, String heard, String reply) {
        Intent intent = new Intent(ACTION_STATUS).setPackage(getPackageName());
        intent.putExtra(EXTRA_STATE, state);
        if (heard != null) intent.putExtra(EXTRA_HEARD, heard);
        if (reply != null) intent.putExtra(EXTRA_REPLY, reply);
        sendBroadcast(intent);
    }
}
