package com.vamos.helios.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import com.vamos.helios.MainActivity;
import com.vamos.helios.core.HeliosBrain;
import com.vamos.helios.core.PendingAction;
import com.vamos.helios.core.Speaker;
import com.vamos.helios.core.SystemAccess;
import com.vamos.helios.core.WakeWord;
import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.ui.HudView;
import com.vamos.helios.ui.OverlayBubble;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Écoute mains libres en arrière-plan : service au premier plan qui garde le micro ouvert, attend
 * « Bonjour HELIOS », exécute la commande puis répond à voix haute. Pendant une conversation le micro
 * reste ouvert (pas besoin de répéter le mot d'activation). Une bulle flottante montre l'état de HELIOS.
 */
public class HeliosListenService extends Service {
    public static final String ACTION_START = "com.vamos.helios.action.START_LISTEN";
    public static final String ACTION_STOP = "com.vamos.helios.action.STOP_LISTEN";
    /** Diffusion interne vers MainActivity : état, texte entendu, réponse. */
    public static final String ACTION_STATUS = "com.vamos.helios.action.STATUS";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_HEARD = "heard";
    public static final String EXTRA_REPLY = "reply";

    private static final String CHANNEL_ID = "helios_listen";
    private static final int NOTIFICATION_ID = 4101;
    private static final long CONVERSATION_WINDOW_MS = 30_000L;
    private static final long CONFIRMATION_WINDOW_MS = 45_000L;
    private static final long WAKE_ONLY_WINDOW_MS = 20_000L;

    private static volatile boolean running = false;
    private static volatile float micLevel = 0f;
    private static volatile boolean uiVisible = false;
    private static HeliosListenService instance;

    public static boolean isRunning() { return running; }

    /** Niveau sonore du micro (0..1), lu par le réacteur HUD. */
    public static float getLevel() { return running ? micLevel : 0f; }

    /** Fait parler HELIOS : via le service s'il écoute (le micro se coupe pendant la voix), sinon directement. */
    public static void say(Context context, String text) {
        final HeliosListenService service = instance;
        if (running && service != null) {
            service.handler.post(() -> service.speak(text));
        } else {
            Speaker.get(context).speak(text, null);
        }
    }

    /** Appelé par l'écran principal : la bulle se cache quand HELIOS est déjà affiché. */
    public static void setUiVisible(boolean visible) {
        uiVisible = visible;
        final HeliosListenService service = instance;
        if (service != null) service.handler.post(service::updateBubble);
    }

    public static void applyBubblePreference() {
        final HeliosListenService service = instance;
        if (service != null) service.handler.post(service::updateBubble);
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private LocalMemoryStore memory;
    private HeliosBrain brain;
    private PowerManager.WakeLock wakeLock;
    private OverlayBubble bubble;
    private HudView.State hudState = HudView.State.LISTENING;

    private boolean destroyed = false;
    private boolean speaking = false;
    private boolean stopAfterSpeech = false;
    private boolean offlinePreferred = true;
    private boolean voiceWarned = false;
    private long awakeUntil = 0L;
    private int consecutiveErrors = 0;
    private int speakToken = 0;

    private final Runnable restartRunnable = this::startListening;
    private final Runnable processingGuard = () -> { if (speaking) { speaking = false; scheduleRestart(300); } };

    @Override
    public void onCreate() {
        super.onCreate();
        memory = new LocalMemoryStore(this);
        brain = new HeliosBrain(this, memory);
        createChannel();
        Speaker.get(this); // démarre le moteur vocal dès maintenant
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!SystemAccess.hasAudioPermission(this)) {
            broadcast("error", null, "Autorisation du microphone manquante.");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            try {
                Notification notification = buildNotification("HELIOS écoute — dites « Bonjour HELIOS »");
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
                } else {
                    startForeground(NOTIFICATION_ID, notification);
                }
            } catch (Exception exception) {
                broadcast("error", null, "Android a refusé le service d'écoute : " + exception.getMessage()
                        + ". Ouvrez HELIOS puis appuyez sur le bouton mains libres.");
                stopSelf();
                return START_NOT_STICKY;
            }
            running = true;
            instance = this;
            acquireWakeLock();
            setHud(HudView.State.LISTENING);
            updateBubble();
            broadcast("listening", null, null);
            handler.post(restartRunnable);
        }
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        destroyed = true;
        running = false;
        micLevel = 0f;
        instance = null;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (bubble != null) { bubble.hide(); bubble = null; }
        Speaker.get(this).stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        broadcast("stopped", null, null);
        super.onDestroy();
    }

    // ---- Bulle flottante -------------------------------------------------------------------------------

    private void updateBubble() {
        if (destroyed) return;
        boolean wanted = running && !uiVisible && !"off".equals(memory.getPreference("bubble", "on"));
        if (wanted) {
            if (bubble == null) bubble = new OverlayBubble(this);
            if (bubble.show(HeliosListenService::getLevel)) bubble.setState(hudState);
        } else if (bubble != null) {
            bubble.hide();
        }
    }

    private void setHud(HudView.State state) {
        hudState = state;
        if (bubble != null) bubble.setState(state);
    }

    // ---- Écoute ----------------------------------------------------------------------------------------

    private void startListening() {
        if (destroyed || speaking) return;
        if (!SystemAccess.hasAudioPermission(this)) { stopSelf(); return; }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            broadcast("error", null, "Aucun service de reconnaissance vocale sur ce téléphone. Installez ou activez l'application Google.");
            stopSelf();
            return;
        }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(listener);
            }
            String language = memory.getPreference("voice_lang", "fr-FR");
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offlinePreferred);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L);
            intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L);
            recognizer.startListening(intent);
            if (hudState == HudView.State.IDLE) setHud(HudView.State.LISTENING);
        } catch (Exception exception) {
            destroyRecognizer();
            scheduleRestart(1500);
        }
    }

    private void scheduleRestart(long delayMs) {
        if (destroyed) return;
        handler.removeCallbacks(restartRunnable);
        handler.postDelayed(restartRunnable, delayMs);
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void stopRecognizerNow() {
        micLevel = 0f;
        handler.removeCallbacks(restartRunnable);
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) {
            micLevel = Math.max(0f, Math.min(1f, (rmsdB + 2f) / 12f));
        }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { micLevel = 0f; }
        @Override public void onPartialResults(Bundle partialResults) { }
        @Override public void onEvent(int eventType, Bundle params) { }

        @Override
        public void onError(int error) {
            if (destroyed || speaking) return;
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    scheduleRestart(200); // silence normal : on relance simplement
                    return;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    broadcast("error", null, "Autorisation du microphone refusée par Android.");
                    stopSelf();
                    return;
                case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED:
                case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE:
                    if (offlinePreferred) { offlinePreferred = false; scheduleRestart(300); return; }
                    broadcast("error", null, "Langue de reconnaissance indisponible (code " + error + ").");
                    scheduleRestart(8000);
                    return;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                    offlinePreferred = true; // pas d'Internet : on retente avec le modèle hors ligne
                    break;
                default:
                    break;
            }
            consecutiveErrors++;
            destroyRecognizer();
            long delay = Math.min(1000L * consecutiveErrors, 10_000L);
            if (consecutiveErrors == 3) {
                broadcast("error", null, "Le moteur vocal rencontre des erreurs (code " + error + "). Nouvelle tentative…");
            }
            scheduleRestart(delay);
        }

        @Override
        public void onResults(Bundle results) {
            consecutiveErrors = 0;
            ArrayList<String> alternatives = results == null ? null
                    : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            handleUtterance(alternatives);
            if (!speaking) scheduleRestart(150);
        }
    };

    // ---- Compréhension ---------------------------------------------------------------------------------

    private void handleUtterance(List<String> alternatives) {
        if (alternatives == null || alternatives.isEmpty()) return;
        long now = SystemClock.elapsedRealtime();
        String heard = alternatives.get(0);
        String command = null;
        boolean wakeFound = false;
        for (String alternative : alternatives) {
            String after = WakeWord.commandAfterWake(alternative);
            if (after != null) { wakeFound = true; command = after; heard = alternative; break; }
        }
        if (wakeFound) {
            if (command.isEmpty()) {
                awakeUntil = now + WAKE_ONLY_WINDOW_MS;
                broadcast("awake", heard, "Oui ? Je vous écoute.");
                speak("Oui ? Je vous écoute.");
                return;
            }
        } else if (now < awakeUntil || PendingAction.isPending()) {
            command = heard; // conversation en cours : pas besoin de redire le mot d'activation
        } else {
            broadcast("listening", heard, null); // bruit ou conversation autour : on ignore
            return;
        }
        execute(heard, command);
    }

    private void execute(final String heard, String command) {
        String plain = Normalizer.normalize(command, Normalizer.Form.NFD).replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT).replace('’', '\'');
        if (plain.contains("arrete l'ecoute") || plain.contains("arrete d'ecouter")
                || plain.contains("desactive l'ecoute") || plain.contains("eteins l'ecoute")) {
            stopAfterSpeech = true;
            broadcast("awake", heard, "D'accord, j'arrête l'écoute mains libres.");
            speak("D'accord, j'arrête l'écoute mains libres.");
            return;
        }
        broadcast("thinking", heard, null);
        setHud(HudView.State.THINKING);
        speaking = true; // bloque la relance du micro pendant le traitement
        stopRecognizerNow();
        handler.removeCallbacks(processingGuard);
        handler.postDelayed(processingGuard, 60_000L);
        try {
            brain.handle(command, (display, spoken) -> handler.post(() -> {
                handler.removeCallbacks(processingGuard);
                broadcast("awake", heard, display);
                speak(spoken != null ? spoken : display);
            }));
        } catch (RuntimeException exception) {
            handler.removeCallbacks(processingGuard);
            String message = "Je n'ai pas pu exécuter cette action : " + exception.getMessage();
            broadcast("awake", heard, message);
            speak(message);
        }
    }

    // ---- Voix ------------------------------------------------------------------------------------------

    /** Dit le texte ; le micro est coupé pendant ce temps pour ne pas s'entendre soi-même. */
    private void speak(String text) {
        if (destroyed) return;
        final int token = ++speakToken;
        speaking = true;
        stopRecognizerNow();
        setHud(HudView.State.SPEAKING);
        Speaker speaker = Speaker.get(this);
        if (!voiceWarned && (speaker.isFailed() || (speaker.isReady() && !speaker.hasFrench()) || speaker.isMediaVolumeZero())) {
            voiceWarned = true;
            broadcast("error", null, speaker.status());
        }
        speaker.speak(text, () -> { if (token == speakToken) afterSpeaking(); });
    }

    private void afterSpeaking() {
        handler.removeCallbacks(processingGuard);
        speaking = false;
        if (stopAfterSpeech) { stopSelf(); return; }
        awakeUntil = SystemClock.elapsedRealtime()
                + (PendingAction.isPending() ? CONFIRMATION_WINDOW_MS : CONVERSATION_WINDOW_MS);
        setHud(HudView.State.LISTENING);
        broadcast("listening", null, null);
        scheduleRestart(350);
    }

    // ---- Notification, batterie, diffusion ----------------------------------------------------------------

    private void createChannel() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Écoute HELIOS", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Indique que HELIOS écoute en mode mains libres.");
        channel.setShowBadge(false);
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification(String text) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, HeliosListenService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Arrêter", stop).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("HELIOS")
                .setContentText(text)
                .setContentIntent(open)
                .addAction(stopAction)
                .setOngoing(true)
                .build();
    }

    private void acquireWakeLock() {
        try {
            PowerManager manager = (PowerManager) getSystemService(POWER_SERVICE);
            if (manager == null) return;
            wakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "helios:listen");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(12L * 60L * 60L * 1000L);
        } catch (Exception ignored) { }
    }

    private void broadcast(String state, String heard, String reply) {
        Intent intent = new Intent(ACTION_STATUS).setPackage(getPackageName());
        intent.putExtra(EXTRA_STATE, state);
        if (heard != null) intent.putExtra(EXTRA_HEARD, heard);
        if (reply != null) intent.putExtra(EXTRA_REPLY, reply);
        sendBroadcast(intent);
    }
}
